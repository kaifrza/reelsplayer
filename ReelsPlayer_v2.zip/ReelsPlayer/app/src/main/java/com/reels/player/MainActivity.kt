@file:OptIn(androidx.media3.common.util.UnstableApi::class)

package com.reels.player

import android.Manifest
import android.content.ContentUris
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.MediaStore
import android.util.Size
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.Spring
import androidx.compose.animation.core.spring
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.scaleIn
import androidx.compose.animation.scaleOut
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectHorizontalDragGestures
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.pager.VerticalPager
import androidx.compose.foundation.pager.rememberPagerState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Button
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableLongStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.ImageBitmap
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.hapticfeedback.HapticFeedbackType
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalHapticFeedback
import androidx.compose.ui.platform.LocalLifecycleOwner
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.IntOffset
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.core.content.ContextCompat
import androidx.core.view.WindowCompat
import androidx.core.view.WindowInsetsCompat
import androidx.core.view.WindowInsetsControllerCompat
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.LifecycleEventObserver
import androidx.media3.common.MediaItem
import androidx.media3.common.Player
import androidx.media3.common.VideoSize
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.ui.AspectRatioFrameLayout
import androidx.media3.ui.PlayerView
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.withContext
import kotlinx.coroutines.withTimeoutOrNull

data class Video(val uri: Uri, val name: String)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        WindowCompat.setDecorFitsSystemWindows(window, false)
        WindowInsetsControllerCompat(window, window.decorView).apply {
            systemBarsBehavior = WindowInsetsControllerCompat.BEHAVIOR_SHOW_TRANSIENT_BARS_BY_SWIPE
            hide(WindowInsetsCompat.Type.systemBars())
        }
        setContent {
            MaterialTheme(colorScheme = darkColorScheme()) {
                App()
            }
        }
    }
}

@Composable
fun App() {
    val ctx = LocalContext.current
    val perm = if (Build.VERSION.SDK_INT >= 33)
        Manifest.permission.READ_MEDIA_VIDEO else Manifest.permission.READ_EXTERNAL_STORAGE

    var granted by remember {
        mutableStateOf(ContextCompat.checkSelfPermission(ctx, perm) == PackageManager.PERMISSION_GRANTED)
    }
    val launcher = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) {
        granted = it
    }
    var videos by remember { mutableStateOf<List<Video>?>(null) }

    LaunchedEffect(Unit) { if (!granted) launcher.launch(perm) }
    LaunchedEffect(granted) {
        if (granted) videos = withContext(Dispatchers.IO) { loadVideos(ctx) }
    }

    Box(Modifier.fillMaxSize().background(Color.Black), contentAlignment = Alignment.Center) {
        when {
            !granted -> CenterMessage(
                emoji = "🎬",
                title = "Reels Player",
                text = "Apni phone ki videos dekhne ke liye permission chahiye",
                button = "Permission do",
                onClick = { launcher.launch(perm) }
            )
            videos == null -> Text("Loading...", color = Color.White.copy(alpha = 0.7f))
            videos!!.isEmpty() -> CenterMessage("📭", "Koi video nahi mili", "Phone me video save karke dobara kholo", null, {})
            else -> ReelsScreen(videos!!)
        }
    }
}

@Composable
fun CenterMessage(emoji: String, title: String, text: String, button: String?, onClick: () -> Unit) {
    Column(horizontalAlignment = Alignment.CenterHorizontally, modifier = Modifier.padding(32.dp)) {
        Text(emoji, fontSize = 64.sp)
        Text(title, color = Color.White, fontSize = 22.sp, fontWeight = FontWeight.Bold, modifier = Modifier.padding(top = 12.dp))
        Text(text, color = Color.White.copy(alpha = 0.7f), textAlign = TextAlign.Center, modifier = Modifier.padding(top = 8.dp))
        if (button != null) {
            Button(onClick = onClick, modifier = Modifier.padding(top = 20.dp)) { Text(button) }
        }
    }
}

fun loadVideos(ctx: Context): List<Video> {
    val list = mutableListOf<Video>()
    val collection = MediaStore.Video.Media.EXTERNAL_CONTENT_URI
    val projection = arrayOf(MediaStore.Video.Media._ID, MediaStore.Video.Media.DISPLAY_NAME)
    ctx.contentResolver.query(
        collection, projection, null, null, "${MediaStore.Video.Media.DATE_ADDED} DESC"
    )?.use { c ->
        val idCol = c.getColumnIndexOrThrow(MediaStore.Video.Media._ID)
        val nameCol = c.getColumnIndexOrThrow(MediaStore.Video.Media.DISPLAY_NAME)
        while (c.moveToNext()) {
            list += Video(ContentUris.withAppendedId(collection, c.getLong(idCol)), c.getString(nameCol) ?: "")
        }
    }
    return list
}

fun fmt(ms: Long): String {
    val s = (ms / 1000).coerceAtLeast(0)
    return "%d:%02d".format(s / 60, s % 60)
}

@Composable
fun ActionButton(icon: String, label: String, scale: Float = 1f, onClick: () -> Unit) {
    Column(
        horizontalAlignment = Alignment.CenterHorizontally,
        modifier = Modifier.padding(vertical = 10.dp).clickable(onClick = onClick)
    ) {
        Text(icon, fontSize = 32.sp, modifier = Modifier.graphicsLayer { scaleX = scale; scaleY = scale })
        Text(label, color = Color.White, fontSize = 11.sp, modifier = Modifier.padding(top = 2.dp))
    }
}

@Composable
fun ReelsScreen(videos: List<Video>) {
    val ctx = LocalContext.current
    val haptic = LocalHapticFeedback.current
    val prefs = remember { ctx.getSharedPreferences("reels", Context.MODE_PRIVATE) }

    var liked by remember { mutableStateOf(prefs.getStringSet("liked", emptySet())!!.toSet()) }
    var muted by remember { mutableStateOf(prefs.getBoolean("muted", false)) }
    var portrait by remember { mutableStateOf(true) }
    var userPaused by remember { mutableStateOf(false) }
    var posMs by remember { mutableLongStateOf(0L) }
    var durMs by remember { mutableLongStateOf(0L) }
    var seeking by remember { mutableStateOf(false) }

    fun setLiked(key: String, on: Boolean) {
        liked = if (on) liked + key else liked - key
        prefs.edit().putStringSet("liked", liked.toSet()).apply()
    }

    val exo = remember {
        ExoPlayer.Builder(ctx).build().apply {
            repeatMode = Player.REPEAT_MODE_ONE
            playWhenReady = true
        }
    }

    DisposableEffect(exo) {
        val l = object : Player.Listener {
            override fun onVideoSizeChanged(videoSize: VideoSize) {
                portrait = videoSize.height >= videoSize.width
            }
        }
        exo.addListener(l)
        onDispose {
            exo.removeListener(l)
            exo.release()
        }
    }

    val owner = LocalLifecycleOwner.current
    DisposableEffect(owner) {
        val obs = LifecycleEventObserver { _, e ->
            if (e == Lifecycle.Event.ON_PAUSE) exo.pause()
            else if (e == Lifecycle.Event.ON_RESUME && !userPaused) exo.play()
        }
        owner.lifecycle.addObserver(obs)
        onDispose { owner.lifecycle.removeObserver(obs) }
    }

    val startPage = remember {
        val last = prefs.getString("last", null)
        videos.indexOfFirst { it.uri.toString() == last }.coerceAtLeast(0)
    }
    val pager = rememberPagerState(initialPage = startPage) { videos.size }

    LaunchedEffect(pager.settledPage) {
        val v = videos[pager.settledPage]
        prefs.edit().putString("last", v.uri.toString()).apply()
        userPaused = false
        posMs = 0L
        exo.setMediaItem(MediaItem.fromUri(v.uri))
        exo.prepare()
        exo.play()
    }
    LaunchedEffect(muted) {
        exo.volume = if (muted) 0f else 1f
        prefs.edit().putBoolean("muted", muted).apply()
    }
    LaunchedEffect(Unit) {
        while (true) {
            posMs = exo.currentPosition.coerceAtLeast(0)
            durMs = exo.duration.coerceAtLeast(0)
            delay(100)
        }
    }

    val progress = if (durMs > 0) (posMs.toFloat() / durMs).coerceIn(0f, 1f) else 0f

    fun seekFraction(f: Float) {
        val d = exo.duration
        if (d > 0) {
            val t = (d * f.coerceIn(0f, 1f)).toLong()
            exo.seekTo(t)
            posMs = t
        }
    }

    Box(Modifier.fillMaxSize()) {
        VerticalPager(state = pager, modifier = Modifier.fillMaxSize()) { page ->
            val video = videos[page]
            val key = video.uri.toString()
            val isCurrent = page == pager.settledPage
            val isLiked = key in liked

            var heartTick by remember { mutableIntStateOf(0) }
            var showHeart by remember { mutableStateOf(false) }
            var heartPos by remember { mutableStateOf(Offset.Zero) }
            var thumb by remember(key) { mutableStateOf<ImageBitmap?>(null) }
            val likeScale = remember { Animatable(1f) }

            LaunchedEffect(heartTick) {
                if (heartTick > 0) {
                    showHeart = true
                    delay(700)
                    showHeart = false
                }
            }
            LaunchedEffect(isLiked) {
                if (isLiked) {
                    likeScale.animateTo(1.35f, tween(120))
                    likeScale.animateTo(1f, spring(Spring.DampingRatioMediumBouncy))
                }
            }
            LaunchedEffect(key) {
                if (Build.VERSION.SDK_INT >= 29) {
                    thumb = withContext(Dispatchers.IO) {
                        runCatching {
                            ctx.contentResolver.loadThumbnail(video.uri, Size(540, 960), null).asImageBitmap()
                        }.getOrNull()
                    }
                }
            }

            Box(Modifier.fillMaxSize().background(Color.Black)) {
                // Thumbnail shows while swiping / loading
                thumb?.let {
                    Image(
                        bitmap = it,
                        contentDescription = null,
                        contentScale = if (it.height >= it.width) ContentScale.Crop else ContentScale.Fit,
                        modifier = Modifier.fillMaxSize()
                    )
                }

                if (isCurrent) {
                    AndroidView(
                        factory = { c ->
                            PlayerView(c).apply {
                                useController = false
                                keepScreenOn = true
                                setShutterBackgroundColor(android.graphics.Color.TRANSPARENT)
                                player = exo
                            }
                        },
                        update = {
                            it.resizeMode = if (portrait) AspectRatioFrameLayout.RESIZE_MODE_ZOOM
                            else AspectRatioFrameLayout.RESIZE_MODE_FIT
                        },
                        modifier = Modifier.fillMaxSize()
                    )
                }

                // Scrims for readable text
                Box(
                    Modifier.align(Alignment.BottomCenter).fillMaxWidth().height(260.dp)
                        .background(Brush.verticalGradient(listOf(Color.Transparent, Color.Black.copy(alpha = 0.7f))))
                )
                Box(
                    Modifier.align(Alignment.TopCenter).fillMaxWidth().height(140.dp)
                        .background(Brush.verticalGradient(listOf(Color.Black.copy(alpha = 0.55f), Color.Transparent)))
                )

                // Gestures: tap = pause/play, hold = pause, double tap = like
                Box(
                    Modifier.fillMaxSize().pointerInput(page, isCurrent) {
                        detectTapGestures(
                            onPress = {
                                val released = withTimeoutOrNull(250) { tryAwaitRelease(); true }
                                if (released == null && isCurrent) {
                                    exo.pause()
                                    tryAwaitRelease()
                                    if (!userPaused) exo.play()
                                }
                            },
                            onLongPress = { },
                            onTap = {
                                if (isCurrent) {
                                    if (userPaused) { exo.play(); userPaused = false }
                                    else { exo.pause(); userPaused = true }
                                }
                            },
                            onDoubleTap = { off ->
                                if (!isLiked) {
                                    setLiked(key, true)
                                    haptic.performHapticFeedback(HapticFeedbackType.LongPress)
                                }
                                heartPos = off
                                heartTick++
                            }
                        )
                    }
                )

                AnimatedVisibility(
                    visible = showHeart,
                    enter = scaleIn(spring(Spring.DampingRatioMediumBouncy)) + fadeIn(),
                    exit = fadeOut() + scaleOut(),
                    modifier = Modifier.offset {
                        IntOffset((heartPos.x - 50.dp.toPx()).toInt(), (heartPos.y - 60.dp.toPx()).toInt())
                    }
                ) {
                    Text("❤️", fontSize = 80.sp)
                }

                if (isCurrent && userPaused) {
                    Box(
                        Modifier.align(Alignment.Center)
                            .background(Color.Black.copy(alpha = 0.45f), RoundedCornerShape(50))
                            .padding(horizontal = 26.dp, vertical = 16.dp)
                    ) {
                        Text("▶", fontSize = 40.sp, color = Color.White)
                    }
                }

                // Right side actions
                Column(
                    modifier = Modifier.align(Alignment.BottomEnd).padding(end = 14.dp, bottom = 56.dp),
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    ActionButton(
                        icon = if (isLiked) "❤️" else "🤍",
                        label = if (isLiked) "Liked" else "Like",
                        scale = likeScale.value
                    ) { setLiked(key, !isLiked) }
                    ActionButton(icon = if (muted) "🔇" else "🔊", label = if (muted) "Unmute" else "Mute") {
                        muted = !muted
                    }
                    ActionButton(icon = "📤", label = "Share") {
                        val i = Intent(Intent.ACTION_SEND).apply {
                            type = "video/*"
                            putExtra(Intent.EXTRA_STREAM, video.uri)
                            addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
                        }
                        ctx.startActivity(Intent.createChooser(i, "Share video"))
                    }
                }

                // Caption
                Text(
                    video.name.substringBeforeLast('.'),
                    color = Color.White,
                    fontSize = 15.sp,
                    fontWeight = FontWeight.SemiBold,
                    maxLines = 2,
                    overflow = TextOverflow.Ellipsis,
                    modifier = Modifier.align(Alignment.BottomStart).padding(start = 16.dp, end = 90.dp, bottom = 48.dp)
                )
            }
        }

        // Fixed header
        Row(
            Modifier.align(Alignment.TopCenter).fillMaxWidth().padding(start = 16.dp, end = 16.dp, top = 28.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text("Reels", color = Color.White, fontSize = 26.sp, fontWeight = FontWeight.Bold, modifier = Modifier.weight(1f))
            Text("${pager.currentPage + 1} / ${videos.size}", color = Color.White.copy(alpha = 0.85f), fontSize = 14.sp)
        }

        // Time while seeking
        if (seeking) {
            Box(
                Modifier.align(Alignment.Center)
                    .background(Color.Black.copy(alpha = 0.55f), RoundedCornerShape(12.dp))
                    .padding(horizontal = 18.dp, vertical = 10.dp)
            ) {
                Text("${fmt(posMs)} / ${fmt(durMs)}", color = Color.White, fontSize = 20.sp, fontWeight = FontWeight.Medium)
            }
        }

        // Seekable progress bar (tap or drag)
        Box(
            Modifier.align(Alignment.BottomCenter).fillMaxWidth().height(32.dp)
                .pointerInput(Unit) {
                    detectTapGestures { o -> seekFraction(o.x / size.width) }
                }
                .pointerInput(Unit) {
                    detectHorizontalDragGestures(
                        onDragStart = { seeking = true },
                        onDragEnd = { seeking = false },
                        onDragCancel = { seeking = false }
                    ) { change, _ ->
                        change.consume()
                        seekFraction(change.position.x / size.width)
                    }
                }
        ) {
            val h = if (seeking) 6.dp else 2.dp
            Box(Modifier.align(Alignment.BottomStart).fillMaxWidth().height(h).background(Color.White.copy(alpha = 0.3f)))
            Box(Modifier.align(Alignment.BottomStart).fillMaxWidth(progress).height(h).background(Color.White))
        }
    }
}
