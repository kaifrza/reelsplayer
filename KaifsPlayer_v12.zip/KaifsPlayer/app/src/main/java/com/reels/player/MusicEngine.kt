package com.reels.player

import android.content.ComponentName
import android.content.ContentUris
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.os.Handler
import android.os.Looper
import android.provider.MediaStore
import android.widget.Toast
import androidx.compose.runtime.Immutable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableLongStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.core.content.ContextCompat
import androidx.media3.common.AudioAttributes
import androidx.media3.common.C
import androidx.media3.common.MediaItem
import androidx.media3.common.MediaMetadata
import androidx.media3.common.PlaybackException
import androidx.media3.common.PlaybackParameters
import androidx.media3.common.Player
import androidx.media3.common.Timeline
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.session.DefaultMediaNotificationProvider
import androidx.media3.session.MediaController
import androidx.media3.session.MediaSession
import androidx.media3.session.MediaSessionService
import androidx.media3.session.SessionToken
import com.google.common.util.concurrent.ListenableFuture
import java.io.File

// ---------- Data ----------

@Immutable
data class Song(
    val id: Long,
    val uri: Uri,
    val title: String,
    val artist: String,
    val album: String,
    val albumId: Long,
    val durationMs: Long,
    val added: Long
)

val audioExts = setOf(
    "mp3", "m4a", "aac", "flac", "wav", "ogg", "oga", "opus", "amr", "awb", "mka",
    "ac3", "eac3", "wma", "mid", "midi", "3ga", "ape", "dts", "aiff", "aif", "m4b"
)

fun isAudioFile(f: File): Boolean = f.extension.lowercase() in audioExts

fun fileSong(f: File): Song = Song(
    id = f.absolutePath.hashCode().toLong(),
    uri = Uri.fromFile(f),
    title = f.nameWithoutExtension,
    artist = "Unknown artist",
    album = f.parentFile?.name ?: "",
    albumId = 0L,
    durationMs = 0L,
    added = f.lastModified() / 1000
)

fun loadSongs(ctx: Context, includeAll: Boolean): List<Song> {
    val out = mutableListOf<Song>()
    val coll = MediaStore.Audio.Media.EXTERNAL_CONTENT_URI
    val proj = arrayOf(
        MediaStore.Audio.Media._ID,
        MediaStore.Audio.Media.TITLE,
        MediaStore.Audio.Media.ARTIST,
        MediaStore.Audio.Media.ALBUM,
        MediaStore.Audio.Media.ALBUM_ID,
        MediaStore.Audio.Media.DURATION,
        MediaStore.Audio.Media.DATE_ADDED
    )
    val sel = if (includeAll) "${MediaStore.Audio.Media.DURATION} >= 3000"
    else "${MediaStore.Audio.Media.IS_MUSIC} != 0 AND ${MediaStore.Audio.Media.DURATION} >= 3000"
    ctx.contentResolver.query(coll, proj, sel, null, null)?.use { c ->
        val idCol = c.getColumnIndexOrThrow(MediaStore.Audio.Media._ID)
        val titleCol = c.getColumnIndexOrThrow(MediaStore.Audio.Media.TITLE)
        val artistCol = c.getColumnIndexOrThrow(MediaStore.Audio.Media.ARTIST)
        val albumCol = c.getColumnIndexOrThrow(MediaStore.Audio.Media.ALBUM)
        val albumIdCol = c.getColumnIndexOrThrow(MediaStore.Audio.Media.ALBUM_ID)
        val durCol = c.getColumnIndexOrThrow(MediaStore.Audio.Media.DURATION)
        val addCol = c.getColumnIndexOrThrow(MediaStore.Audio.Media.DATE_ADDED)
        while (c.moveToNext()) {
            val id = c.getLong(idCol)
            val artist = c.getString(artistCol)?.takeIf { it != "<unknown>" } ?: "Unknown artist"
            val album = c.getString(albumCol)?.takeIf { it != "<unknown>" } ?: "Unknown album"
            out += Song(
                id = id,
                uri = ContentUris.withAppendedId(coll, id),
                title = c.getString(titleCol) ?: "Unknown",
                artist = artist,
                album = album,
                albumId = c.getLong(albumIdCol),
                durationMs = c.getLong(durCol),
                added = c.getLong(addCol)
            )
        }
    }
    return out.sortedBy { it.title.lowercase() }
}

fun Song.toMediaItem(): MediaItem {
    val art: Uri? = if (albumId > 0L) {
        ContentUris.withAppendedId(Uri.parse("content://media/external/audio/albumart"), albumId)
    } else null
    return MediaItem.Builder()
        .setUri(uri)
        .setMediaId(id.toString())
        .setMediaMetadata(
            MediaMetadata.Builder()
                .setTitle(title)
                .setArtist(artist)
                .setAlbumTitle(album)
                .setArtworkUri(art)
                .build()
        )
        .build()
}

// ---------- Service (owns the player + media notification) ----------

class MusicService : MediaSessionService() {
    private var session: MediaSession? = null

    override fun onCreate() {
        super.onCreate()
        val player = ExoPlayer.Builder(this)
            .setAudioAttributes(
                AudioAttributes.Builder()
                    .setUsage(C.USAGE_MEDIA)
                    .setContentType(C.AUDIO_CONTENT_TYPE_MUSIC)
                    .build(),
                true
            )
            .setHandleAudioBecomingNoisy(true)
            .setWakeMode(C.WAKE_MODE_LOCAL)
            .build()
        session = MediaSession.Builder(this, player).build()
        val provider = DefaultMediaNotificationProvider.Builder(this).build()
        provider.setSmallIcon(R.drawable.ic_music_note)
        setMediaNotificationProvider(provider)
    }

    override fun onGetSession(controllerInfo: MediaSession.ControllerInfo): MediaSession? = session

    override fun onTaskRemoved(rootIntent: Intent?) {
        val p = session?.player
        if (p == null || !p.playWhenReady || p.mediaItemCount == 0) {
            stopSelf()
        }
    }

    override fun onDestroy() {
        session?.let {
            it.player.release()
            it.release()
        }
        session = null
        super.onDestroy()
    }
}

// ---------- UI-side controller ----------

object MusicHub {
    private var appCtx: Context? = null
    private var future: ListenableFuture<MediaController>? = null
    private var pending: (() -> Unit)? = null
    private val handler = Handler(Looper.getMainLooper())
    private var sleepRunnable: Runnable? = null

    var controller by mutableStateOf<MediaController?>(null)
    var current by mutableStateOf<MediaItem?>(null)
    var isPlaying by mutableStateOf(false)
    var posMs by mutableLongStateOf(0L)
    var durMs by mutableLongStateOf(0L)
    var shuffle by mutableStateOf(false)
    var repeat by mutableIntStateOf(Player.REPEAT_MODE_OFF)
    var queue by mutableStateOf<List<MediaItem>>(emptyList())
    var index by mutableIntStateOf(0)
    var speed by mutableFloatStateOf(1f)
    var sleepEnd by mutableLongStateOf(0L)

    fun init(ctx: Context) {
        if (future != null) return
        val app = ctx.applicationContext
        appCtx = app
        val token = SessionToken(app, ComponentName(app, MusicService::class.java))
        val f = MediaController.Builder(app, token).buildAsync()
        future = f
        f.addListener({
            val c = runCatching { f.get() }.getOrNull()
            if (c != null) attach(c)
        }, ContextCompat.getMainExecutor(app))
    }

    fun release() {
        future?.let { MediaController.releaseFuture(it) }
        future = null
        controller = null
    }

    private fun refreshQueue(c: MediaController) {
        queue = (0 until c.mediaItemCount).map { c.getMediaItemAt(it) }
    }

    private fun refresh(c: MediaController) {
        current = c.currentMediaItem
        isPlaying = c.isPlaying
        shuffle = c.shuffleModeEnabled
        repeat = c.repeatMode
        index = c.currentMediaItemIndex
        durMs = c.duration.coerceAtLeast(0)
        posMs = c.currentPosition.coerceAtLeast(0)
        speed = c.playbackParameters.speed
        refreshQueue(c)
    }

    private fun attach(c: MediaController) {
        controller = c
        c.addListener(object : Player.Listener {
            override fun onIsPlayingChanged(playing: Boolean) {
                isPlaying = playing
            }

            override fun onMediaItemTransition(mediaItem: MediaItem?, reason: Int) {
                current = mediaItem
                index = c.currentMediaItemIndex
                posMs = 0L
                durMs = c.duration.coerceAtLeast(0)
            }

            override fun onTimelineChanged(timeline: Timeline, reason: Int) {
                refreshQueue(c)
                index = c.currentMediaItemIndex
            }

            override fun onPlaybackStateChanged(playbackState: Int) {
                durMs = c.duration.coerceAtLeast(0)
            }

            override fun onShuffleModeEnabledChanged(shuffleModeEnabled: Boolean) {
                shuffle = shuffleModeEnabled
            }

            override fun onRepeatModeChanged(repeatMode: Int) {
                repeat = repeatMode
            }

            override fun onPlaybackParametersChanged(playbackParameters: PlaybackParameters) {
                speed = playbackParameters.speed
            }

            override fun onPlayerError(error: PlaybackException) {
                appCtx?.let {
                    Toast.makeText(it, "Ye audio nahi chal pa raha, agla chala raha hoon", Toast.LENGTH_SHORT).show()
                }
                if (c.hasNextMediaItem()) {
                    c.seekToNextMediaItem()
                    c.prepare()
                    c.play()
                }
            }
        })
        refresh(c)
        pending?.invoke()
        pending = null
    }

    fun tick() {
        val c = controller ?: return
        posMs = c.currentPosition.coerceAtLeast(0)
        durMs = c.duration.coerceAtLeast(0)
    }

    fun playList(items: List<MediaItem>, startIndex: Int, shuffleOn: Boolean = false) {
        if (items.isEmpty()) return
        val action = {
            val c = controller
            if (c != null) {
                c.shuffleModeEnabled = shuffleOn
                c.setMediaItems(items, startIndex.coerceIn(0, items.size - 1), 0L)
                c.prepare()
                c.play()
            }
        }
        if (controller != null) action() else pending = action
    }

    fun playSongs(songs: List<Song>, startIndex: Int, shuffleOn: Boolean = false) {
        playList(songs.map { it.toMediaItem() }, startIndex, shuffleOn)
    }

    fun playAt(i: Int) {
        val c = controller ?: return
        c.seekToDefaultPosition(i)
        c.play()
    }

    fun toggle() {
        val c = controller ?: return
        if (c.isPlaying) c.pause() else c.play()
    }

    fun pause() {
        controller?.pause()
    }

    fun next() {
        controller?.seekToNextMediaItem()
    }

    fun prev() {
        val c = controller ?: return
        if (c.currentPosition > 3000) c.seekTo(0L) else c.seekToPreviousMediaItem()
    }

    fun seekTo(ms: Long) {
        controller?.seekTo(ms)
        posMs = ms
    }

    fun toggleShuffle() {
        val c = controller ?: return
        c.shuffleModeEnabled = !c.shuffleModeEnabled
    }

    fun toggleRepeat() {
        val c = controller ?: return
        c.repeatMode = when (c.repeatMode) {
            Player.REPEAT_MODE_OFF -> Player.REPEAT_MODE_ALL
            Player.REPEAT_MODE_ALL -> Player.REPEAT_MODE_ONE
            else -> Player.REPEAT_MODE_OFF
        }
    }

    fun changeSpeed(s: Float) {
        controller?.setPlaybackSpeed(s)
        speed = s
    }

    fun setSleep(minutes: Int) {
        sleepRunnable?.let { handler.removeCallbacks(it) }
        sleepRunnable = null
        sleepEnd = 0L
        if (minutes > 0) {
            val r = Runnable {
                controller?.pause()
                sleepEnd = 0L
            }
            sleepRunnable = r
            sleepEnd = System.currentTimeMillis() + minutes * 60_000L
            handler.postDelayed(r, minutes * 60_000L)
        }
    }
}
