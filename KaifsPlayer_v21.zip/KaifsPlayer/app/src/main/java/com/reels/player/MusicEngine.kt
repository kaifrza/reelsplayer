@file:OptIn(androidx.media3.common.util.UnstableApi::class)

package com.reels.player

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Matrix
import android.media.ExifInterface
import android.widget.RemoteViews
import java.io.FileOutputStream
import android.os.Build
import android.os.Bundle
import android.util.LruCache
import android.util.Size
import androidx.core.app.NotificationCompat
import androidx.core.app.NotificationManagerCompat
import androidx.core.app.ServiceCompat
import androidx.media3.session.CommandButton
import androidx.media3.session.MediaNotification
import androidx.media3.session.MediaStyleNotificationHelper
import com.google.common.collect.ImmutableList
import java.util.concurrent.Executors
import android.content.ComponentName
import android.content.ContentUris
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.os.Handler
import android.os.Looper
import android.provider.MediaStore
import android.widget.Toast
import androidx.compose.runtime.Immutable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableLongStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.core.content.ContextCompat
import androidx.media3.common.AudioAttributes
import androidx.media3.common.C
import androidx.media3.common.MediaItem
import androidx.media3.common.MediaMetadata
import androidx.media3.common.PlaybackException
import androidx.media3.common.PlaybackParameters
import androidx.media3.common.Player
import androidx.media3.common.Timeline
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.session.DefaultMediaNotificationProvider
import androidx.media3.session.MediaController
import androidx.media3.session.MediaSession
import androidx.media3.session.MediaSessionService
import androidx.media3.session.SessionToken
import com.google.common.util.concurrent.ListenableFuture
import java.io.File

// ---------- Data ----------

@Immutable
data class Song(
    val id: Long,
    val uri: Uri,
    val title: String,
    val artist: String,
    val album: String,
    val albumId: Long,
    val durationMs: Long,
    val added: Long
)

val audioExts = setOf(
    "mp3", "m4a", "aac", "flac", "wav", "ogg", "oga", "opus", "amr", "awb", "mka",
    "ac3", "eac3", "wma", "mid", "midi", "3ga", "ape", "dts", "aiff", "aif", "m4b"
)

fun isAudioFile(f: File): Boolean = f.extension.lowercase() in audioExts

fun fileSong(f: File): Song = Song(
    id = f.absolutePath.hashCode().toLong(),
    uri = Uri.fromFile(f),
    title = f.nameWithoutExtension,
    artist = "Unknown artist",
    album = f.parentFile?.name ?: "",
    albumId = 0L,
    durationMs = 0L,
    added = f.lastModified() / 1000
)

fun loadSongs(ctx: Context, includeAll: Boolean): List<Song> {
    val out = mutableListOf<Song>()
    val coll = MediaStore.Audio.Media.EXTERNAL_CONTENT_URI
    val proj = arrayOf(
        MediaStore.Audio.Media._ID,
        MediaStore.Audio.Media.TITLE,
        MediaStore.Audio.Media.ARTIST,
        MediaStore.Audio.Media.ALBUM,
        MediaStore.Audio.Media.ALBUM_ID,
        MediaStore.Audio.Media.DURATION,
        MediaStore.Audio.Media.DATE_ADDED
    )
    val sel = if (includeAll) "${MediaStore.Audio.Media.DURATION} >= 3000"
    else "${MediaStore.Audio.Media.IS_MUSIC} != 0 AND ${MediaStore.Audio.Media.DURATION} >= 3000"
    ctx.contentResolver.query(coll, proj, sel, null, null)?.use { c ->
        val idCol = c.getColumnIndexOrThrow(MediaStore.Audio.Media._ID)
        val titleCol = c.getColumnIndexOrThrow(MediaStore.Audio.Media.TITLE)
        val artistCol = c.getColumnIndexOrThrow(MediaStore.Audio.Media.ARTIST)
        val albumCol = c.getColumnIndexOrThrow(MediaStore.Audio.Media.ALBUM)
        val albumIdCol = c.getColumnIndexOrThrow(MediaStore.Audio.Media.ALBUM_ID)
        val durCol = c.getColumnIndexOrThrow(MediaStore.Audio.Media.DURATION)
        val addCol = c.getColumnIndexOrThrow(MediaStore.Audio.Media.DATE_ADDED)
        while (c.moveToNext()) {
            val id = c.getLong(idCol)
            val artist = c.getString(artistCol)?.takeIf { it != "<unknown>" } ?: "Unknown artist"
            val album = c.getString(albumCol)?.takeIf { it != "<unknown>" } ?: "Unknown album"
            out += Song(
                id = id,
                uri = ContentUris.withAppendedId(coll, id),
                title = c.getString(titleCol) ?: "Unknown",
                artist = artist,
                album = album,
                albumId = c.getLong(albumIdCol),
                durationMs = c.getLong(durCol),
                added = c.getLong(addCol)
            )
        }
    }
    return out.sortedBy { it.title.lowercase() }
}

fun Song.toMediaItem(): MediaItem {
    val original: Uri? = if (albumId > 0L) {
        ContentUris.withAppendedId(Uri.parse("content://media/external/audio/albumart"), albumId)
    } else null
    val art: Uri? = MusicHub.customArtUri(id.toString()) ?: original
    val extras = Bundle()
    extras.putString("albumArt", original?.toString())
    return MediaItem.Builder()
        .setUri(uri)
        .setMediaId(id.toString())
        .setMediaMetadata(
            MediaMetadata.Builder()
                .setTitle(title)
                .setArtist(artist)
                .setAlbumTitle(album)
                .setArtworkUri(art)
                .setExtras(extras)
                .build()
        )
        .build()
}

// ---------- Service (owns the player + media notification) ----------

/** User-chosen artwork per song, stored privately inside the app. */
object CustomArt {
    var version by mutableIntStateOf(0)

    fun file(ctx: Context, key: String): File =
        File(File(ctx.filesDir, "art"), Integer.toHexString(key.hashCode()) + ".jpg")

    fun exists(ctx: Context, key: String): Boolean = file(ctx, key).exists()

    fun remove(ctx: Context, key: String) {
        file(ctx, key).delete()
    }

    /**
     * Saves the picked image as a square, centre-cropped JPEG (max 1024px) so any photo - big, wide or tall -
     * fits the artwork frame, the lists and the notification the same way. EXIF rotation is respected.
     */
    fun save(ctx: Context, key: String, src: Uri): Boolean {
        try {
            val bounds = BitmapFactory.Options().apply { inJustDecodeBounds = true }
            ctx.contentResolver.openInputStream(src)?.use { BitmapFactory.decodeStream(it, null, bounds) }
            if (bounds.outWidth <= 0 || bounds.outHeight <= 0) return false
            val shortSide = minOf(bounds.outWidth, bounds.outHeight)
            var sample = 1
            while (shortSide / (sample * 2) >= 1024) sample *= 2
            val opts = BitmapFactory.Options().apply { inSampleSize = sample }
            var bmp = ctx.contentResolver.openInputStream(src)?.use { BitmapFactory.decodeStream(it, null, opts) }
                ?: return false

            val orientation = runCatching {
                ctx.contentResolver.openInputStream(src)?.use {
                    ExifInterface(it).getAttributeInt(ExifInterface.TAG_ORIENTATION, ExifInterface.ORIENTATION_NORMAL)
                }
            }.getOrNull() ?: ExifInterface.ORIENTATION_NORMAL
            val m = Matrix()
            when (orientation) {
                ExifInterface.ORIENTATION_ROTATE_90 -> m.postRotate(90f)
                ExifInterface.ORIENTATION_ROTATE_180 -> m.postRotate(180f)
                ExifInterface.ORIENTATION_ROTATE_270 -> m.postRotate(270f)
                ExifInterface.ORIENTATION_FLIP_HORIZONTAL -> m.postScale(-1f, 1f)
                ExifInterface.ORIENTATION_FLIP_VERTICAL -> m.postScale(1f, -1f)
            }
            if (!m.isIdentity) {
                bmp = Bitmap.createBitmap(bmp, 0, 0, bmp.width, bmp.height, m, true)
            }

            val side = minOf(bmp.width, bmp.height)
            var square = Bitmap.createBitmap(bmp, (bmp.width - side) / 2, (bmp.height - side) / 2, side, side)
            if (side > 1024) {
                square = Bitmap.createScaledBitmap(square, 1024, 1024, true)
            }

            val f = file(ctx, key)
            f.parentFile?.mkdirs()
            FileOutputStream(f).use { square.compress(Bitmap.CompressFormat.JPEG, 92, it) }
            return true
        } catch (e: Exception) {
            return false
        } catch (e: OutOfMemoryError) {
            return false
        }
    }

    fun decode(path: String, px: Int): Bitmap? {
        val o = BitmapFactory.Options().apply { inJustDecodeBounds = true }
        BitmapFactory.decodeFile(path, o)
        var sample = 1
        while (o.outWidth / (sample * 2) >= px && o.outHeight / (sample * 2) >= px) sample *= 2
        return BitmapFactory.decodeFile(path, BitmapFactory.Options().apply { inSampleSize = sample })
    }
}

/** Call after changing a custom artwork so lists, mini player and the notification all refresh. */
fun notifyArtChanged(mediaId: String? = null) {
    CustomArt.version++
    MusicService.artVersion++
    if (mediaId != null) MusicHub.refreshArtwork(mediaId)
    MusicService.instance?.refreshNotification()
}

fun artBitmap(ctx: Context, uri: Uri, px: Int, key: String?): Bitmap? {
    var b: Bitmap? = null
    if (key != null) {
        val cf = CustomArt.file(ctx, key)
        if (cf.exists()) b = runCatching { CustomArt.decode(cf.path, px) }.getOrNull()
    }
    if (b == null && uri.scheme == "content" && Build.VERSION.SDK_INT >= 29) {
        b = runCatching { ctx.contentResolver.loadThumbnail(uri, Size(px, px), null) }.getOrNull()
    }
    if (b == null) b = runCatching { embeddedArt(ctx, uri) }.getOrNull()
    return b
}

/** Bakes a fixed alpha into the bitmap once, so the notification doesn't need a per-update setImageAlpha call. */
private fun dimBitmap(src: Bitmap, alpha: Int): Bitmap {
    val out = Bitmap.createBitmap(src.width, src.height, Bitmap.Config.ARGB_8888)
    val c = android.graphics.Canvas(out)
    val paint = android.graphics.Paint().apply { this.alpha = alpha }
    c.drawBitmap(src, 0f, 0f, paint)
    return out
}

private fun softBlur(src: Bitmap): Bitmap {
    // Tiny on purpose: this is sent to the system UI on every notification update, so the smaller
    // the better. The ImageView stretches it back up, which looks the same blurry background.
    val tiny = Bitmap.createScaledBitmap(src, 24, 24, true)
    return Bitmap.createScaledBitmap(tiny, 32, 32, true)
}

class MusicService : MediaSessionService() {
    companion object {
        /**
         * How often the custom bar is re-posted. The system media card (lock screen / quick settings) has
         * its own seek bar driven by the MediaSession; every notification update makes that card reload
         * and its dot jumps back to the start (the blink). So we post as rarely as we can and let the
         * system seek bar and the Chronometer run on their own between posts.
         */
        const val TICK_MS = 10_000L
        const val NOTIF_ID = 1101
        const val CHANNEL = "kaifs_music"
        const val ACTION_PREV = "com.reels.player.PREV"
        const val ACTION_TOGGLE = "com.reels.player.TOGGLE"
        const val ACTION_NEXT = "com.reels.player.NEXT"
        const val ACTION_STOP = "com.reels.player.STOP"

        @Volatile
        var artVersion = 0

        @Volatile
        var instance: MusicService? = null
    }

    private var session: MediaSession? = null
    private val handler = Handler(Looper.getMainLooper())
    private val artCache = LruCache<String, Bitmap>(6)
    private val bgCache = LruCache<String, Bitmap>(6)
    private val smallArtCache = LruCache<String, Bitmap>(6)
    private val postedAt = System.currentTimeMillis()
    private val artExecutor = Executors.newSingleThreadExecutor()
    private var artRequested: String? = null

    private val ticker = object : Runnable {
        override fun run() {
            val pm = getSystemService(Context.POWER_SERVICE) as android.os.PowerManager
            if (pm.isInteractive) refreshNotification()
            handler.postDelayed(this, TICK_MS)
        }
    }

    override fun onCreate() {
        super.onCreate()
        instance = this
        if (Build.VERSION.SDK_INT >= 26) {
            val ch = NotificationChannel(CHANNEL, "Music playback", NotificationManager.IMPORTANCE_LOW)
            ch.setShowBadge(false)
            (getSystemService(NOTIFICATION_SERVICE) as NotificationManager).createNotificationChannel(ch)
        }
        val player = ExoPlayer.Builder(this)
            .setAudioAttributes(
                AudioAttributes.Builder()
                    .setUsage(C.USAGE_MEDIA)
                    .setContentType(C.AUDIO_CONTENT_TYPE_MUSIC)
                    .build(),
                true
            )
            .setHandleAudioBecomingNoisy(true)
            .setWakeMode(C.WAKE_MODE_LOCAL)
            .build()
        player.addListener(object : Player.Listener {
            override fun onIsPlayingChanged(isPlaying: Boolean) {
                handler.removeCallbacks(ticker)
                if (isPlaying) handler.postDelayed(ticker, TICK_MS) else refreshNotification()
            }

            override fun onMediaItemTransition(mediaItem: MediaItem?, reason: Int) {
                refreshNotification()
            }
        })
        session = MediaSession.Builder(this, player).build()
        setMediaNotificationProvider(KaifsNotificationProvider(this))
    }

    override fun onGetSession(controllerInfo: MediaSession.ControllerInfo): MediaSession? = session

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        val p = session?.player
        when (intent?.action) {
            ACTION_PREV -> {
                if (p != null) {
                    if (p.currentPosition > 3000) p.seekTo(0L) else p.seekToPreviousMediaItem()
                }
            }
            ACTION_TOGGLE -> {
                if (p != null) {
                    if (p.isPlaying) p.pause() else p.play()
                }
            }
            ACTION_NEXT -> p?.seekToNextMediaItem()
            ACTION_STOP -> {
                p?.pause()
                p?.clearMediaItems()
                handler.removeCallbacks(ticker)
                ServiceCompat.stopForeground(this, ServiceCompat.STOP_FOREGROUND_REMOVE)
                stopSelf()
            }
        }
        return super.onStartCommand(intent, flags, startId)
    }

    private fun servicePending(action: String, code: Int): PendingIntent =
        PendingIntent.getService(
            this, code,
            Intent(this, MusicService::class.java).setAction(action),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )

    private fun artKey(item: MediaItem): String = item.mediaId + "#" + artVersion

    private fun requestArt(item: MediaItem) {
        val ak = artKey(item)
        if (artRequested == ak) return
        artRequested = ak
        val uri = item.localConfiguration?.uri ?: return
        val mediaId = item.mediaId
        artExecutor.execute {
            val bmp = artBitmap(applicationContext, uri, 320, mediaId)
            val blurred = if (bmp != null) runCatching { dimBitmap(softBlur(bmp), 130) }.getOrNull() else null
            val small = if (bmp != null) runCatching { Bitmap.createScaledBitmap(bmp, 144, 144, true) }.getOrNull() else null
            handler.post {
                if (bmp != null) {
                    artCache.put(ak, bmp)
                    if (small != null) smallArtCache.put(ak, small)
                    if (blurred != null) bgCache.put(ak, blurred)
                    refreshNotification()
                }
            }
        }
    }

    private fun bindViews(layout: Int, title: String, artist: String, art: Bitmap?, bg: Bitmap?, pos: Long, dur: Long, playing: Boolean): RemoteViews {
        val rv = RemoteViews(packageName, layout)
        rv.setTextViewText(R.id.n_title, title)
        rv.setTextViewText(R.id.n_artist, artist)
        // Chronometer ticks by itself inside the system UI, so the elapsed time needs no notification updates.
        rv.setChronometer(
            R.id.n_time,
            android.os.SystemClock.elapsedRealtime() - pos,
            if (dur > 0) "%s / " + fmt(dur).replace("%", "%%") else "%s",
            playing
        )
        // Only touch the progress value. setProgressBar() also re-sends setMax/setIndeterminate every tick,
        // which makes the bar redraw from scratch (the 1-second blink). Max (1000) is fixed in the layout XML.
        rv.setInt(R.id.n_progress, "setProgress", if (dur > 0) ((pos * 1000L) / dur).toInt().coerceIn(0, 1000) else 0)
        if (art != null) rv.setImageViewBitmap(R.id.n_art, art)
        else rv.setImageViewResource(R.id.n_art, R.drawable.notif_bg_default)
        if (bg != null) {
            rv.setImageViewBitmap(R.id.n_bg, bg)
        } else {
            rv.setImageViewResource(R.id.n_bg, R.drawable.notif_bg_default)
        }
        return rv
    }

    fun buildNotification(s: MediaSession): Notification {
        val p = s.player
        val item = p.currentMediaItem
        val md = item?.mediaMetadata
        val title = md?.title?.toString() ?: "KaifsPlayer"
        val artist = md?.artist?.toString() ?: ""
        val pos = p.currentPosition.coerceAtLeast(0L)
        val dur = p.duration.coerceAtLeast(0L)
        val playing = p.isPlaying
        var art: Bitmap? = null
        var smallArt: Bitmap? = null
        var bg: Bitmap? = null
        if (item != null) {
            val ak = artKey(item)
            art = artCache.get(ak)
            smallArt = smallArtCache.get(ak)
            bg = bgCache.get(ak)
            if (art == null) requestArt(item)
        }
        val open = PendingIntent.getActivity(
            this, 0,
            Intent(this, MainActivity::class.java)
                .putExtra("open_now_playing", true)
                .addFlags(Intent.FLAG_ACTIVITY_SINGLE_TOP or Intent.FLAG_ACTIVITY_CLEAR_TOP),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )
        val useArtStyle = getSharedPreferences("app", Context.MODE_PRIVATE).getBoolean("notif_art", false)
        val b = NotificationCompat.Builder(this, CHANNEL)
            .setSmallIcon(R.drawable.ic_music_note)
            .setContentTitle(title)
            .setContentText(artist)
            .setLargeIcon(if (useArtStyle) smallArt else art)
            .setWhen(postedAt)
            .setColor(0xFFE1306C.toInt())
            .setContentIntent(open)
            .setOnlyAlertOnce(true)
            .setOngoing(playing)
            .setShowWhen(false)
            .setVisibility(NotificationCompat.VISIBILITY_PUBLIC)
            .setCategory(NotificationCompat.CATEGORY_TRANSPORT)
        if (useArtStyle) {
            b.setCustomContentView(bindViews(R.layout.notif_music_small, title, artist, smallArt, bg, pos, dur, playing))
            b.setCustomBigContentView(bindViews(R.layout.notif_music_big, title, artist, smallArt, bg, pos, dur, playing))
        } else {
            if (dur > 0) {
                b.setSubText(fmt(pos) + " / " + fmt(dur))
                b.setProgress((dur / 1000L).toInt(), (pos / 1000L).toInt(), false)
            }
        }
        b.addAction(R.drawable.ic_skip_prev, "Previous", servicePending(ACTION_PREV, 1))
        b.addAction(
            if (playing) R.drawable.ic_pause else R.drawable.ic_play,
            if (playing) "Pause" else "Play",
            servicePending(ACTION_TOGGLE, 2)
        )
        b.addAction(R.drawable.ic_skip_next, "Next", servicePending(ACTION_NEXT, 3))
        b.addAction(R.drawable.ic_close, "Stop", servicePending(ACTION_STOP, 4))
        if (useArtStyle) {
            b.setStyle(MediaStyleNotificationHelper.DecoratedMediaCustomViewStyle(s).setShowActionsInCompactView(0, 1, 2))
        } else {
            b.setStyle(MediaStyleNotificationHelper.MediaStyle(s).setShowActionsInCompactView(0, 1, 2))
        }
        return b.build()
    }

    private var lastSig: String? = null


    fun refreshNotification() {
        val s = session ?: return
        val p = s.player
        if (p.mediaItemCount == 0) return
        // Skip identical updates (several callers can fire within the same second); every extra
        // notify() is another chance for the system UI to redraw the row.
        val item = p.currentMediaItem
        val sig = "${item?.mediaId}|${artVersion}|${p.currentPosition / TICK_MS}|${p.isPlaying}|" +
            "${item?.let { artCache.get(artKey(it)) != null }}|${item?.mediaMetadata?.title}"
        if (sig == lastSig) return
        lastSig = sig
        runCatching { NotificationManagerCompat.from(this).notify(NOTIF_ID, buildNotification(s)) }
    }

    override fun onTaskRemoved(rootIntent: Intent?) {
        val p = session?.player
        if (p == null || !p.playWhenReady || p.mediaItemCount == 0) {
            stopSelf()
        }
    }

    override fun onDestroy() {
        instance = null
        handler.removeCallbacks(ticker)
        artExecutor.shutdown()
        session?.let {
            it.player.release()
            it.release()
        }
        session = null
        super.onDestroy()
    }
}

/** Media3 notification provider that renders our own notification (artwork background, progress, controls). */
class KaifsNotificationProvider(private val service: MusicService) : MediaNotification.Provider {
    override fun createNotification(
        mediaSession: MediaSession,
        customLayout: ImmutableList<CommandButton>,
        actionFactory: MediaNotification.ActionFactory,
        onNotificationChangedCallback: MediaNotification.Provider.Callback
    ): MediaNotification {
        return MediaNotification(MusicService.NOTIF_ID, service.buildNotification(mediaSession))
    }

    override fun handleCustomCommand(session: MediaSession, action: String, extras: Bundle): Boolean = false
}

// ---------- UI-side controller ----------

object MusicHub {
    private var appCtx: Context? = null

    fun customArtUri(key: String): Uri? {
        val c = appCtx ?: return null
        val f = CustomArt.file(c, key)
        return if (f.exists()) Uri.fromFile(f).buildUpon().appendQueryParameter("v", CustomArt.version.toString()).build() else null
    }

    /** Updates the artwork stored in the queue (so system media cards pick up the custom image) without restarting playback. */
    fun refreshArtwork(mediaId: String) {
        val c = controller ?: return
        for (i in 0 until c.mediaItemCount) {
            val old = c.getMediaItemAt(i)
            if (old.mediaId != mediaId) continue
            val orig = old.mediaMetadata.extras?.getString("albumArt")?.let { Uri.parse(it) }
            val art = customArtUri(mediaId) ?: orig
            val md = old.mediaMetadata.buildUpon().setArtworkUri(art).build()
            c.replaceMediaItem(i, old.buildUpon().setMediaMetadata(md).build())
        }
    }
    private var future: ListenableFuture<MediaController>? = null
    private var pending: (() -> Unit)? = null
    private val handler = Handler(Looper.getMainLooper())
    private var sleepRunnable: Runnable? = null

    var controller by mutableStateOf<MediaController?>(null)
    var current by mutableStateOf<MediaItem?>(null)
    var isPlaying by mutableStateOf(false)
    var posMs by mutableLongStateOf(0L)
    var durMs by mutableLongStateOf(0L)
    var shuffle by mutableStateOf(false)
    var repeat by mutableIntStateOf(Player.REPEAT_MODE_OFF)
    var queue by mutableStateOf<List<MediaItem>>(emptyList())
    var index by mutableIntStateOf(0)
    var speed by mutableFloatStateOf(1f)
    var sleepEnd by mutableLongStateOf(0L)

    fun init(ctx: Context) {
        if (future != null) return
        val app = ctx.applicationContext
        appCtx = app
        val token = SessionToken(app, ComponentName(app, MusicService::class.java))
        val f = MediaController.Builder(app, token).buildAsync()
        future = f
        f.addListener({
            val c = runCatching { f.get() }.getOrNull()
            if (c != null) attach(c)
        }, ContextCompat.getMainExecutor(app))
    }

    fun release() {
        future?.let { MediaController.releaseFuture(it) }
        future = null
        controller = null
    }

    private fun refreshQueue(c: MediaController) {
        queue = (0 until c.mediaItemCount).map { c.getMediaItemAt(it) }
    }

    private fun refresh(c: MediaController) {
        current = c.currentMediaItem
        isPlaying = c.isPlaying
        shuffle = c.shuffleModeEnabled
        repeat = c.repeatMode
        index = c.currentMediaItemIndex
        durMs = c.duration.coerceAtLeast(0)
        posMs = c.currentPosition.coerceAtLeast(0)
        speed = c.playbackParameters.speed
        refreshQueue(c)
    }

    private fun attach(c: MediaController) {
        controller = c
        c.addListener(object : Player.Listener {
            override fun onIsPlayingChanged(playing: Boolean) {
                isPlaying = playing
            }

            override fun onMediaItemTransition(mediaItem: MediaItem?, reason: Int) {
                current = mediaItem
                index = c.currentMediaItemIndex
                posMs = 0L
                durMs = c.duration.coerceAtLeast(0)
            }

            override fun onTimelineChanged(timeline: Timeline, reason: Int) {
                refreshQueue(c)
                index = c.currentMediaItemIndex
            }

            override fun onPlaybackStateChanged(playbackState: Int) {
                durMs = c.duration.coerceAtLeast(0)
            }

            override fun onShuffleModeEnabledChanged(shuffleModeEnabled: Boolean) {
                shuffle = shuffleModeEnabled
            }

            override fun onRepeatModeChanged(repeatMode: Int) {
                repeat = repeatMode
            }

            override fun onPlaybackParametersChanged(playbackParameters: PlaybackParameters) {
                speed = playbackParameters.speed
            }

            override fun onPlayerError(error: PlaybackException) {
                appCtx?.let {
                    Toast.makeText(it, "Can't play this audio file. Skipping to the next one.", Toast.LENGTH_SHORT).show()
                }
                if (c.hasNextMediaItem()) {
                    c.seekToNextMediaItem()
                    c.prepare()
                    c.play()
                }
            }
        })
        refresh(c)
        pending?.invoke()
        pending = null
    }

    fun tick() {
        val c = controller ?: return
        posMs = c.currentPosition.coerceAtLeast(0)
        durMs = c.duration.coerceAtLeast(0)
    }

    fun playList(items: List<MediaItem>, startIndex: Int, shuffleOn: Boolean = false) {
        if (items.isEmpty()) return
        val action = {
            val c = controller
            if (c != null) {
                c.shuffleModeEnabled = shuffleOn
                c.setMediaItems(items, startIndex.coerceIn(0, items.size - 1), 0L)
                c.prepare()
                c.play()
            }
        }
        if (controller != null) action() else pending = action
    }

    fun playSongs(songs: List<Song>, startIndex: Int, shuffleOn: Boolean = false) {
        playList(songs.map { it.toMediaItem() }, startIndex, shuffleOn)
    }

    fun playAt(i: Int) {
        val c = controller ?: return
        c.seekToDefaultPosition(i)
        c.play()
    }

    fun toggle() {
        val c = controller ?: return
        if (c.isPlaying) c.pause() else c.play()
    }

    fun pause() {
        controller?.pause()
    }

    fun next() {
        controller?.seekToNextMediaItem()
    }

    fun prev() {
        val c = controller ?: return
        if (c.currentPosition > 3000) c.seekTo(0L) else c.seekToPreviousMediaItem()
    }

    fun seekTo(ms: Long) {
        controller?.seekTo(ms)
        posMs = ms
    }

    fun toggleShuffle() {
        val c = controller ?: return
        c.shuffleModeEnabled = !c.shuffleModeEnabled
    }

    fun toggleRepeat() {
        val c = controller ?: return
        c.repeatMode = when (c.repeatMode) {
            Player.REPEAT_MODE_OFF -> Player.REPEAT_MODE_ALL
            Player.REPEAT_MODE_ALL -> Player.REPEAT_MODE_ONE
            else -> Player.REPEAT_MODE_OFF
        }
    }

    fun changeSpeed(s: Float) {
        controller?.setPlaybackSpeed(s)
        speed = s
    }

    fun setSleep(minutes: Int) {
        sleepRunnable?.let { handler.removeCallbacks(it) }
        sleepRunnable = null
        sleepEnd = 0L
        if (minutes > 0) {
            val r = Runnable {
                controller?.pause()
                sleepEnd = 0L
            }
            sleepRunnable = r
            sleepEnd = System.currentTimeMillis() + minutes * 60_000L
            handler.postDelayed(r, minutes * 60_000L)
        }
    }
}
