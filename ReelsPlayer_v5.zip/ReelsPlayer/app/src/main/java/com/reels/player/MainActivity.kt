@file:OptIn(
    androidx.media3.common.util.UnstableApi::class,
    androidx.compose.foundation.ExperimentalFoundationApi::class
)

package com.reels.player

import android.Manifest
import android.content.ContentUris
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.MediaStore
import android.util.LruCache
import android.util.Size
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.Spring
import androidx.compose.animation.core.spring
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.scaleIn
import androidx.compose.animation.scaleOut
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectHorizontalDragGestures
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.lazy.grid.itemsIndexed
import androidx.compose.foundation.pager.VerticalPager
import androidx.compose.foundation.pager.rememberPagerState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Button
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.key
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableLongStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.ImageBitmap
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.hapticfeedback.HapticFeedbackType
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalHapticFeedback
import androidx.compose.ui.platform.LocalLifecycleOwner
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.IntOffset
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.core.content.ContextCompat
import androidx.core.view.WindowCompat
import androidx.core.view.WindowInsetsCompat
import androidx.core.view.WindowInsetsControllerCompat
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.LifecycleEventObserver
import androidx.media3.common.MediaItem
import androidx.media3.common.Player
import androidx.media3.common.VideoSize
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.ui.AspectRatioFrameLayout
import androidx.media3.ui.PlayerView
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.withContext
import kotlinx.coroutines.withTimeoutOrNull

// ---------- Data ----------

data class Video(
    val id: Long,
    val uri: Uri,
    val name: String,
    val folder: String,
    val durationMs: Long,
    val sizeBytes: Long,
    val added: Long
)

data class FolderItem(val key: String, val title: String, val videos: List<Video>)

sealed class Screen {
    data class Reels(val list: List<Video>, val start: Int, val fromBrowse: Boolean) : Screen()
    object Browse : Screen()
}

const val ALL_KEY = "__all__"
val Accent = Color(0xFFE1306C)
val LikeRed = Color(0xFFFF3B5C)
val Bg = Color(0xFF0B0B0F)
val CardBg = Color(0xFF1C1C22)
val sortNames = listOf("Newest", "Oldest", "Name", "Longest")

fun sortVideos(l: List<Video>, mode: Int): List<Video> = when (mode) {
    0 -> l.sortedByDescending { it.added }
    1 -> l.sortedBy { it.added }
    2 -> l.sortedBy { it.name.lowercase() }
    else -> l.sortedByDescending { it.durationMs }
}

fun fmt(ms: Long): String {
    val s = (ms / 1000).coerceAtLeast(0)
    val h = s / 3600
    val m = (s % 3600) / 60
    val sec = s % 60
    return if (h > 0) "%d:%02d:%02d".format(h, m, sec) else "%d:%02d".format(m, sec)
}

fun loadVideos(ctx: Context): List<Video> {
    val list = mutableListOf<Video>()
    val collection = MediaStore.Video.Media.EXTERNAL_CONTENT_URI
    val projection = arrayOf(
        MediaStore.Video.Media._ID,
        MediaStore.Video.Media.DISPLAY_NAME,
        MediaStore.Video.Media.BUCKET_DISPLAY_NAME,
        MediaStore.Video.Media.DURATION,
        MediaStore.Video.Media.SIZE,
        MediaStore.Video.Media.DATE_ADDED
    )
    ctx.contentResolver.query(
        collection, projection, null, null, "${MediaStore.Video.Media.DATE_ADDED} DESC"
    )?.use { c ->
        val idCol = c.getColumnIndexOrThrow(MediaStore.Video.Media._ID)
        val nameCol = c.getColumnIndexOrThrow(MediaStore.Video.Media.DISPLAY_NAME)
        val folderCol = c.getColumnIndexOrThrow(MediaStore.Video.Media.BUCKET_DISPLAY_NAME)
        val durCol = c.getColumnIndexOrThrow(MediaStore.Video.Media.DURATION)
        val sizeCol = c.getColumnIndexOrThrow(MediaStore.Video.Media.SIZE)
        val addCol = c.getColumnIndexOrThrow(MediaStore.Video.Media.DATE_ADDED)
        while (c.moveToNext()) {
            val id = c.getLong(idCol)
            list += Video(
                id = id,
                uri = ContentUris.withAppendedId(collection, id),
                name = c.getString(nameCol) ?: "",
                folder = c.getString(folderCol) ?: "Other",
                durationMs = c.getLong(durCol),
                sizeBytes = c.getLong(sizeCol),
                added = c.getLong(addCol)
            )
        }
    }
    return list
}

// ---------- Thumbnails ----------

val thumbCache = LruCache<String, ImageBitmap>(150)

@Suppress("DEPRECATION")
suspend fun loadThumb(ctx: Context, v: Video, w: Int, h: Int): ImageBitmap? {
    val k = "${v.id}_${w}x$h"
    val cached = thumbCache.get(k)
    if (cached != null) return cached
    val bmp = withContext(Dispatchers.IO) {
        runCatching {
            if (Build.VERSION.SDK_INT >= 29) {
                ctx.contentResolver.loadThumbnail(v.uri, Size(w, h), null)
            } else {
                MediaStore.Video.Thumbnails.getThumbnail(
                    ctx.contentResolver, v.id, MediaStore.Video.Thumbnails.MINI_KIND, null
                )
            }
        }.getOrNull()
    }?.asImageBitmap()
    if (bmp != null) thumbCache.put(k, bmp)
    return bmp
}

@Composable
fun Thumb(video: Video, w: Int, h: Int, modifier: Modifier) {
    val ctx = LocalContext.current
    var bmp by remember(video.id) { mutableStateOf<ImageBitmap?>(thumbCache.get("${video.id}_${w}x$h")) }
    LaunchedEffect(video.id) {
        if (bmp == null) bmp = loadThumb(ctx, video, w, h)
    }
    Box(modifier.background(CardBg)) {
        bmp?.let {
            Image(
                bitmap = it,
                contentDescription = null,
                contentScale = ContentScale.Crop,
                modifier = Modifier.fillMaxSize()
            )
        }
    }
}

// ---------- Small UI pieces ----------

@Composable
fun Ic(res: Int, size: Dp = 24.dp, tint: Color = Color.White, modifier: Modifier = Modifier) {
    Icon(
        painter = painterResource(res),
        contentDescription = null,
        tint = tint,
        modifier = modifier.size(size)
    )
}

@Composable
fun CircleBtn(res: Int, onClick: () -> Unit, modifier: Modifier = Modifier, size: Dp = 42.dp) {
    Box(
        modifier
            .size(size)
            .clip(CircleShape)
            .background(Color.Black.copy(alpha = 0.35f))
            .clickable(onClick = onClick),
        contentAlignment = Alignment.Center
    ) {
        Ic(res, 22.dp)
    }
}

@Composable
fun ActionButton(
    res: Int,
    label: String,
    tint: Color = Color.White,
    scale: Float = 1f,
    onClick: () -> Unit
) {
    Column(
        horizontalAlignment = Alignment.CenterHorizontally,
        modifier = Modifier.padding(vertical = 8.dp).clickable(onClick = onClick)
    ) {
        Box(
            Modifier.size(50.dp).clip(CircleShape).background(Color.Black.copy(alpha = 0.32f)),
            contentAlignment = Alignment.Center
        ) {
            Ic(res, 26.dp, tint, Modifier.graphicsLayer { scaleX = scale; scaleY = scale })
        }
        Text(label, color = Color.White, fontSize = 11.sp, modifier = Modifier.padding(top = 3.dp))
    }
}

@Composable
fun CenterMessage(iconRes: Int, title: String, text: String, button: String?, onClick: () -> Unit) {
    Column(horizontalAlignment = Alignment.CenterHorizontally, modifier = Modifier.padding(32.dp)) {
        Ic(iconRes, 72.dp, Accent)
        Text(title, color = Color.White, fontSize = 22.sp, fontWeight = FontWeight.Bold, modifier = Modifier.padding(top = 12.dp))
        Text(text, color = Color.White.copy(alpha = 0.7f), textAlign = TextAlign.Center, modifier = Modifier.padding(top = 8.dp))
        if (button != null) {
            Button(onClick = onClick, modifier = Modifier.padding(top = 20.dp)) { Text(button) }
        }
    }
}

// ---------- Activity / App ----------

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        WindowCompat.setDecorFitsSystemWindows(window, false)
        WindowInsetsControllerCompat(window, window.decorView).apply {
            systemBarsBehavior = WindowInsetsControllerCompat.BEHAVIOR_SHOW_TRANSIENT_BARS_BY_SWIPE
            hide(WindowInsetsCompat.Type.systemBars())
        }
        setContent {
            MaterialTheme(colorScheme = darkColorScheme(primary = Accent)) {
                App()
            }
        }
    }
}

@Composable
fun App() {
    val ctx = LocalContext.current
    val perm = if (Build.VERSION.SDK_INT >= 33)
        Manifest.permission.READ_MEDIA_VIDEO else Manifest.permission.READ_EXTERNAL_STORAGE

    var granted by remember {
        mutableStateOf(ContextCompat.checkSelfPermission(ctx, perm) == PackageManager.PERMISSION_GRANTED)
    }
    val launcher = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) {
        granted = it
    }
    var videos by remember { mutableStateOf<List<Video>?>(null) }

    LaunchedEffect(Unit) { if (!granted) launcher.launch(perm) }
    LaunchedEffect(granted) {
        if (granted) videos = withContext(Dispatchers.IO) { loadVideos(ctx) }
    }

    Box(Modifier.fillMaxSize().background(Color.Black), contentAlignment = Alignment.Center) {
        val list = videos
        when {
            !granted -> CenterMessage(
                R.drawable.ic_video, "Reels Player",
                "Apni phone ki videos dekhne ke liye permission chahiye",
                "Permission do"
            ) { launcher.launch(perm) }
            list == null -> Text("Loading...", color = Color.White.copy(alpha = 0.7f))
            list.isEmpty() -> CenterMessage(
                R.drawable.ic_folder, "Koi video nahi mili",
                "Phone me video save karke dobara kholo", null
            ) { }
            else -> Main(list)
        }
    }
}

fun lastIndex(ctx: Context, all: List<Video>): Int {
    val last = ctx.getSharedPreferences("reels", Context.MODE_PRIVATE).getString("last", null)
    return all.indexOfFirst { it.uri.toString() == last }.coerceAtLeast(0)
}

@Composable
fun Main(all: List<Video>) {
    val ctx = LocalContext.current
    var screen by remember { mutableStateOf<Screen>(Screen.Reels(all, lastIndex(ctx, all), false)) }
    var folder by remember { mutableStateOf<String?>(null) }
    var sort by remember { mutableIntStateOf(0) }

    val s = screen
    when (s) {
        is Screen.Reels -> {
            BackHandler(enabled = s.fromBrowse) { screen = Screen.Browse }
            key(s) {
                ReelsScreen(
                    videos = s.list,
                    startIndex = s.start,
                    rememberLast = !s.fromBrowse,
                    onBrowse = { screen = Screen.Browse },
                    onBack = if (s.fromBrowse) ({ screen = Screen.Browse }) else null
                )
            }
        }
        is Screen.Browse -> {
            BackHandler(enabled = folder != null) { folder = null }
            BackHandler(enabled = folder == null) {
                screen = Screen.Reels(all, lastIndex(ctx, all), false)
            }
            BrowseScreen(
                all = all,
                folder = folder,
                sort = sort,
                onFolder = { folder = it },
                onSort = { sort = (sort + 1) % sortNames.size },
                onPlay = { list, idx -> screen = Screen.Reels(list, idx, true) },
                onClose = { screen = Screen.Reels(all, lastIndex(ctx, all), false) }
            )
        }
    }
}

// ---------- Browse ----------

@Composable
fun BrowseScreen(
    all: List<Video>,
    folder: String?,
    sort: Int,
    onFolder: (String?) -> Unit,
    onSort: () -> Unit,
    onPlay: (List<Video>, Int) -> Unit,
    onClose: () -> Unit
) {
    val folderItems = remember(all) {
        listOf(FolderItem(ALL_KEY, "All videos", all)) +
            all.groupBy { it.folder }
                .map { FolderItem(it.key, it.key, it.value) }
                .sortedBy { it.title.lowercase() }
    }
    val videoList = remember(all, folder, sort) {
        if (folder == null) emptyList()
        else sortVideos(if (folder == ALL_KEY) all else all.filter { it.folder == folder }, sort)
    }
    val title = when (folder) {
        null -> "Browse"
        ALL_KEY -> "All videos"
        else -> folder ?: ""
    }
    val subtitle = if (folder == null) "${folderItems.size - 1} folders  •  ${all.size} videos"
    else "${videoList.size} videos"

    Column(Modifier.fillMaxSize().background(Bg)) {
        Row(
            Modifier.fillMaxWidth().padding(start = 12.dp, end = 12.dp, top = 32.dp, bottom = 12.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            CircleBtn(R.drawable.ic_back, onClick = { if (folder != null) onFolder(null) else onClose() })
            Column(Modifier.weight(1f).padding(horizontal = 12.dp)) {
                Text(title, color = Color.White, fontSize = 22.sp, fontWeight = FontWeight.Bold, maxLines = 1, overflow = TextOverflow.Ellipsis)
                Text(subtitle, color = Color.White.copy(alpha = 0.6f), fontSize = 13.sp)
            }
            if (folder != null) {
                Row(
                    Modifier.clip(RoundedCornerShape(20.dp)).background(CardBg)
                        .clickable(onClick = onSort)
                        .padding(horizontal = 12.dp, vertical = 8.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Ic(R.drawable.ic_sort, 18.dp)
                    Spacer(Modifier.width(6.dp))
                    Text(sortNames[sort], color = Color.White, fontSize = 13.sp)
                }
            }
        }

        if (folder == null) {
            LazyVerticalGrid(
                columns = GridCells.Fixed(2),
                contentPadding = PaddingValues(12.dp),
                horizontalArrangement = Arrangement.spacedBy(10.dp),
                verticalArrangement = Arrangement.spacedBy(10.dp),
                modifier = Modifier.fillMaxSize()
            ) {
                items(folderItems) { f ->
                    Box(
                        Modifier.fillMaxWidth().aspectRatio(1.25f)
                            .clip(RoundedCornerShape(14.dp))
                            .background(CardBg)
                            .clickable { onFolder(f.key) }
                    ) {
                        Thumb(f.videos.first(), 360, 288, Modifier.fillMaxSize())
                        Box(
                            Modifier.fillMaxSize().background(
                                Brush.verticalGradient(listOf(Color.Transparent, Color.Black.copy(alpha = 0.78f)))
                            )
                        )
                        Column(Modifier.align(Alignment.BottomStart).padding(10.dp)) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Ic(R.drawable.ic_folder, 16.dp, Accent)
                                Spacer(Modifier.width(6.dp))
                                Text(f.title, color = Color.White, fontSize = 14.sp, fontWeight = FontWeight.SemiBold, maxLines = 1, overflow = TextOverflow.Ellipsis)
                            }
                            Text("${f.videos.size} videos", color = Color.White.copy(alpha = 0.7f), fontSize = 12.sp)
                        }
                    }
                }
            }
        } else {
            LazyVerticalGrid(
                columns = GridCells.Fixed(3),
                contentPadding = PaddingValues(8.dp),
                horizontalArrangement = Arrangement.spacedBy(6.dp),
                verticalArrangement = Arrangement.spacedBy(6.dp),
                modifier = Modifier.fillMaxSize()
            ) {
                itemsIndexed(videoList) { idx, v ->
                    Box(
                        Modifier.fillMaxWidth().aspectRatio(0.62f)
                            .clip(RoundedCornerShape(10.dp))
                            .background(CardBg)
                            .clickable { onPlay(videoList, idx) }
                    ) {
                        Thumb(v, 300, 480, Modifier.fillMaxSize())
                        Box(
                            Modifier.align(Alignment.BottomCenter).fillMaxWidth().height(70.dp).background(
                                Brush.verticalGradient(listOf(Color.Transparent, Color.Black.copy(alpha = 0.8f)))
                            )
                        )
                        Text(
                            fmt(v.durationMs),
                            color = Color.White,
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Medium,
                            modifier = Modifier.align(Alignment.TopEnd).padding(6.dp)
                                .background(Color.Black.copy(alpha = 0.6f), RoundedCornerShape(6.dp))
                                .padding(horizontal = 5.dp, vertical = 2.dp)
                        )
                        Text(
                            v.name.substringBeforeLast('.'),
                            color = Color.White,
                            fontSize = 11.sp,
                            maxLines = 2,
                            overflow = TextOverflow.Ellipsis,
                            modifier = Modifier.align(Alignment.BottomStart).padding(6.dp)
                        )
                    }
                }
            }
        }
    }
}

// ---------- Reels ----------

@Composable
fun ReelsScreen(
    videos: List<Video>,
    startIndex: Int,
    rememberLast: Boolean,
    onBrowse: () -> Unit,
    onBack: (() -> Unit)?
) {
    val ctx = LocalContext.current
    val haptic = LocalHapticFeedback.current
    val prefs = remember { ctx.getSharedPreferences("reels", Context.MODE_PRIVATE) }

    var liked by remember { mutableStateOf(prefs.getStringSet("liked", emptySet())!!.toSet()) }
    var muted by remember { mutableStateOf(prefs.getBoolean("muted", false)) }
    var portrait by remember { mutableStateOf(true) }
    var userPaused by remember { mutableStateOf(false) }
    var fast by remember { mutableStateOf(false) }
    var posMs by remember { mutableLongStateOf(0L) }
    var durMs by remember { mutableLongStateOf(0L) }
    var seeking by remember { mutableStateOf(false) }

    fun setLiked(key: String, on: Boolean) {
        liked = if (on) liked + key else liked - key
        prefs.edit().putStringSet("liked", liked.toSet()).apply()
    }

    val exo = remember {
        ExoPlayer.Builder(ctx).build().apply {
            repeatMode = Player.REPEAT_MODE_ONE
            playWhenReady = true
        }
    }

    DisposableEffect(exo) {
        val l = object : Player.Listener {
            override fun onVideoSizeChanged(videoSize: VideoSize) {
                portrait = videoSize.height >= videoSize.width
            }
        }
        exo.addListener(l)
        onDispose {
            exo.removeListener(l)
            exo.release()
        }
    }

    val owner = LocalLifecycleOwner.current
    DisposableEffect(owner) {
        val obs = LifecycleEventObserver { _, e ->
            if (e == Lifecycle.Event.ON_PAUSE) {
                exo.pause()
            }
            if (e == Lifecycle.Event.ON_RESUME && !userPaused) {
                exo.play()
            }
        }
        owner.lifecycle.addObserver(obs)
        onDispose { owner.lifecycle.removeObserver(obs) }
    }

    val pager = rememberPagerState(initialPage = startIndex.coerceIn(0, videos.size - 1)) { videos.size }

    LaunchedEffect(pager.settledPage) {
        val v = videos[pager.settledPage]
        if (rememberLast) prefs.edit().putString("last", v.uri.toString()).apply()
        userPaused = false
        fast = false
        posMs = 0L
        exo.setPlaybackSpeed(1f)
        exo.setMediaItem(MediaItem.fromUri(v.uri))
        exo.prepare()
        exo.play()
    }
    LaunchedEffect(muted) {
        exo.volume = if (muted) 0f else 1f
        prefs.edit().putBoolean("muted", muted).apply()
    }
    LaunchedEffect(Unit) {
        while (true) {
            posMs = exo.currentPosition.coerceAtLeast(0)
            durMs = exo.duration.coerceAtLeast(0)
            delay(100)
        }
    }

    val current = videos[pager.settledPage]
    val totalMs = if (durMs > 0) durMs else current.durationMs
    val progress = if (totalMs > 0) (posMs.toFloat() / totalMs).coerceIn(0f, 1f) else 0f

    fun seekFraction(f: Float) {
        val d = exo.duration
        if (d > 0) {
            val t = (d * f.coerceIn(0f, 1f)).toLong()
            exo.seekTo(t)
            posMs = t
        }
    }

    Box(Modifier.fillMaxSize().background(Color.Black)) {
        VerticalPager(state = pager, modifier = Modifier.fillMaxSize()) { page ->
            val video = videos[page]
            val key = video.uri.toString()
            val isCurrent = page == pager.settledPage
            val isLiked = key in liked

            var heartTick by remember { mutableIntStateOf(0) }
            var showHeart by remember { mutableStateOf(false) }
            var heartPos by remember { mutableStateOf(Offset.Zero) }
            var thumb by remember(key) { mutableStateOf<ImageBitmap?>(null) }
            val likeScale = remember { Animatable(1f) }

            LaunchedEffect(heartTick) {
                if (heartTick > 0) {
                    showHeart = true
                    delay(700)
                    showHeart = false
                }
            }
            LaunchedEffect(isLiked) {
                if (isLiked) {
                    likeScale.animateTo(1.35f, tween(120))
                    likeScale.animateTo(1f, spring(Spring.DampingRatioMediumBouncy))
                }
            }
            LaunchedEffect(key) {
                thumb = loadThumb(ctx, video, 540, 960)
            }

            Box(Modifier.fillMaxSize().background(Color.Black)) {
                thumb?.let {
                    Image(
                        bitmap = it,
                        contentDescription = null,
                        contentScale = if (it.height >= it.width) ContentScale.Crop else ContentScale.Fit,
                        modifier = Modifier.fillMaxSize()
                    )
                }

                if (isCurrent) {
                    AndroidView(
                        factory = { c ->
                            PlayerView(c).apply {
                                useController = false
                                keepScreenOn = true
                                setShutterBackgroundColor(android.graphics.Color.TRANSPARENT)
                                player = exo
                            }
                        },
                        update = {
                            it.resizeMode = if (portrait) AspectRatioFrameLayout.RESIZE_MODE_ZOOM
                            else AspectRatioFrameLayout.RESIZE_MODE_FIT
                        },
                        modifier = Modifier.fillMaxSize()
                    )
                }

                // Scrims for readable text
                Box(
                    Modifier.align(Alignment.BottomCenter).fillMaxWidth().height(300.dp)
                        .background(Brush.verticalGradient(listOf(Color.Transparent, Color.Black.copy(alpha = 0.75f))))
                )
                Box(
                    Modifier.align(Alignment.TopCenter).fillMaxWidth().height(150.dp)
                        .background(Brush.verticalGradient(listOf(Color.Black.copy(alpha = 0.6f), Color.Transparent)))
                )

                // Gestures: tap = pause/play, hold = 2x speed, double tap = like
                Box(
                    Modifier.fillMaxSize().pointerInput(page, isCurrent) {
                        detectTapGestures(
                            onPress = {
                                val released = withTimeoutOrNull(300) { tryAwaitRelease(); true }
                                if (released == null && isCurrent && !userPaused) {
                                    exo.setPlaybackSpeed(2f)
                                    fast = true
                                    tryAwaitRelease()
                                    exo.setPlaybackSpeed(1f)
                                    fast = false
                                }
                            },
                            onLongPress = { },
                            onTap = {
                                if (isCurrent) {
                                    if (userPaused) { exo.play(); userPaused = false }
                                    else { exo.pause(); userPaused = true }
                                }
                            },
                            onDoubleTap = { off ->
                                if (!isLiked) {
                                    setLiked(key, true)
                                    haptic.performHapticFeedback(HapticFeedbackType.LongPress)
                                }
                                heartPos = off
                                heartTick++
                            }
                        )
                    }
                )

                AnimatedVisibility(
                    visible = showHeart,
                    enter = scaleIn(spring(Spring.DampingRatioMediumBouncy)) + fadeIn(),
                    exit = fadeOut() + scaleOut(),
                    modifier = Modifier.offset {
                        IntOffset((heartPos.x - 45.dp.toPx()).toInt(), (heartPos.y - 55.dp.toPx()).toInt())
                    }
                ) {
                    Ic(R.drawable.ic_heart, 90.dp, LikeRed)
                }

                if (isCurrent && userPaused) {
                    Box(
                        Modifier.align(Alignment.Center).size(76.dp).clip(CircleShape)
                            .background(Color.Black.copy(alpha = 0.45f)),
                        contentAlignment = Alignment.Center
                    ) {
                        Ic(R.drawable.ic_play, 44.dp)
                    }
                }

                // Right side actions
                Column(
                    modifier = Modifier.align(Alignment.BottomEnd).padding(end = 12.dp, bottom = 84.dp),
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    ActionButton(
                        res = if (isLiked) R.drawable.ic_heart else R.drawable.ic_heart_outline,
                        label = if (isLiked) "Liked" else "Like",
                        tint = if (isLiked) LikeRed else Color.White,
                        scale = likeScale.value
                    ) { setLiked(key, !isLiked) }
                    ActionButton(
                        res = if (muted) R.drawable.ic_volume_off else R.drawable.ic_volume_on,
                        label = if (muted) "Unmute" else "Mute"
                    ) { muted = !muted }
                    ActionButton(res = R.drawable.ic_share, label = "Share") {
                        val i = Intent(Intent.ACTION_SEND).apply {
                            type = "video/*"
                            putExtra(Intent.EXTRA_STREAM, video.uri)
                            addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
                        }
                        ctx.startActivity(Intent.createChooser(i, "Share video"))
                    }
                }

                // Caption
                Column(
                    Modifier.align(Alignment.BottomStart).padding(start = 16.dp, end = 86.dp, bottom = 80.dp)
                ) {
                    Text(
                        video.name.substringBeforeLast('.'),
                        color = Color.White,
                        fontSize = 15.sp,
                        fontWeight = FontWeight.SemiBold,
                        maxLines = 2,
                        overflow = TextOverflow.Ellipsis
                    )
                    Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.padding(top = 4.dp)) {
                        Ic(R.drawable.ic_folder, 14.dp, Color.White.copy(alpha = 0.75f))
                        Spacer(Modifier.width(4.dp))
                        Text(
                            video.folder,
                            color = Color.White.copy(alpha = 0.75f),
                            fontSize = 12.sp,
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis
                        )
                    }
                }
            }
        }

        // Fixed header
        Row(
            Modifier.align(Alignment.TopCenter).fillMaxWidth().padding(start = 12.dp, end = 12.dp, top = 28.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            if (onBack != null) {
                CircleBtn(R.drawable.ic_back, onClick = onBack)
                Spacer(Modifier.width(10.dp))
            }
            Text("Reels", color = Color.White, fontSize = 26.sp, fontWeight = FontWeight.Bold, modifier = Modifier.weight(1f))
            Text("${pager.currentPage + 1} / ${videos.size}", color = Color.White.copy(alpha = 0.85f), fontSize = 14.sp)
            Spacer(Modifier.width(10.dp))
            CircleBtn(R.drawable.ic_apps, onClick = onBrowse)
        }

        // 2x speed badge
        if (fast) {
            Row(
                Modifier.align(Alignment.TopCenter).padding(top = 88.dp)
                    .background(Color.Black.copy(alpha = 0.55f), RoundedCornerShape(20.dp))
                    .padding(horizontal = 14.dp, vertical = 6.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Ic(R.drawable.ic_fast_forward, 18.dp)
                Spacer(Modifier.width(6.dp))
                Text("2x", color = Color.White, fontSize = 14.sp, fontWeight = FontWeight.Bold)
            }
        }

        // Time while seeking
        if (seeking) {
            Box(
                Modifier.align(Alignment.Center)
                    .background(Color.Black.copy(alpha = 0.55f), RoundedCornerShape(12.dp))
                    .padding(horizontal = 18.dp, vertical = 10.dp)
            ) {
                Text("${fmt(posMs)} / ${fmt(totalMs)}", color = Color.White, fontSize = 20.sp, fontWeight = FontWeight.Medium)
            }
        }

        // Elapsed / total time
        Text(
            "${fmt(posMs)} / ${fmt(totalMs)}",
            color = Color.White,
            fontSize = 12.sp,
            fontWeight = FontWeight.Medium,
            modifier = Modifier.align(Alignment.BottomStart).padding(start = 16.dp, bottom = 44.dp)
                .background(Color.Black.copy(alpha = 0.45f), RoundedCornerShape(8.dp))
                .padding(horizontal = 8.dp, vertical = 3.dp)
        )

        // Seekable progress bar (tap or drag)
        Box(
            Modifier.align(Alignment.BottomCenter).fillMaxWidth().height(34.dp)
                .pointerInput(Unit) {
                    detectTapGestures { o -> seekFraction(o.x / size.width) }
                }
                .pointerInput(Unit) {
                    detectHorizontalDragGestures(
                        onDragStart = { seeking = true },
                        onDragEnd = { seeking = false },
                        onDragCancel = { seeking = false }
                    ) { change, _ ->
                        change.consume()
                        seekFraction(change.position.x / size.width)
                    }
                }
        ) {
            val h = if (seeking) 7.dp else 3.dp
            Box(Modifier.align(Alignment.BottomStart).padding(bottom = 4.dp).fillMaxWidth().height(h).background(Color.White.copy(alpha = 0.3f)))
            Box(Modifier.align(Alignment.BottomStart).padding(bottom = 4.dp).fillMaxWidth(progress).height(h).background(Accent))
        }
    }
}
