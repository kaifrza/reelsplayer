@file:OptIn(androidx.media3.common.util.UnstableApi::class)

package com.reels.player

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.graphics.Bitmap
import android.os.Build
import android.os.Bundle
import android.util.LruCache
import android.util.Size
import androidx.core.app.NotificationCompat
import androidx.core.app.NotificationManagerCompat
import androidx.core.app.ServiceCompat
import androidx.media3.session.CommandButton
import androidx.media3.session.MediaNotification
import androidx.media3.session.MediaStyleNotificationHelper
import com.google.common.collect.ImmutableList
import java.util.concurrent.Executors
import android.content.ComponentName
import android.content.ContentUris
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.os.Handler
import android.os.Looper
import android.provider.MediaStore
import android.widget.Toast
import androidx.compose.runtime.Immutable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableLongStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.core.content.ContextCompat
import androidx.media3.common.AudioAttributes
import androidx.media3.common.C
import androidx.media3.common.MediaItem
import androidx.media3.common.MediaMetadata
import androidx.media3.common.PlaybackException
import androidx.media3.common.PlaybackParameters
import androidx.media3.common.Player
import androidx.media3.common.Timeline
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.session.DefaultMediaNotificationProvider
import androidx.media3.session.MediaController
import androidx.media3.session.MediaSession
import androidx.media3.session.MediaSessionService
import androidx.media3.session.SessionToken
import com.google.common.util.concurrent.ListenableFuture
import java.io.File

// ---------- Data ----------

@Immutable
data class Song(
    val id: Long,
    val uri: Uri,
    val title: String,
    val artist: String,
    val album: String,
    val albumId: Long,
    val durationMs: Long,
    val added: Long
)

val audioExts = setOf(
    "mp3", "m4a", "aac", "flac", "wav", "ogg", "oga", "opus", "amr", "awb", "mka",
    "ac3", "eac3", "wma", "mid", "midi", "3ga", "ape", "dts", "aiff", "aif", "m4b"
)

fun isAudioFile(f: File): Boolean = f.extension.lowercase() in audioExts

fun fileSong(f: File): Song = Song(
    id = f.absolutePath.hashCode().toLong(),
    uri = Uri.fromFile(f),
    title = f.nameWithoutExtension,
    artist = "Unknown artist",
    album = f.parentFile?.name ?: "",
    albumId = 0L,
    durationMs = 0L,
    added = f.lastModified() / 1000
)

fun loadSongs(ctx: Context, includeAll: Boolean): List<Song> {
    val out = mutableListOf<Song>()
    val coll = MediaStore.Audio.Media.EXTERNAL_CONTENT_URI
    val proj = arrayOf(
        MediaStore.Audio.Media._ID,
        MediaStore.Audio.Media.TITLE,
        MediaStore.Audio.Media.ARTIST,
        MediaStore.Audio.Media.ALBUM,
        MediaStore.Audio.Media.ALBUM_ID,
        MediaStore.Audio.Media.DURATION,
        MediaStore.Audio.Media.DATE_ADDED
    )
    val sel = if (includeAll) "${MediaStore.Audio.Media.DURATION} >= 3000"
    else "${MediaStore.Audio.Media.IS_MUSIC} != 0 AND ${MediaStore.Audio.Media.DURATION} >= 3000"
    ctx.contentResolver.query(coll, proj, sel, null, null)?.use { c ->
        val idCol = c.getColumnIndexOrThrow(MediaStore.Audio.Media._ID)
        val titleCol = c.getColumnIndexOrThrow(MediaStore.Audio.Media.TITLE)
        val artistCol = c.getColumnIndexOrThrow(MediaStore.Audio.Media.ARTIST)
        val albumCol = c.getColumnIndexOrThrow(MediaStore.Audio.Media.ALBUM)
        val albumIdCol = c.getColumnIndexOrThrow(MediaStore.Audio.Media.ALBUM_ID)
        val durCol = c.getColumnIndexOrThrow(MediaStore.Audio.Media.DURATION)
        val addCol = c.getColumnIndexOrThrow(MediaStore.Audio.Media.DATE_ADDED)
        while (c.moveToNext()) {
            val id = c.getLong(idCol)
            val artist = c.getString(artistCol)?.takeIf { it != "<unknown>" } ?: "Unknown artist"
            val album = c.getString(albumCol)?.takeIf { it != "<unknown>" } ?: "Unknown album"
            out += Song(
                id = id,
                uri = ContentUris.withAppendedId(coll, id),
                title = c.getString(titleCol) ?: "Unknown",
                artist = artist,
                album = album,
                albumId = c.getLong(albumIdCol),
                durationMs = c.getLong(durCol),
                added = c.getLong(addCol)
            )
        }
    }
    return out.sortedBy { it.title.lowercase() }
}

fun Song.toMediaItem(): MediaItem {
    val art: Uri? = if (albumId > 0L) {
        ContentUris.withAppendedId(Uri.parse("content://media/external/audio/albumart"), albumId)
    } else null
    return MediaItem.Builder()
        .setUri(uri)
        .setMediaId(id.toString())
        .setMediaMetadata(
            MediaMetadata.Builder()
                .setTitle(title)
                .setArtist(artist)
                .setAlbumTitle(album)
                .setArtworkUri(art)
                .build()
        )
        .build()
}

// ---------- Service (owns the player + media notification) ----------

fun artBitmap(ctx: Context, uri: Uri, px: Int): Bitmap? {
    var b: Bitmap? = null
    if (uri.scheme == "content" && Build.VERSION.SDK_INT >= 29) {
        b = runCatching { ctx.contentResolver.loadThumbnail(uri, Size(px, px), null) }.getOrNull()
    }
    if (b == null) b = runCatching { embeddedArt(ctx, uri) }.getOrNull()
    return b
}

class MusicService : MediaSessionService() {
    companion object {
        const val NOTIF_ID = 1101
        const val CHANNEL = "kaifs_music"
        const val ACTION_PREV = "com.reels.player.PREV"
        const val ACTION_TOGGLE = "com.reels.player.TOGGLE"
        const val ACTION_NEXT = "com.reels.player.NEXT"
        const val ACTION_STOP = "com.reels.player.STOP"
    }

    private var session: MediaSession? = null
    private val handler = Handler(Looper.getMainLooper())
    private val artCache = LruCache<String, Bitmap>(6)
    private val artExecutor = Executors.newSingleThreadExecutor()
    private var artRequested: String? = null

    private val ticker = object : Runnable {
        override fun run() {
            refreshNotification()
            handler.postDelayed(this, 1000L)
        }
    }

    override fun onCreate() {
        super.onCreate()
        if (Build.VERSION.SDK_INT >= 26) {
            val ch = NotificationChannel(CHANNEL, "Music playback", NotificationManager.IMPORTANCE_LOW)
            ch.setShowBadge(false)
            (getSystemService(NOTIFICATION_SERVICE) as NotificationManager).createNotificationChannel(ch)
        }
        val player = ExoPlayer.Builder(this)
            .setAudioAttributes(
                AudioAttributes.Builder()
                    .setUsage(C.USAGE_MEDIA)
                    .setContentType(C.AUDIO_CONTENT_TYPE_MUSIC)
                    .build(),
                true
            )
            .setHandleAudioBecomingNoisy(true)
            .setWakeMode(C.WAKE_MODE_LOCAL)
            .build()
        player.addListener(object : Player.Listener {
            override fun onIsPlayingChanged(isPlaying: Boolean) {
                handler.removeCallbacks(ticker)
                if (isPlaying) handler.postDelayed(ticker, 1000L) else refreshNotification()
            }

            override fun onMediaItemTransition(mediaItem: MediaItem?, reason: Int) {
                refreshNotification()
            }
        })
        session = MediaSession.Builder(this, player).build()
        setMediaNotificationProvider(KaifsNotificationProvider(this))
    }

    override fun onGetSession(controllerInfo: MediaSession.ControllerInfo): MediaSession? = session

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        val p = session?.player
        when (intent?.action) {
            ACTION_PREV -> {
                if (p != null) {
                    if (p.currentPosition > 3000) p.seekTo(0L) else p.seekToPreviousMediaItem()
                }
            }
            ACTION_TOGGLE -> {
                if (p != null) {
                    if (p.isPlaying) p.pause() else p.play()
                }
            }
            ACTION_NEXT -> p?.seekToNextMediaItem()
            ACTION_STOP -> {
                p?.pause()
                p?.clearMediaItems()
                handler.removeCallbacks(ticker)
                ServiceCompat.stopForeground(this, ServiceCompat.STOP_FOREGROUND_REMOVE)
                stopSelf()
            }
        }
        return super.onStartCommand(intent, flags, startId)
    }

    private fun servicePending(action: String, code: Int): PendingIntent =
        PendingIntent.getService(
            this, code,
            Intent(this, MusicService::class.java).setAction(action),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )

    private fun requestArt(item: MediaItem) {
        val id = item.mediaId
        if (artRequested == id) return
        artRequested = id
        val uri = item.localConfiguration?.uri ?: return
        artExecutor.execute {
            val bmp = artBitmap(applicationContext, uri, 320)
            handler.post {
                if (bmp != null) {
                    artCache.put(id, bmp)
                    refreshNotification()
                }
            }
        }
    }

    fun buildNotification(s: MediaSession): Notification {
        val p = s.player
        val item = p.currentMediaItem
        val md = item?.mediaMetadata
        val title = md?.title?.toString() ?: "KaifsPlayer"
        val artist = md?.artist?.toString() ?: ""
        val pos = p.currentPosition.coerceAtLeast(0L)
        val dur = p.duration.coerceAtLeast(0L)
        val playing = p.isPlaying
        var art: Bitmap? = null
        if (item != null) {
            art = artCache.get(item.mediaId)
            if (art == null) requestArt(item)
        }
        val open = PendingIntent.getActivity(
            this, 0,
            Intent(this, MainActivity::class.java)
                .addFlags(Intent.FLAG_ACTIVITY_SINGLE_TOP or Intent.FLAG_ACTIVITY_CLEAR_TOP),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )
        val b = NotificationCompat.Builder(this, CHANNEL)
            .setSmallIcon(R.drawable.ic_music_note)
            .setContentTitle(title)
            .setContentText(artist)
            .setSubText(if (dur > 0) fmt(pos) + " / " + fmt(dur) else null)
            .setLargeIcon(art)
            .setColor(0xFFE1306C.toInt())
            .setContentIntent(open)
            .setOnlyAlertOnce(true)
            .setOngoing(playing)
            .setShowWhen(false)
            .setVisibility(NotificationCompat.VISIBILITY_PUBLIC)
            .setCategory(NotificationCompat.CATEGORY_TRANSPORT)
        if (dur > 0) {
            b.setProgress((dur / 1000L).toInt(), (pos / 1000L).toInt(), false)
        }
        b.addAction(R.drawable.ic_skip_prev, "Previous", servicePending(ACTION_PREV, 1))
        b.addAction(
            if (playing) R.drawable.ic_pause else R.drawable.ic_play,
            if (playing) "Pause" else "Play",
            servicePending(ACTION_TOGGLE, 2)
        )
        b.addAction(R.drawable.ic_skip_next, "Next", servicePending(ACTION_NEXT, 3))
        b.addAction(R.drawable.ic_close, "Stop", servicePending(ACTION_STOP, 4))
        b.setStyle(MediaStyleNotificationHelper.MediaStyle(s).setShowActionsInCompactView(0, 1, 2))
        return b.build()
    }

    fun refreshNotification() {
        val s = session ?: return
        if (s.player.mediaItemCount == 0) return
        runCatching { NotificationManagerCompat.from(this).notify(NOTIF_ID, buildNotification(s)) }
    }

    override fun onTaskRemoved(rootIntent: Intent?) {
        val p = session?.player
        if (p == null || !p.playWhenReady || p.mediaItemCount == 0) {
            stopSelf()
        }
    }

    override fun onDestroy() {
        handler.removeCallbacks(ticker)
        artExecutor.shutdown()
        session?.let {
            it.player.release()
            it.release()
        }
        session = null
        super.onDestroy()
    }
}

/** Media3 notification provider that renders our own notification (art, progress bar, time, controls). */
class KaifsNotificationProvider(private val service: MusicService) : MediaNotification.Provider {
    override fun createNotification(
        mediaSession: MediaSession,
        customLayout: ImmutableList<CommandButton>,
        actionFactory: MediaNotification.ActionFactory,
        onNotificationChangedCallback: MediaNotification.Provider.Callback
    ): MediaNotification {
        return MediaNotification(MusicService.NOTIF_ID, service.buildNotification(mediaSession))
    }

    override fun handleCustomCommand(session: MediaSession, action: String, extras: Bundle): Boolean = false
}

// ---------- UI-side controller ----------

object MusicHub {
    private var appCtx: Context? = null
    private var future: ListenableFuture<MediaController>? = null
    private var pending: (() -> Unit)? = null
    private val handler = Handler(Looper.getMainLooper())
    private var sleepRunnable: Runnable? = null

    var controller by mutableStateOf<MediaController?>(null)
    var current by mutableStateOf<MediaItem?>(null)
    var isPlaying by mutableStateOf(false)
    var posMs by mutableLongStateOf(0L)
    var durMs by mutableLongStateOf(0L)
    var shuffle by mutableStateOf(false)
    var repeat by mutableIntStateOf(Player.REPEAT_MODE_OFF)
    var queue by mutableStateOf<List<MediaItem>>(emptyList())
    var index by mutableIntStateOf(0)
    var speed by mutableFloatStateOf(1f)
    var sleepEnd by mutableLongStateOf(0L)

    fun init(ctx: Context) {
        if (future != null) return
        val app = ctx.applicationContext
        appCtx = app
        val token = SessionToken(app, ComponentName(app, MusicService::class.java))
        val f = MediaController.Builder(app, token).buildAsync()
        future = f
        f.addListener({
            val c = runCatching { f.get() }.getOrNull()
            if (c != null) attach(c)
        }, ContextCompat.getMainExecutor(app))
    }

    fun release() {
        future?.let { MediaController.releaseFuture(it) }
        future = null
        controller = null
    }

    private fun refreshQueue(c: MediaController) {
        queue = (0 until c.mediaItemCount).map { c.getMediaItemAt(it) }
    }

    private fun refresh(c: MediaController) {
        current = c.currentMediaItem
        isPlaying = c.isPlaying
        shuffle = c.shuffleModeEnabled
        repeat = c.repeatMode
        index = c.currentMediaItemIndex
        durMs = c.duration.coerceAtLeast(0)
        posMs = c.currentPosition.coerceAtLeast(0)
        speed = c.playbackParameters.speed
        refreshQueue(c)
    }

    private fun attach(c: MediaController) {
        controller = c
        c.addListener(object : Player.Listener {
            override fun onIsPlayingChanged(playing: Boolean) {
                isPlaying = playing
            }

            override fun onMediaItemTransition(mediaItem: MediaItem?, reason: Int) {
                current = mediaItem
                index = c.currentMediaItemIndex
                posMs = 0L
                durMs = c.duration.coerceAtLeast(0)
            }

            override fun onTimelineChanged(timeline: Timeline, reason: Int) {
                refreshQueue(c)
                index = c.currentMediaItemIndex
            }

            override fun onPlaybackStateChanged(playbackState: Int) {
                durMs = c.duration.coerceAtLeast(0)
            }

            override fun onShuffleModeEnabledChanged(shuffleModeEnabled: Boolean) {
                shuffle = shuffleModeEnabled
            }

            override fun onRepeatModeChanged(repeatMode: Int) {
                repeat = repeatMode
            }

            override fun onPlaybackParametersChanged(playbackParameters: PlaybackParameters) {
                speed = playbackParameters.speed
            }

            override fun onPlayerError(error: PlaybackException) {
                appCtx?.let {
                    Toast.makeText(it, "Can't play this audio file. Skipping to the next one.", Toast.LENGTH_SHORT).show()
                }
                if (c.hasNextMediaItem()) {
                    c.seekToNextMediaItem()
                    c.prepare()
                    c.play()
                }
            }
        })
        refresh(c)
        pending?.invoke()
        pending = null
    }

    fun tick() {
        val c = controller ?: return
        posMs = c.currentPosition.coerceAtLeast(0)
        durMs = c.duration.coerceAtLeast(0)
    }

    fun playList(items: List<MediaItem>, startIndex: Int, shuffleOn: Boolean = false) {
        if (items.isEmpty()) return
        val action = {
            val c = controller
            if (c != null) {
                c.shuffleModeEnabled = shuffleOn
                c.setMediaItems(items, startIndex.coerceIn(0, items.size - 1), 0L)
                c.prepare()
                c.play()
            }
        }
        if (controller != null) action() else pending = action
    }

    fun playSongs(songs: List<Song>, startIndex: Int, shuffleOn: Boolean = false) {
        playList(songs.map { it.toMediaItem() }, startIndex, shuffleOn)
    }

    fun playAt(i: Int) {
        val c = controller ?: return
        c.seekToDefaultPosition(i)
        c.play()
    }

    fun toggle() {
        val c = controller ?: return
        if (c.isPlaying) c.pause() else c.play()
    }

    fun pause() {
        controller?.pause()
    }

    fun next() {
        controller?.seekToNextMediaItem()
    }

    fun prev() {
        val c = controller ?: return
        if (c.currentPosition > 3000) c.seekTo(0L) else c.seekToPreviousMediaItem()
    }

    fun seekTo(ms: Long) {
        controller?.seekTo(ms)
        posMs = ms
    }

    fun toggleShuffle() {
        val c = controller ?: return
        c.shuffleModeEnabled = !c.shuffleModeEnabled
    }

    fun toggleRepeat() {
        val c = controller ?: return
        c.repeatMode = when (c.repeatMode) {
            Player.REPEAT_MODE_OFF -> Player.REPEAT_MODE_ALL
            Player.REPEAT_MODE_ALL -> Player.REPEAT_MODE_ONE
            else -> Player.REPEAT_MODE_OFF
        }
    }

    fun changeSpeed(s: Float) {
        controller?.setPlaybackSpeed(s)
        speed = s
    }

    fun setSleep(minutes: Int) {
        sleepRunnable?.let { handler.removeCallbacks(it) }
        sleepRunnable = null
        sleepEnd = 0L
        if (minutes > 0) {
            val r = Runnable {
                controller?.pause()
                sleepEnd = 0L
            }
            sleepRunnable = r
            sleepEnd = System.currentTimeMillis() + minutes * 60_000L
            handler.postDelayed(r, minutes * 60_000L)
        }
    }
}
