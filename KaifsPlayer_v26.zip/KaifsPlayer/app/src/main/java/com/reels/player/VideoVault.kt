@file:OptIn(androidx.compose.foundation.ExperimentalFoundationApi::class)

package com.reels.player

import android.Manifest
import android.content.ContentUris
import android.content.Context
import android.content.pm.PackageManager
import android.media.MediaScannerConnection
import android.net.Uri
import android.os.Build
import android.os.Environment
import android.provider.MediaStore
import android.widget.Toast
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.activity.compose.BackHandler
import androidx.biometric.BiometricManager
import androidx.biometric.BiometricPrompt
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.ui.platform.LocalLifecycleOwner
import androidx.fragment.app.FragmentActivity
import androidx.lifecycle.Lifecycle
import kotlinx.coroutines.delay
import androidx.compose.foundation.background
import androidx.compose.foundation.combinedClickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.itemsIndexed
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.ContextCompat
import java.io.File
import java.io.FileInputStream
import java.io.FileOutputStream
import java.security.MessageDigest
import java.util.UUID
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import org.json.JSONArray
import org.json.JSONObject

class VaultItem(
    val file: String,
    val name: String,
    val origPath: String,
    val durationMs: Long,
    val size: Long,
    val hiddenAt: Long
)

class VaultException(msg: String) : Exception(msg)

/**
 * Real "hide": the video is MOVED out of shared storage into the app's private internal storage
 * (/data/data/<package>/files/vault). No gallery, file manager or other app can see it there.
 * It can only be opened from Settings > Hidden videos, behind a PIN.
 */
object VideoVault {
    private const val PREFS = "vault"
    private const val MARK = "/files/vault/"

    /** Bumped whenever the hidden set or the media library changes, so lists reload. */
    val version = mutableIntStateOf(0)

    /** Uris hidden in this session; filtered from in-app lists until MediaStore catches up. */
    val removed = mutableStateListOf<Uri>()

    var unlocked by mutableStateOf(false)

    private var fails = 0
    private var lockUntil = 0L
    private val lock = Any()

    private fun prefs(ctx: Context) = ctx.getSharedPreferences(PREFS, Context.MODE_PRIVATE)

    fun dir(ctx: Context): File = File(ctx.filesDir, "vault").also { it.mkdirs() }

    fun isVault(uri: Uri?): Boolean =
        uri != null && uri.scheme == "file" && (uri.path ?: "").contains(MARK)

    fun isVaultKey(key: String): Boolean = key.startsWith("file:") && key.contains(MARK)

    // ---------- Index ----------

    private fun readIndex(ctx: Context): MutableList<VaultItem> {
        val s = prefs(ctx).getString("items", null) ?: return mutableListOf()
        return runCatching {
            val a = JSONArray(s)
            (0 until a.length()).map { i ->
                val o = a.getJSONObject(i)
                VaultItem(
                    o.getString("f"), o.optString("n"), o.optString("p"),
                    o.optLong("d"), o.optLong("s"), o.optLong("t")
                )
            }.toMutableList()
        }.getOrDefault(mutableListOf())
    }

    private fun writeIndex(ctx: Context, l: List<VaultItem>) {
        val a = JSONArray()
        l.forEach {
            a.put(
                JSONObject().put("f", it.file).put("n", it.name).put("p", it.origPath)
                    .put("d", it.durationMs).put("s", it.size).put("t", it.hiddenAt)
            )
        }
        prefs(ctx).edit().putString("items", a.toString()).commit()
    }

    fun items(ctx: Context): List<VaultItem> = synchronized(lock) {
        val d = dir(ctx)
        val known = readIndex(ctx).filter { File(d, it.file).exists() }
        val orphans = (d.listFiles() ?: emptyArray())
            .filter { f -> f.isFile && isVideoFile(f) && known.none { it.file == f.name } }
            .map { VaultItem(it.name, it.name, "", 0L, it.length(), it.lastModified() / 1000) }
        (known + orphans).sortedByDescending { it.hiddenAt }
    }

    fun toVideo(ctx: Context, item: VaultItem): Video {
        val f = File(dir(ctx), item.file)
        val dur = if (item.durationMs > 0) item.durationMs else readDuration(f.absolutePath)
        return Video(
            id = item.file.hashCode().toLong(),
            uri = Uri.fromFile(f),
            name = item.name,
            folder = "Hidden",
            durationMs = dur,
            sizeBytes = item.size,
            added = item.hiddenAt
        )
    }

    fun videos(ctx: Context): List<Video> = items(ctx).map { toVideo(ctx, it) }

    fun itemFor(ctx: Context, v: Video): VaultItem? {
        val n = File(v.uri.path ?: return null).name
        return items(ctx).firstOrNull { it.file == n }
    }

    /** Leftover half-copied files from a killed process. Call at app start only. */
    fun cleanupPartials(ctx: Context) {
        (dir(ctx).listFiles() ?: emptyArray()).forEach { if (it.name.endsWith(".part")) it.delete() }
    }

    // ---------- Resume positions for hidden videos (never shown in Continue watching) ----------

    fun savePos(ctx: Context, key: String, pos: Long) {
        prefs(ctx).edit().putLong("pos_" + key.hashCode(), pos).apply()
    }

    fun getPos(ctx: Context, key: String): Long = prefs(ctx).getLong("pos_" + key.hashCode(), 0L)

    // ---------- File moving ----------

    private fun moveFile(src: File, dest: File, onProgress: (Float) -> Unit, alive: () -> Boolean) {
        if (src.renameTo(dest)) {
            onProgress(1f)
            return
        }
        val parent = dest.parentFile ?: throw VaultException("Invalid destination.")
        parent.mkdirs()
        val total = src.length()
        if (parent.usableSpace < total + 20L * 1024 * 1024) {
            throw VaultException("Not enough free storage on the phone. Free up ${fmtSize(total)} and try again.")
        }
        val part = File(parent, dest.name + ".part")
        try {
            FileInputStream(src).use { ins ->
                FileOutputStream(part).use { out ->
                    val buf = ByteArray(1 shl 20)
                    var done = 0L
                    while (true) {
                        val n = ins.read(buf)
                        if (n < 0) break
                        if (!alive()) throw VaultException("Cancelled.")
                        out.write(buf, 0, n)
                        done += n
                        if (total > 0) onProgress((done.toFloat() / total).coerceIn(0f, 1f))
                    }
                    out.fd.sync()
                }
            }
            if (part.length() != total) throw VaultException("Copy failed (size mismatch). Your original file is untouched.")
            if (!part.renameTo(dest)) throw VaultException("Couldn't finish the copy.")
        } catch (e: Exception) {
            part.delete()
            dest.delete()
            if (e is VaultException) throw e
            throw VaultException("Couldn't copy the video: ${e.message ?: "unknown error"}. Your original file is untouched.")
        }
        if (!src.delete()) {
            dest.delete()
            throw VaultException(
                "Android didn't allow removing the original file, so nothing was hidden. " +
                    "Allow 'All files access' for KaifsPlayer in Settings and try again."
            )
        }
        onProgress(1f)
    }

    // ---------- Hide ----------

    /** Returns null on success, or an error message. Runs blocking: call from Dispatchers.IO. */
    fun hide(ctx: Context, v: Video, onProgress: (Float) -> Unit, alive: () -> Boolean): String? {
        val path = videoPath(ctx, v) ?: return "Couldn't find this video's file."
        val src = File(path)
        if (!src.exists()) return "The video file no longer exists."
        if (isVault(Uri.fromFile(src))) return "This video is already hidden."
        val d = dir(ctx)
        val size = src.length()
        val id = UUID.randomUUID().toString().replace("-", "").take(20)
        val ext = src.extension.lowercase().ifBlank { "mp4" }
        val dest = File(d, "$id.$ext")
        val base = src.nameWithoutExtension
        val subs = (src.parentFile?.listFiles() ?: emptyArray())
            .filter { it.isFile && it.extension.lowercase() in subExts.keys && it.name.startsWith(base) }
        val dur = if (v.durationMs > 0) v.durationMs else readDuration(path)

        try {
            moveFile(src, dest, onProgress, alive)
        } catch (e: VaultException) {
            return e.message
        }
        // Subtitle files next to the video would still reveal it, so they move too (best effort).
        subs.forEach { s ->
            runCatching { moveFile(s, File(d, id + s.name.removePrefix(base)), { }, { true }) }
        }

        synchronized(lock) {
            val idx = readIndex(ctx)
            idx.add(VaultItem(dest.name, src.name, path, dur, size, System.currentTimeMillis() / 1000))
            writeIndex(ctx, idx)
        }

        // Remove every trace from the in-app lists, resume list and likes.
        val keys = mutableSetOf(v.uri.toString())
        removed.add(v.uri)
        runCatching {
            val coll = MediaStore.Video.Media.EXTERNAL_CONTENT_URI
            ctx.contentResolver.query(
                coll, arrayOf(MediaStore.Video.Media._ID),
                "${MediaStore.MediaColumns.DATA}=?", arrayOf(path), null
            )?.use { c ->
                while (c.moveToNext()) {
                    val u = ContentUris.withAppendedId(coll, c.getLong(0))
                    keys.add(u.toString())
                    removed.add(u)
                    runCatching { ctx.contentResolver.delete(u, null, null) }
                }
            }
        }
        runCatching { ctx.contentResolver.delete(v.uri, null, null) }
        keys.forEach { removeRecent(ctx, it) }
        val rp = ctx.getSharedPreferences("reels", Context.MODE_PRIVATE)
        val liked = rp.getStringSet("liked", emptySet())!!.toMutableSet()
        if (liked.removeAll(keys)) rp.edit().putStringSet("liked", liked).apply()

        // Tell Android the original is gone so the Gallery and other apps drop it.
        runCatching {
            MediaScannerConnection.scanFile(ctx.applicationContext, arrayOf(path), null) { _, _ ->
                version.intValue++
            }
        }
        version.intValue++
        return null
    }

    // ---------- Unhide / delete ----------

    fun unhide(ctx: Context, item: VaultItem, onProgress: (Float) -> Unit, alive: () -> Boolean): String? {
        val d = dir(ctx)
        val f = File(d, item.file)
        if (!f.exists()) {
            removeFromIndex(ctx, item)
            return "The file is missing."
        }
        val fallbackDir = File(Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_MOVIES), "Restored")
        var target = if (item.origPath.isNotBlank()) File(item.origPath) else File(fallbackDir, item.name)
        val parent = target.parentFile
        if (parent == null || !(parent.exists() || parent.mkdirs()) || !parent.canWrite()) {
            fallbackDir.mkdirs()
            target = File(fallbackDir, item.name)
        }
        if (target.exists()) {
            val b = target.nameWithoutExtension
            val e = target.extension.let { if (it.isEmpty()) "" else ".$it" }
            var n = 1
            while (File(target.parentFile, "$b ($n)$e").exists()) n++
            target = File(target.parentFile, "$b ($n)$e")
        }
        try {
            moveFile(f, target, onProgress, alive)
        } catch (e: VaultException) {
            return e.message
        }
        val id = item.file.substringBeforeLast('.')
        val restored = mutableListOf(target.absolutePath)
        (d.listFiles() ?: emptyArray())
            .filter { it.name.startsWith("$id.") && it.extension.lowercase() in subExts.keys }
            .forEach { s ->
                val out = File(target.parentFile, target.nameWithoutExtension + s.name.removePrefix(id))
                runCatching { moveFile(s, out, { }, { true }); restored.add(out.absolutePath) }
            }
        removeFromIndex(ctx, item)
        runCatching {
            MediaScannerConnection.scanFile(ctx.applicationContext, restored.toTypedArray(), null) { _, _ ->
                version.intValue++
            }
        }
        version.intValue++
        return null
    }

    fun deleteForever(ctx: Context, item: VaultItem) {
        val d = dir(ctx)
        val id = item.file.substringBeforeLast('.')
        (d.listFiles() ?: emptyArray()).filter { it.name == item.file || it.name.startsWith("$id.") }.forEach { it.delete() }
        removeFromIndex(ctx, item)
        version.intValue++
    }

    private fun removeFromIndex(ctx: Context, item: VaultItem) = synchronized(lock) {
        writeIndex(ctx, readIndex(ctx).filter { it.file != item.file })
    }

    // ---------- Batch helpers ----------

    /** Returns (how many were done, error or null). Stops at the first error. */
    fun hideMany(ctx: Context, vids: List<Video>, onProgress: (Int, Float) -> Unit, alive: () -> Boolean): Pair<Int, String?> {
        var n = 0
        for ((i, v) in vids.withIndex()) {
            if (!alive()) return Pair(n, "Cancelled.")
            val err = hide(ctx, v, { onProgress(i, it) }, alive)
            if (err != null) return Pair(n, err)
            n++
        }
        return Pair(n, null)
    }

    fun unhideMany(ctx: Context, list: List<VaultItem>, onProgress: (Int, Float) -> Unit, alive: () -> Boolean): Pair<Int, String?> {
        var n = 0
        for ((i, item) in list.withIndex()) {
            if (!alive()) return Pair(n, "Cancelled.")
            val err = unhide(ctx, item, { p -> onProgress(i, p) }, alive)
            if (err != null) return Pair(n, err)
            n++
        }
        return Pair(n, null)
    }

    // ---------- Fingerprint ----------

    fun bioEnabled(ctx: Context): Boolean = prefs(ctx).getBoolean("bio", false)

    fun setBio(ctx: Context, on: Boolean) {
        prefs(ctx).edit().putBoolean("bio", on).apply()
    }

    fun bioAvailable(ctx: Context): Boolean =
        BiometricManager.from(ctx).canAuthenticate(BiometricManager.Authenticators.BIOMETRIC_WEAK) ==
            BiometricManager.BIOMETRIC_SUCCESS

    fun promptBio(act: FragmentActivity, title: String, onSuccess: () -> Unit, onError: (String) -> Unit) {
        val info = BiometricPrompt.PromptInfo.Builder()
            .setTitle(title)
            .setSubtitle("Hidden videos")
            .setNegativeButtonText("Use PIN")
            .setAllowedAuthenticators(BiometricManager.Authenticators.BIOMETRIC_WEAK)
            .build()
        val prompt = BiometricPrompt(
            act,
            ContextCompat.getMainExecutor(act),
            object : BiometricPrompt.AuthenticationCallback() {
                override fun onAuthenticationSucceeded(result: BiometricPrompt.AuthenticationResult) {
                    onSuccess()
                }

                override fun onAuthenticationError(errorCode: Int, errString: CharSequence) {
                    onError(errString.toString())
                }
            }
        )
        prompt.authenticate(info)
    }

    // ---------- PIN ----------

    private fun hash(salt: String, s: String): String =
        MessageDigest.getInstance("SHA-256").digest((salt + s).toByteArray())
            .joinToString("") { "%02x".format(it) }

    fun hasPin(ctx: Context): Boolean = prefs(ctx).contains("pin_hash")

    fun hasRecovery(ctx: Context): Boolean = prefs(ctx).contains("rec_hash")

    fun setPin(ctx: Context, pin: String, recovery: String?, unlock: Boolean) {
        val p = prefs(ctx)
        val salt = p.getString("salt", null) ?: UUID.randomUUID().toString()
        val e = p.edit().putString("salt", salt).putString("pin_hash", hash(salt, pin))
        if (!recovery.isNullOrBlank()) e.putString("rec_hash", hash(salt, recovery.trim().lowercase()))
        e.commit()
        if (unlock) unlocked = true
    }

    /** 0 = correct, -1 = wrong, > 0 = locked out for that many seconds. */
    fun tryPin(ctx: Context, pin: String, unlock: Boolean = true): Int {
        val now = System.currentTimeMillis()
        if (now < lockUntil) return ((lockUntil - now) / 1000 + 1).toInt()
        val p = prefs(ctx)
        val ok = hash(p.getString("salt", "") ?: "", pin) == p.getString("pin_hash", null)
        if (ok) {
            fails = 0
            if (unlock) unlocked = true
            return 0
        }
        fails++
        if (fails >= 5) {
            fails = 0
            lockUntil = now + 30_000
            return 30
        }
        return -1
    }

    fun tryRecovery(ctx: Context, word: String): Boolean {
        val p = prefs(ctx)
        val h = p.getString("rec_hash", null) ?: return false
        return hash(p.getString("salt", "") ?: "", word.trim().lowercase()) == h
    }
}

// ======================= UI =======================

@Composable
fun PinField(label: String, value: String, onChange: (String) -> Unit) {
    OutlinedTextField(
        value = value,
        onValueChange = onChange,
        singleLine = true,
        label = { Text(label) },
        visualTransformation = PasswordVisualTransformation(),
        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.NumberPassword),
        colors = fieldColors(),
        modifier = Modifier.fillMaxWidth()
    )
}

@Composable
fun fieldColors() = OutlinedTextFieldDefaults.colors(
    focusedTextColor = Fg,
    unfocusedTextColor = Fg,
    focusedBorderColor = Accent,
    unfocusedBorderColor = Fg.copy(alpha = 0.3f),
    focusedLabelColor = Accent,
    unfocusedLabelColor = Fg.copy(alpha = 0.6f),
    cursorColor = Accent
)

private val ErrRed = Color(0xFFE5484D)

@Composable
fun PinSetupDialog(unlock: Boolean, onDone: () -> Unit, onDismiss: () -> Unit) {
    val ctx = LocalContext.current
    var pin by remember { mutableStateOf("") }
    var pin2 by remember { mutableStateOf("") }
    var rec by remember { mutableStateOf("") }
    var err by remember { mutableStateOf<String?>(null) }
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Create a PIN") },
        text = {
            Column {
                Text("Choose a 4 to 8 digit PIN. It will be required to open your hidden videos.", fontSize = 13.sp)
                Spacer(Modifier.height(10.dp))
                PinField("PIN", pin) { pin = it.filter { c -> c.isDigit() }.take(8) }
                Spacer(Modifier.height(8.dp))
                PinField("Confirm PIN", pin2) { pin2 = it.filter { c -> c.isDigit() }.take(8) }
                Spacer(Modifier.height(8.dp))
                OutlinedTextField(
                    value = rec,
                    onValueChange = { rec = it },
                    singleLine = true,
                    label = { Text("Recovery word") },
                    colors = fieldColors(),
                    modifier = Modifier.fillMaxWidth()
                )
                Text(
                    "If you forget your PIN, this word is the only way to reset it. Remember it.",
                    fontSize = 11.sp,
                    modifier = Modifier.padding(top = 6.dp)
                )
                err?.let { Text(it, color = ErrRed, fontSize = 12.sp, modifier = Modifier.padding(top = 6.dp)) }
            }
        },
        confirmButton = {
            TextButton(onClick = {
                when {
                    pin.length < 4 -> err = "The PIN must be at least 4 digits."
                    pin != pin2 -> err = "The PINs don't match."
                    rec.isBlank() -> err = "Please enter a recovery word."
                    else -> {
                        VideoVault.setPin(ctx, pin, rec, unlock)
                        onDone()
                    }
                }
            }) { Text("Save", color = Accent) }
        },
        dismissButton = { TextButton(onClick = onDismiss) { Text("Cancel", color = Fg) } },
        containerColor = CardBg,
        titleContentColor = Fg,
        textContentColor = Fg.copy(alpha = 0.8f)
    )
}

@Composable
fun ForgotPinDialog(onDone: () -> Unit, onDismiss: () -> Unit) {
    val ctx = LocalContext.current
    var word by remember { mutableStateOf("") }
    var pin by remember { mutableStateOf("") }
    var err by remember { mutableStateOf<String?>(null) }
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Reset PIN") },
        text = {
            Column {
                if (!VideoVault.hasRecovery(ctx)) {
                    Text("No recovery word was set, so the PIN can't be reset.", fontSize = 13.sp)
                } else {
                    OutlinedTextField(
                        value = word, onValueChange = { word = it }, singleLine = true,
                        label = { Text("Recovery word") }, colors = fieldColors(),
                        modifier = Modifier.fillMaxWidth()
                    )
                    Spacer(Modifier.height(8.dp))
                    PinField("New PIN (4 to 8 digits)", pin) { pin = it.filter { c -> c.isDigit() }.take(8) }
                    err?.let { Text(it, color = ErrRed, fontSize = 12.sp, modifier = Modifier.padding(top = 6.dp)) }
                }
            }
        },
        confirmButton = {
            if (VideoVault.hasRecovery(ctx)) {
                TextButton(onClick = {
                    if (pin.length < 4) {
                        err = "The PIN must be at least 4 digits."
                    } else if (!VideoVault.tryRecovery(ctx, word)) {
                        err = "That recovery word is incorrect."
                    } else {
                        VideoVault.setPin(ctx, pin, null, true)
                        onDone()
                    }
                }) { Text("Reset", color = Accent) }
            }
        },
        dismissButton = { TextButton(onClick = onDismiss) { Text("Close", color = Fg) } },
        containerColor = CardBg,
        titleContentColor = Fg,
        textContentColor = Fg.copy(alpha = 0.8f)
    )
}

@Composable
fun ChangePinDialog(onDone: () -> Unit, onDismiss: () -> Unit) {
    val ctx = LocalContext.current
    var old by remember { mutableStateOf("") }
    var pin by remember { mutableStateOf("") }
    var err by remember { mutableStateOf<String?>(null) }
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Change PIN") },
        text = {
            Column {
                PinField("Current PIN", old) { old = it.filter { c -> c.isDigit() }.take(8) }
                Spacer(Modifier.height(8.dp))
                PinField("New PIN (4 to 8 digits)", pin) { pin = it.filter { c -> c.isDigit() }.take(8) }
                err?.let { Text(it, color = ErrRed, fontSize = 12.sp, modifier = Modifier.padding(top = 6.dp)) }
            }
        },
        confirmButton = {
            TextButton(onClick = {
                if (pin.length < 4) {
                    err = "The new PIN must be at least 4 digits."
                } else {
                    val r = VideoVault.tryPin(ctx, old)
                    if (r == 0) {
                        VideoVault.setPin(ctx, pin, null, true)
                        Toast.makeText(ctx, "PIN changed", Toast.LENGTH_SHORT).show()
                        onDone()
                    } else if (r < 0) {
                        err = "The current PIN is wrong."
                    } else {
                        err = "Too many attempts. Try again in $r s."
                    }
                }
            }) { Text("Change", color = Accent) }
        },
        dismissButton = { TextButton(onClick = onDismiss) { Text("Cancel", color = Fg) } },
        containerColor = CardBg,
        titleContentColor = Fg,
        textContentColor = Fg.copy(alpha = 0.8f)
    )
}

@Composable
fun ProgressDialog(title: String, progress: Float, onCancel: () -> Unit) {
    AlertDialog(
        onDismissRequest = { },
        title = { Text(title) },
        text = {
            Column {
                LinearProgressIndicator(progress = { progress }, color = Accent, modifier = Modifier.fillMaxWidth())
                Text(
                    "${(progress * 100).toInt()}%  •  Please keep the app open",
                    fontSize = 12.sp,
                    modifier = Modifier.padding(top = 8.dp)
                )
            }
        },
        confirmButton = { },
        dismissButton = { TextButton(onClick = onCancel) { Text("Cancel", color = Fg) } },
        containerColor = CardBg,
        titleContentColor = Fg,
        textContentColor = Fg.copy(alpha = 0.8f)
    )
}

/** Confirm, (create a PIN if needed), then move the videos into the vault. */
@Composable
fun BatchHideDialog(videos: List<Video>, label: String?, onDismiss: () -> Unit, onDone: (List<Video>) -> Unit) {
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    var step by remember { mutableIntStateOf(if (VideoVault.hasPin(ctx)) 1 else 0) }
    var prog by remember { mutableFloatStateOf(0f) }
    var cur by remember { mutableIntStateOf(0) }
    val cancelled = remember { booleanArrayOf(false) }

    fun start() {
        step = 2
        cancelled[0] = false
        scope.launch {
            val (n, err) = withContext(Dispatchers.IO) {
                VideoVault.hideMany(ctx, videos, { i, p ->
                    cur = i
                    prog = (i + p) / videos.size.coerceAtLeast(1)
                }, { !cancelled[0] })
            }
            if (n > 0) {
                Toast.makeText(ctx, if (n == 1) "Video hidden" else "$n videos hidden", Toast.LENGTH_SHORT).show()
            }
            if (err != null && err != "Cancelled.") Toast.makeText(ctx, err, Toast.LENGTH_LONG).show()
            if (n > 0) onDone(videos.take(n)) else onDismiss()
        }
    }

    val writeLauncher = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { ok ->
        if (ok) start() else {
            Toast.makeText(ctx, "Storage permission is required to hide videos", Toast.LENGTH_LONG).show()
            onDismiss()
        }
    }

    fun confirm() {
        if (Build.VERSION.SDK_INT >= 30 && !Environment.isExternalStorageManager()) {
            Toast.makeText(ctx, "Allow 'All files access' for KaifsPlayer, then try again", Toast.LENGTH_LONG).show()
            openAllFilesSettings(ctx)
            onDismiss()
        } else if (Build.VERSION.SDK_INT <= 29 &&
            ContextCompat.checkSelfPermission(ctx, Manifest.permission.WRITE_EXTERNAL_STORAGE) != PackageManager.PERMISSION_GRANTED
        ) {
            writeLauncher.launch(Manifest.permission.WRITE_EXTERNAL_STORAGE)
        } else {
            start()
        }
    }

    when (step) {
        0 -> PinSetupDialog(unlock = false, onDone = { step = 1 }, onDismiss = onDismiss)
        1 -> AlertDialog(
            onDismissRequest = onDismiss,
            title = { Text(if (videos.size == 1) "Hide this video?" else "Hide ${videos.size} videos?") },
            text = {
                val what = if (videos.size == 1) "\"${videos[0].name}\"" else "${videos.size} videos" + (label?.let { " $it" } ?: "")
                Text(
                    "$what will be moved into KaifsPlayer's private storage. They will disappear from " +
                        "Gallery, file managers and every other app. You can open them only from Settings > Hidden videos with your PIN or fingerprint.\n\n" +
                        "Important: if you uninstall KaifsPlayer or clear its data, hidden videos are deleted permanently. " +
                        "Update the app over the existing install instead."
                )
            },
            confirmButton = { TextButton(onClick = { confirm() }) { Text("Hide", color = Accent) } },
            dismissButton = { TextButton(onClick = onDismiss) { Text("Cancel", color = Fg) } },
            containerColor = CardBg,
            titleContentColor = Fg,
            textContentColor = Fg.copy(alpha = 0.8f)
        )
        else -> ProgressDialog(
            if (videos.size > 1) "Hiding ${cur + 1} of ${videos.size}..." else "Hiding video...",
            prog
        ) { cancelled[0] = true }
    }
}

@Composable
fun HideVideoDialog(video: Video, onDismiss: () -> Unit, onDone: (Video) -> Unit) {
    BatchHideDialog(listOf(video), null, onDismiss) { onDone(video) }
}

/** "+" screen: choose any videos on the phone and hide them in one go. */
@Composable
fun VaultPicker(all: List<Video>, onClose: () -> Unit, onPick: (List<Video>) -> Unit) {
    var folder by remember { mutableStateOf<String?>(null) }
    var sel by remember { mutableStateOf<Set<Long>>(emptySet()) }
    val folders = remember(all) { all.map { it.folder }.distinct().sortedBy { it.lowercase() } }
    val shown = remember(all, folder) { if (folder == null) all else all.filter { it.folder == folder } }
    val allShownSelected = shown.isNotEmpty() && shown.all { it.id in sel }

    BackHandler { onClose() }
    Box(Modifier.fillMaxSize().background(Bg)) {
        Column(Modifier.fillMaxSize()) {
            BrowseHeader(
                "Select videos",
                if (sel.isEmpty()) "Tap videos to hide" else "${sel.size} selected",
                onClose
            ) {
                Chip(R.drawable.ic_check, if (allShownSelected) "Clear" else "Select all") {
                    val ids = shown.map { it.id }.toSet()
                    sel = if (allShownSelected) sel - ids else sel + ids
                }
            }
            Row(
                Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()).padding(horizontal = 12.dp, vertical = 4.dp),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                Chip(R.drawable.ic_folder, "All", folder == null) { folder = null }
                folders.forEach { f -> Chip(R.drawable.ic_folder, f, folder == f) { folder = f } }
            }
            if (shown.isEmpty()) {
                Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                    Text("No videos found", color = Fg.copy(alpha = 0.6f))
                }
            } else {
                LazyVerticalGrid(
                    columns = GridCells.Fixed(3),
                    contentPadding = PaddingValues(start = 8.dp, end = 8.dp, top = 8.dp, bottom = 96.dp),
                    horizontalArrangement = Arrangement.spacedBy(6.dp),
                    verticalArrangement = Arrangement.spacedBy(6.dp),
                    modifier = Modifier.fillMaxSize()
                ) {
                    itemsIndexed(shown, key = { _, v -> v.id }) { _, v ->
                        val on = v.id in sel
                        Box(
                            Modifier.fillMaxWidth().aspectRatio(0.62f)
                                .clip(RoundedCornerShape(10.dp))
                                .background(CardBg)
                                .clickable { sel = if (on) sel - v.id else sel + v.id }
                        ) {
                            Thumb(v, 300, 480, Modifier.fillMaxSize())
                            if (on) Box(Modifier.fillMaxSize().background(Accent.copy(alpha = 0.35f)))
                            Box(
                                Modifier.align(Alignment.TopStart).padding(6.dp).size(22.dp)
                                    .clip(CircleShape)
                                    .background(if (on) Accent else Color.Black.copy(alpha = 0.45f)),
                                contentAlignment = Alignment.Center
                            ) {
                                if (on) Ic(R.drawable.ic_check, 14.dp, Color.White)
                            }
                            Text(
                                fmt(v.durationMs),
                                color = Color.White,
                                fontSize = 11.sp,
                                modifier = Modifier.align(Alignment.BottomEnd).padding(6.dp)
                                    .background(Color.Black.copy(alpha = 0.6f), RoundedCornerShape(6.dp))
                                    .padding(horizontal = 5.dp, vertical = 2.dp)
                            )
                        }
                    }
                }
            }
        }
        if (sel.isNotEmpty()) {
            Button(
                onClick = { onPick(all.filter { it.id in sel }) },
                modifier = Modifier.align(Alignment.BottomCenter).padding(bottom = 20.dp)
            ) { Text(if (sel.size == 1) "Hide 1 video" else "Hide ${sel.size} videos") }
        }
    }
}

@Composable
fun VaultOptionsDialog(onChangePin: () -> Unit, onDismiss: () -> Unit) {
    val ctx = LocalContext.current
    val act = remember { ctx.findActivity() as? FragmentActivity }
    var bio by remember { mutableStateOf(VideoVault.bioEnabled(ctx)) }
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Vault options") },
        text = {
            Column {
                ToggleRow(
                    "Fingerprint unlock",
                    "Open hidden videos with your fingerprint (or phone face unlock where supported). Your PIN always works too.",
                    bio
                ) { on ->
                    if (!on) {
                        VideoVault.setBio(ctx, false)
                        bio = false
                    } else if (!VideoVault.bioAvailable(ctx)) {
                        Toast.makeText(
                            ctx,
                            "No fingerprint or face unlock is set up on this phone. Add one in your phone's Settings first.",
                            Toast.LENGTH_LONG
                        ).show()
                    } else if (act != null) {
                        VideoVault.promptBio(act, "Confirm to turn on", {
                            VideoVault.setBio(ctx, true)
                            bio = true
                        }, { })
                    }
                }
                Spacer(Modifier.height(6.dp))
                ActionRow("Change PIN", null) { onChangePin() }
            }
        },
        confirmButton = { TextButton(onClick = onDismiss) { Text("Close", color = Accent) } },
        containerColor = CardBg,
        titleContentColor = Fg,
        textContentColor = Fg.copy(alpha = 0.8f)
    )
}

@Composable
fun VaultScreen(all: List<Video>, onBack: () -> Unit, onPlay: (List<Video>, Int) -> Unit) {
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    var hasPin by remember { mutableStateOf(VideoVault.hasPin(ctx)) }
    val unlocked = VideoVault.unlocked
    var showSetup by remember { mutableStateOf(false) }
    var showChange by remember { mutableStateOf(false) }
    var showForgot by remember { mutableStateOf(false) }
    var showOptions by remember { mutableStateOf(false) }
    var picking by remember { mutableStateOf(false) }
    var hideBatch by remember { mutableStateOf<List<Video>?>(null) }
    var vids by remember { mutableStateOf<List<Video>?>(null) }
    var selected by remember { mutableStateOf<Set<Long>>(emptySet()) }
    var confirmDelete by remember { mutableStateOf(false) }
    var work by remember { mutableStateOf<String?>(null) }
    var prog by remember { mutableFloatStateOf(0f) }
    val cancelled = remember { booleanArrayOf(false) }

    LaunchedEffect(VideoVault.version.intValue, unlocked) {
        if (unlocked) {
            vids = withContext(Dispatchers.IO) { VideoVault.videos(ctx) }
        } else {
            selected = emptySet()
        }
    }

    val list = vids
    val selecting = selected.isNotEmpty()
    BackHandler(enabled = selecting) { selected = emptySet() }

    if (picking && unlocked) {
        VaultPicker(all = all, onClose = { picking = false }, onPick = { hideBatch = it })
    } else {
        Box(Modifier.fillMaxSize().background(Bg)) {
            Column(Modifier.fillMaxSize()) {
                if (selecting && list != null) {
                    BrowseHeader("${selected.size} selected", "Choose an action below", { selected = emptySet() }) {
                        Chip(R.drawable.ic_check, if (selected.size == list.size) "Clear" else "Select all") {
                            selected = if (selected.size == list.size) emptySet() else list.map { it.id }.toSet()
                        }
                    }
                } else {
                    BrowseHeader(
                        "Hidden videos",
                        if (!unlocked || list == null) "Locked"
                        else "${list.size} videos  •  ${fmtSize(list.sumOf { it.sizeBytes })}",
                        onBack
                    ) {
                        if (unlocked) {
                            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                Chip(R.drawable.ic_lock, "Lock") { VideoVault.unlocked = false }
                                Chip(R.drawable.ic_settings, null) { showOptions = true }
                            }
                        }
                    }
                }

                when {
                    !hasPin -> Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                        CenterMessage(
                            R.drawable.ic_lock, "Protect your hidden videos",
                            "Create a PIN first. Hidden videos are stored privately inside KaifsPlayer and can only be opened with it.",
                            "Create PIN"
                        ) { showSetup = true }
                    }
                    !unlocked -> VaultGate(onForgot = { showForgot = true })
                    list == null -> Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                        Text("Loading...", color = Fg.copy(alpha = 0.6f))
                    }
                    list.isEmpty() -> Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                        Text(
                            "No hidden videos yet.\nTap + to choose videos from your phone and hide them.",
                            color = Fg.copy(alpha = 0.6f),
                            textAlign = TextAlign.Center,
                            modifier = Modifier.padding(32.dp)
                        )
                    }
                    else -> LazyVerticalGrid(
                        columns = GridCells.Fixed(3),
                        contentPadding = PaddingValues(start = 8.dp, end = 8.dp, top = 8.dp, bottom = 96.dp),
                        horizontalArrangement = Arrangement.spacedBy(6.dp),
                        verticalArrangement = Arrangement.spacedBy(6.dp),
                        modifier = Modifier.fillMaxSize()
                    ) {
                        itemsIndexed(list, key = { _, v -> v.id }) { idx, v ->
                            val on = v.id in selected
                            Box(
                                Modifier.fillMaxWidth().aspectRatio(0.62f)
                                    .clip(RoundedCornerShape(10.dp))
                                    .background(CardBg)
                                    .combinedClickable(
                                        onClick = {
                                            if (selected.isNotEmpty()) selected = if (on) selected - v.id else selected + v.id
                                            else onPlay(list, idx)
                                        },
                                        onLongClick = { selected = selected + v.id }
                                    )
                            ) {
                                Thumb(v, 300, 480, Modifier.fillMaxSize())
                                Box(
                                    Modifier.align(Alignment.BottomCenter).fillMaxWidth().height(70.dp).background(
                                        Brush.verticalGradient(listOf(Color.Transparent, Color.Black.copy(alpha = 0.8f)))
                                    )
                                )
                                if (on) Box(Modifier.fillMaxSize().background(Accent.copy(alpha = 0.35f)))
                                if (selecting) {
                                    Box(
                                        Modifier.align(Alignment.TopStart).padding(6.dp).size(22.dp)
                                            .clip(CircleShape)
                                            .background(if (on) Accent else Color.Black.copy(alpha = 0.45f)),
                                        contentAlignment = Alignment.Center
                                    ) {
                                        if (on) Ic(R.drawable.ic_check, 14.dp, Color.White)
                                    }
                                }
                                Text(
                                    fmt(v.durationMs),
                                    color = Color.White,
                                    fontSize = 11.sp,
                                    fontWeight = FontWeight.Medium,
                                    modifier = Modifier.align(Alignment.TopEnd).padding(6.dp)
                                        .background(Color.Black.copy(alpha = 0.6f), RoundedCornerShape(6.dp))
                                        .padding(horizontal = 5.dp, vertical = 2.dp)
                                )
                                Text(
                                    v.name.substringBeforeLast('.'),
                                    color = Color.White,
                                    fontSize = 11.sp,
                                    maxLines = 2,
                                    overflow = TextOverflow.Ellipsis,
                                    modifier = Modifier.align(Alignment.BottomStart).padding(6.dp)
                                )
                            }
                        }
                    }
                }
            }

            // "+" button: pick videos from the phone to hide
            if (unlocked && hasPin && !selecting) {
                Box(
                    Modifier.align(Alignment.BottomEnd).padding(20.dp).size(56.dp)
                        .clip(CircleShape).background(Accent)
                        .clickable { picking = true },
                    contentAlignment = Alignment.Center
                ) { Ic(R.drawable.ic_add, 28.dp, Color.White) }
            }

            // Action bar while videos are selected
            if (selecting && list != null) {
                Row(
                    Modifier.align(Alignment.BottomCenter).padding(bottom = 20.dp),
                    horizontalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    Button(onClick = {
                        val chosen = list.filter { it.id in selected }
                        work = "Restoring..."
                        prog = 0f
                        cancelled[0] = false
                        scope.launch {
                            val (n, err) = withContext(Dispatchers.IO) {
                                val its = VideoVault.items(ctx)
                                val picks = chosen.mapNotNull { v ->
                                    val nm = File(v.uri.path ?: "").name
                                    its.firstOrNull { it.file == nm }
                                }
                                VideoVault.unhideMany(ctx, picks, { i, p ->
                                    prog = (i + p) / picks.size.coerceAtLeast(1)
                                }, { !cancelled[0] })
                            }
                            work = null
                            selected = emptySet()
                            Toast.makeText(
                                ctx,
                                if (err != null && err != "Cancelled.") err
                                else if (n == 1) "Video restored to its original folder"
                                else "$n videos restored to their original folders",
                                Toast.LENGTH_LONG
                            ).show()
                        }
                    }) { Text("Unhide (${selected.size})") }
                    Button(
                        onClick = { confirmDelete = true },
                        colors = ButtonDefaults.buttonColors(containerColor = ErrRed)
                    ) { Text("Delete (${selected.size})", color = Color.White) }
                }
            }
        }
    }

    if (showSetup) {
        PinSetupDialog(unlock = true, onDone = { showSetup = false; hasPin = true }, onDismiss = { showSetup = false })
    }
    if (showChange) ChangePinDialog(onDone = { showChange = false }, onDismiss = { showChange = false })
    if (showForgot) ForgotPinDialog(onDone = { showForgot = false }, onDismiss = { showForgot = false })
    if (showOptions) {
        VaultOptionsDialog(onChangePin = { showOptions = false; showChange = true }, onDismiss = { showOptions = false })
    }
    val hb = hideBatch
    if (hb != null) {
        BatchHideDialog(
            videos = hb,
            label = null,
            onDismiss = { hideBatch = null },
            onDone = { hideBatch = null; picking = false }
        )
    }
    if (confirmDelete && list != null) {
        val chosen = list.filter { it.id in selected }
        AlertDialog(
            onDismissRequest = { confirmDelete = false },
            title = { Text(if (chosen.size == 1) "Delete permanently?" else "Delete ${chosen.size} videos permanently?") },
            text = { Text("They will be deleted from your phone. This action can't be undone.") },
            confirmButton = {
                TextButton(onClick = {
                    val its = VideoVault.items(ctx)
                    chosen.forEach { v ->
                        val nm = File(v.uri.path ?: "").name
                        its.firstOrNull { it.file == nm }?.let { VideoVault.deleteForever(ctx, it) }
                    }
                    confirmDelete = false
                    selected = emptySet()
                    Toast.makeText(ctx, "Deleted", Toast.LENGTH_SHORT).show()
                }) { Text("Delete", color = ErrRed) }
            },
            dismissButton = { TextButton(onClick = { confirmDelete = false }) { Text("Cancel", color = Fg) } },
            containerColor = CardBg,
            titleContentColor = Fg,
            textContentColor = Fg.copy(alpha = 0.8f)
        )
    }
    val w = work
    if (w != null) ProgressDialog(w, prog) { cancelled[0] = true }
}

@Composable
fun VaultGate(onForgot: () -> Unit) {
    val ctx = LocalContext.current
    val owner = LocalLifecycleOwner.current
    val act = remember { ctx.findActivity() as? FragmentActivity }
    val bio = remember { VideoVault.bioEnabled(ctx) && VideoVault.bioAvailable(ctx) }
    var pin by remember { mutableStateOf("") }
    var err by remember { mutableStateOf<String?>(null) }

    fun askBio() {
        if (act != null) VideoVault.promptBio(act, "Unlock hidden videos", { VideoVault.unlocked = true }, { })
    }

    LaunchedEffect(Unit) {
        if (bio) {
            while (!owner.lifecycle.currentState.isAtLeast(Lifecycle.State.RESUMED)) delay(200)
            askBio()
        }
    }

    Column(
        Modifier.fillMaxSize().padding(horizontal = 32.dp),
        verticalArrangement = Arrangement.Center,
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Ic(R.drawable.ic_lock, 56.dp, Accent)
        Text("Enter your PIN", color = Fg, fontSize = 20.sp, fontWeight = FontWeight.Bold, modifier = Modifier.padding(top = 12.dp, bottom = 16.dp))
        PinField("PIN", pin) { pin = it.filter { c -> c.isDigit() }.take(8) }
        err?.let { Text(it, color = ErrRed, fontSize = 12.sp, modifier = Modifier.padding(top = 8.dp)) }
        Button(
            onClick = {
                val r = VideoVault.tryPin(ctx, pin)
                if (r < 0) {
                    err = "Wrong PIN"
                } else if (r > 0) {
                    err = "Too many attempts. Try again in $r s."
                }
                pin = ""
            },
            modifier = Modifier.padding(top = 16.dp)
        ) { Text("Unlock") }
        if (bio) {
            TextButton(onClick = { askBio() }) { Text("Use fingerprint", color = Accent) }
        }
        TextButton(onClick = onForgot) { Text("Forgot PIN?", color = Fg.copy(alpha = 0.7f)) }
    }
}
