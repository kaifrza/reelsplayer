@file:OptIn(androidx.compose.material3.ExperimentalMaterial3Api::class)

package com.reels.player

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.media.MediaMetadataRetriever
import android.net.Uri
import android.os.Build
import android.util.LruCache
import android.util.Size
import android.widget.Toast
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.material3.Slider
import androidx.compose.material3.SliderDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.rotate
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.ImageBitmap
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.media3.common.MediaItem
import androidx.media3.common.Player
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

// ---------- Album art ----------

val artCache = object : LruCache<String, ImageBitmap>((Runtime.getRuntime().maxMemory() / 16).toInt()) {
    override fun sizeOf(key: String, value: ImageBitmap): Int = value.width * value.height * 4
}

fun embeddedArt(ctx: Context, uri: Uri): Bitmap? {
    val r = MediaMetadataRetriever()
    return try {
        if (uri.scheme == "file") r.setDataSource(uri.path) else r.setDataSource(ctx, uri)
        val b = r.embeddedPicture
        if (b != null) BitmapFactory.decodeByteArray(b, 0, b.size) else null
    } catch (e: Exception) {
        null
    } finally {
        try { r.release() } catch (e: Exception) { }
    }
}

suspend fun loadArt(ctx: Context, uri: Uri, key: String, px: Int): ImageBitmap? {
    val ver = CustomArt.version
    val k = "$key@$px@$ver"
    val cached = artCache.get(k)
    if (cached != null) return cached
    val raw: Bitmap? = withContext(thumbDispatcher) { artBitmap(ctx, uri, px, key) }
    val img = raw?.asImageBitmap()
    if (img != null) artCache.put(k, img)
    return img
}

@Composable
fun ArtImage(uri: Uri?, key: String, px: Int, modifier: Modifier, corner: Dp = 10.dp) {
    val ctx = LocalContext.current
    val ver = CustomArt.version
    var bmp by remember(key, ver) { mutableStateOf<ImageBitmap?>(artCache.get("$key@$px@$ver")) }
    LaunchedEffect(key, ver) {
        if (bmp == null && uri != null) {
            delay(40)
            bmp = loadArt(ctx, uri, key, px)
        }
    }
    Box(
        modifier.clip(RoundedCornerShape(corner)).background(Accent.copy(alpha = 0.16f)),
        contentAlignment = Alignment.Center
    ) {
        val b = bmp
        if (b != null) {
            Image(
                bitmap = b,
                contentDescription = null,
                contentScale = ContentScale.Crop,
                modifier = Modifier.fillMaxSize()
            )
        } else {
            Ic(R.drawable.ic_music_note, 24.dp, Accent)
        }
    }
}

// ---------- Music library ----------

@Composable
fun SongRow(song: Song, playing: Boolean, onClick: () -> Unit) {
    Row(
        Modifier.fillMaxWidth().clickable(onClick = onClick).padding(horizontal = 16.dp, vertical = 8.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        ArtImage(song.uri, song.id.toString(), 128, Modifier.size(50.dp))
        Spacer(Modifier.width(12.dp))
        Column(Modifier.weight(1f)) {
            Text(
                song.title,
                color = if (playing) Accent else Fg,
                fontSize = 15.sp,
                fontWeight = if (playing) FontWeight.Bold else FontWeight.Normal,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis
            )
            Text(
                song.artist + "  •  " + fmt(song.durationMs),
                color = Fg.copy(alpha = 0.6f),
                fontSize = 12.sp,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis
            )
        }
        if (playing) Ic(R.drawable.ic_music_note, 20.dp, Accent)
    }
}

@Composable
fun SongList(list: List<Song>, onPlay: (List<Song>, Int, Boolean) -> Unit) {
    val currentId = MusicHub.current?.mediaId
    LazyColumn(Modifier.fillMaxSize(), contentPadding = PaddingValues(bottom = 16.dp)) {
        item {
            Row(
                Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 8.dp),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                Chip(R.drawable.ic_play, "Play all", true) { onPlay(list, 0, false) }
                Chip(R.drawable.ic_shuffle, "Shuffle") { onPlay(list, 0, true) }
            }
        }
        items(list.size, key = { list[it].id }) { i ->
            val s = list[i]
            SongRow(s, currentId == s.id.toString()) { onPlay(list, i, false) }
        }
    }
}

@Composable
fun MusicScreen(
    songs: List<Song>?,
    granted: Boolean,
    onGrant: () -> Unit,
    onOpenFiles: () -> Unit,
    onPlay: (List<Song>, Int, Boolean) -> Unit
) {
    var tab by remember { mutableIntStateOf(0) }
    var query by remember { mutableStateOf("") }
    var searching by remember { mutableStateOf(false) }
    var detail by remember { mutableStateOf<Pair<String, List<Song>>?>(null) }

    BackHandler(enabled = detail != null) { detail = null }
    BackHandler(enabled = searching) {
        searching = false
        query = ""
    }

    Column(Modifier.fillMaxSize().background(Bg)) {
        val d = detail
        Row(
            Modifier.fillMaxWidth().padding(start = 16.dp, end = 16.dp, top = 40.dp, bottom = 8.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            if (d != null) {
                CircleBtn(R.drawable.ic_back, onClick = { detail = null })
                Spacer(Modifier.width(12.dp))
            }
            Text(
                d?.first ?: "Music",
                color = Fg,
                fontSize = 26.sp,
                fontWeight = FontWeight.Bold,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis,
                modifier = Modifier.weight(1f)
            )
            if (d == null && granted && songs != null && songs.isNotEmpty()) {
                CircleBtn(R.drawable.ic_search, onClick = {
                    searching = !searching
                    if (!searching) query = ""
                    tab = 0
                })
            }
        }

        if (searching) {
            BasicTextField(
                value = query,
                onValueChange = { query = it },
                singleLine = true,
                textStyle = TextStyle(color = Fg, fontSize = 15.sp),
                cursorBrush = SolidColor(Accent),
                modifier = Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 4.dp)
                    .clip(RoundedCornerShape(12.dp)).background(CardBg)
                    .padding(horizontal = 14.dp, vertical = 12.dp),
                decorationBox = { inner ->
                    Box {
                        if (query.isEmpty()) {
                            Text("Search songs, artists or albums", color = Fg.copy(alpha = 0.5f), fontSize = 15.sp)
                        }
                        inner()
                    }
                }
            )
        }

        if (!granted) {
            Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                CenterMessage(
                    R.drawable.ic_music_note, "Music permission required",
                    "Allow audio access to show the songs on your device.", "Grant permission"
                ) { onGrant() }
            }
        } else if (songs == null) {
            Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                Text("Loading...", color = Fg.copy(alpha = 0.6f))
            }
        } else if (songs.isEmpty()) {
            Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                CenterMessage(
                    R.drawable.ic_music_note, "No songs found",
                    "You can also play any audio file from the Files section of the Videos tab.", "Open Files"
                ) { onOpenFiles() }
            }
        } else if (d != null) {
            SongList(d.second, onPlay)
        } else {
            if (!searching) {
                Row(
                    Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 4.dp),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    Chip(R.drawable.ic_music_note, "Songs", tab == 0) { tab = 0 }
                    Chip(R.drawable.ic_videos, "Albums", tab == 1) { tab = 1 }
                    Chip(R.drawable.ic_person, "Artists", tab == 2) { tab = 2 }
                }
            }
            if (tab == 0) {
                val q = query.trim()
                val shown = if (q.isEmpty()) songs else songs.filter {
                    it.title.contains(q, true) || it.artist.contains(q, true) || it.album.contains(q, true)
                }
                SongList(shown, onPlay)
            } else if (tab == 1) {
                val albums = remember(songs) {
                    songs.groupBy { it.album }.entries.sortedBy { it.key.lowercase() }
                }
                LazyVerticalGrid(
                    columns = GridCells.Fixed(2),
                    contentPadding = PaddingValues(12.dp),
                    horizontalArrangement = Arrangement.spacedBy(12.dp),
                    verticalArrangement = Arrangement.spacedBy(12.dp),
                    modifier = Modifier.fillMaxSize()
                ) {
                    items(albums, key = { it.key }) { a ->
                        val first = a.value.first()
                        Column(Modifier.clickable { detail = Pair(a.key, a.value) }) {
                            ArtImage(first.uri, first.id.toString(), 300, Modifier.fillMaxWidth().aspectRatio(1f), 14.dp)
                            Text(a.key, color = Fg, fontSize = 14.sp, fontWeight = FontWeight.SemiBold, maxLines = 1, overflow = TextOverflow.Ellipsis, modifier = Modifier.padding(top = 6.dp))
                            Text("${a.value.size} songs  •  ${first.artist}", color = Fg.copy(alpha = 0.6f), fontSize = 12.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
                        }
                    }
                }
            } else {
                val artists = remember(songs) {
                    songs.groupBy { it.artist }.entries.sortedBy { it.key.lowercase() }
                }
                LazyColumn(Modifier.fillMaxSize(), contentPadding = PaddingValues(bottom = 16.dp)) {
                    items(artists, key = { it.key }) { a ->
                        Row(
                            Modifier.fillMaxWidth().clickable { detail = Pair(a.key, a.value) }
                                .padding(horizontal = 16.dp, vertical = 10.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Box(
                                Modifier.size(46.dp).clip(CircleShape).background(Accent.copy(alpha = 0.16f)),
                                contentAlignment = Alignment.Center
                            ) { Ic(R.drawable.ic_person, 24.dp, Accent) }
                            Spacer(Modifier.width(12.dp))
                            Column(Modifier.weight(1f)) {
                                Text(a.key, color = Fg, fontSize = 15.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
                                Text("${a.value.size} songs", color = Fg.copy(alpha = 0.6f), fontSize = 12.sp)
                            }
                        }
                    }
                }
            }
        }
    }
}

// ---------- Mini player ----------

@Composable
fun MiniPlayer(onOpen: () -> Unit) {
    val item = MusicHub.current ?: return
    val md = item.mediaMetadata
    val frac = if (MusicHub.durMs > 0) (MusicHub.posMs.toFloat() / MusicHub.durMs).coerceIn(0f, 1f) else 0f
    Column(Modifier.fillMaxWidth().background(CardBg).clickable(onClick = onOpen)) {
        Box(Modifier.fillMaxWidth().height(2.dp).background(Fg.copy(alpha = 0.08f))) {
            Box(Modifier.fillMaxWidth(frac).height(2.dp).background(Accent))
        }
        Row(
            Modifier.fillMaxWidth().padding(horizontal = 12.dp, vertical = 8.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            ArtImage(item.localConfiguration?.uri, item.mediaId, 96, Modifier.size(44.dp))
            Column(Modifier.weight(1f).padding(horizontal = 12.dp)) {
                Text(
                    md.title?.toString() ?: "Unknown",
                    color = Fg, fontSize = 14.sp, fontWeight = FontWeight.SemiBold,
                    maxLines = 1, overflow = TextOverflow.Ellipsis
                )
                Text(
                    md.artist?.toString() ?: "",
                    color = Fg.copy(alpha = 0.6f), fontSize = 12.sp,
                    maxLines = 1, overflow = TextOverflow.Ellipsis
                )
            }
            Box(
                Modifier.size(42.dp).clip(CircleShape).clickable { MusicHub.prev() },
                contentAlignment = Alignment.Center
            ) {
                Ic(R.drawable.ic_skip_prev, 26.dp)
            }
            Box(
                Modifier.size(42.dp).clip(CircleShape).clickable { MusicHub.toggle() },
                contentAlignment = Alignment.Center
            ) {
                Ic(if (MusicHub.isPlaying) R.drawable.ic_pause else R.drawable.ic_play, 28.dp)
            }
            Box(
                Modifier.size(42.dp).clip(CircleShape).clickable { MusicHub.next() },
                contentAlignment = Alignment.Center
            ) {
                Ic(R.drawable.ic_skip_next, 26.dp)
            }
        }
    }
}

// ---------- Now playing ----------

@Composable
fun NowPlayingScreen(onClose: () -> Unit) {
    BackHandler { onClose() }
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    val item = MusicHub.current
    var panel by remember { mutableIntStateOf(0) }
    val pickArt = rememberLauncherForActivityResult(ActivityResultContracts.GetContent()) { u ->
        val key = MusicHub.current?.mediaId
        if (u != null && key != null) {
            scope.launch {
                val ok = withContext(Dispatchers.IO) { CustomArt.save(ctx, key, u) }
                if (ok) {
                    notifyArtChanged()
                    Toast.makeText(ctx, "Artwork updated", Toast.LENGTH_SHORT).show()
                } else {
                    Toast.makeText(ctx, "Couldn't use that image", Toast.LENGTH_SHORT).show()
                }
            }
        }
    }
    var scrub by remember { mutableStateOf(false) }
    var scrubV by remember { mutableFloatStateOf(0f) }

    Box(
        Modifier.fillMaxSize().background(Bg).pointerInput(Unit) { detectTapGestures { } }
    ) {
        if (item == null) {
            Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                Text("Nothing is playing", color = Fg.copy(alpha = 0.6f))
            }
        } else {
            val md = item.mediaMetadata
            val frac = if (MusicHub.durMs > 0) (MusicHub.posMs.toFloat() / MusicHub.durMs).coerceIn(0f, 1f) else 0f
            val curMs = if (scrub) (scrubV * MusicHub.durMs).toLong() else MusicHub.posMs

            Column(
                Modifier.fillMaxSize().padding(start = 24.dp, end = 24.dp, top = 40.dp, bottom = 24.dp),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                    CircleBtn(R.drawable.ic_expand_more, onClick = onClose)
                    Text(
                        "Now playing",
                        color = Fg, fontSize = 16.sp, fontWeight = FontWeight.SemiBold,
                        textAlign = TextAlign.Center, modifier = Modifier.weight(1f)
                    )
                    CircleBtn(R.drawable.ic_queue, onClick = { panel = 1 })
                }

                Spacer(Modifier.weight(1f))
                Box(
                    Modifier.fillMaxWidth(0.86f).aspectRatio(1f).clip(RoundedCornerShape(28.dp))
                        .clickable { panel = 4 }
                ) {
                    ArtImage(
                        item.localConfiguration?.uri, item.mediaId, 700,
                        Modifier.fillMaxSize(), 28.dp
                    )
                    Box(
                        Modifier.align(Alignment.BottomEnd).padding(12.dp).size(44.dp)
                            .clip(CircleShape).background(Accent),
                        contentAlignment = Alignment.Center
                    ) {
                        Ic(R.drawable.ic_image, 22.dp, Color.White)
                    }
                }
                Spacer(Modifier.weight(1f))

                Text(
                    md.title?.toString() ?: "Unknown",
                    color = Fg, fontSize = 22.sp, fontWeight = FontWeight.Bold,
                    maxLines = 2, overflow = TextOverflow.Ellipsis, textAlign = TextAlign.Center
                )
                Text(
                    (md.artist?.toString() ?: "") + (md.albumTitle?.let { "  •  $it" } ?: ""),
                    color = Fg.copy(alpha = 0.65f), fontSize = 14.sp,
                    maxLines = 1, overflow = TextOverflow.Ellipsis, textAlign = TextAlign.Center,
                    modifier = Modifier.padding(top = 4.dp)
                )

                Slider(
                    value = if (scrub) scrubV else frac,
                    onValueChange = {
                        scrub = true
                        scrubV = it
                    },
                    onValueChangeFinished = {
                        MusicHub.seekTo((scrubV * MusicHub.durMs).toLong())
                        scrub = false
                    },
                    modifier = Modifier.fillMaxWidth().padding(top = 12.dp),
                    colors = SliderDefaults.colors(
                        thumbColor = Accent,
                        activeTrackColor = Accent,
                        inactiveTrackColor = Fg.copy(alpha = 0.18f)
                    )
                )
                Row(Modifier.fillMaxWidth()) {
                    Text(fmt(curMs), color = Fg.copy(alpha = 0.7f), fontSize = 12.sp, modifier = Modifier.weight(1f))
                    Text(fmt(MusicHub.durMs), color = Fg.copy(alpha = 0.7f), fontSize = 12.sp)
                }

                Row(
                    Modifier.fillMaxWidth().padding(top = 10.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Box(Modifier.size(44.dp).clip(CircleShape).clickable { MusicHub.toggleShuffle() }, contentAlignment = Alignment.Center) {
                        Ic(R.drawable.ic_shuffle, 24.dp, if (MusicHub.shuffle) Accent else Fg.copy(alpha = 0.6f))
                    }
                    Box(Modifier.size(52.dp).clip(CircleShape).clickable { MusicHub.prev() }, contentAlignment = Alignment.Center) {
                        Ic(R.drawable.ic_skip_prev, 34.dp)
                    }
                    Box(
                        Modifier.size(74.dp).clip(CircleShape).background(Accent).clickable { MusicHub.toggle() },
                        contentAlignment = Alignment.Center
                    ) {
                        Ic(if (MusicHub.isPlaying) R.drawable.ic_pause else R.drawable.ic_play, 42.dp, Color.White)
                    }
                    Box(Modifier.size(52.dp).clip(CircleShape).clickable { MusicHub.next() }, contentAlignment = Alignment.Center) {
                        Ic(R.drawable.ic_skip_next, 34.dp)
                    }
                    Box(Modifier.size(44.dp).clip(CircleShape).clickable { MusicHub.toggleRepeat() }, contentAlignment = Alignment.Center) {
                        val on = MusicHub.repeat != Player.REPEAT_MODE_OFF
                        Ic(
                            if (MusicHub.repeat == Player.REPEAT_MODE_ONE) R.drawable.ic_repeat_one else R.drawable.ic_repeat,
                            24.dp,
                            if (on) Accent else Fg.copy(alpha = 0.6f)
                        )
                    }
                }

                Row(
                    Modifier.fillMaxWidth().padding(top = 18.dp),
                    horizontalArrangement = Arrangement.spacedBy(10.dp, Alignment.CenterHorizontally)
                ) {
                    Chip(R.drawable.ic_speed, fmtSpeed(MusicHub.speed)) { panel = 3 }
                    Chip(
                        R.drawable.ic_timer,
                        if (MusicHub.sleepEnd > 0) "Timer on" else "Sleep timer",
                        MusicHub.sleepEnd > 0
                    ) { panel = 2 }
                }
            }
        }

        if (panel == 1) {
            val q = MusicHub.queue
            val items = q.mapIndexed { i, mi ->
                PanelItem(
                    (mi.mediaMetadata.title?.toString() ?: "Unknown") + "  —  " + (mi.mediaMetadata.artist?.toString() ?: ""),
                    i == MusicHub.index
                ) {
                    MusicHub.playAt(i)
                    panel = 0
                }
            }
            Panel("Queue (${q.size})", items) { panel = 0 }
        } else if (panel == 2) {
            val opts = listOf(0, 15, 30, 45, 60, 90)
            val items = opts.map { m ->
                PanelItem(if (m == 0) "Off" else "$m minutes", m == 0 && MusicHub.sleepEnd == 0L) {
                    MusicHub.setSleep(m)
                    panel = 0
                }
            }
            Panel("Sleep timer", items) { panel = 0 }
        } else if (panel == 3) {
            SpeedPanel(MusicHub.speed, { MusicHub.changeSpeed(it) }, { panel = 0 })
        } else if (panel == 4 && item != null) {
            val key = item.mediaId
            val artItems: List<PanelItem> = buildList {
                add(PanelItem("Choose image from gallery", false) {
                    panel = 0
                    pickArt.launch("image/*")
                })
                if (CustomArt.exists(ctx, key)) {
                    add(PanelItem("Remove custom image", false) {
                        CustomArt.remove(ctx, key)
                        notifyArtChanged()
                        panel = 0
                    })
                }
            }
            Panel("Song artwork", artItems) { panel = 0 }
        }
    }
}
