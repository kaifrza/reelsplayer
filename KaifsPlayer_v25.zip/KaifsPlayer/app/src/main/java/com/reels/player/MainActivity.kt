@file:OptIn(
    androidx.media3.common.util.UnstableApi::class,
    androidx.compose.foundation.ExperimentalFoundationApi::class
)

package com.reels.player

import android.Manifest
import android.content.ContentUris
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.content.res.Configuration
import android.graphics.Bitmap
import android.media.MediaMetadataRetriever
import android.media.ThumbnailUtils
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.Environment
import android.os.StatFs
import android.provider.MediaStore
import android.provider.Settings
import android.util.LruCache
import android.util.Size
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.Spring
import androidx.compose.animation.core.spring
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.scaleIn
import androidx.compose.animation.scaleOut
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.combinedClickable
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.text.TextStyle
import androidx.compose.foundation.gestures.detectHorizontalDragGestures
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxScope
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.lazy.grid.itemsIndexed
import androidx.compose.foundation.pager.VerticalPager
import androidx.compose.foundation.pager.rememberPagerState
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Button
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.Immutable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.key
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableLongStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.ImageBitmap
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.hapticfeedback.HapticFeedbackType
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalConfiguration
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalHapticFeedback
import androidx.compose.ui.platform.LocalLifecycleOwner
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.IntOffset
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.core.content.ContextCompat
import androidx.core.content.FileProvider
import androidx.core.view.WindowCompat
import androidx.core.view.WindowInsetsCompat
import androidx.core.view.WindowInsetsControllerCompat
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.LifecycleEventObserver
import androidx.media3.common.MediaItem
import androidx.media3.common.Player
import androidx.media3.common.VideoSize
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.ui.AspectRatioFrameLayout
import androidx.media3.ui.PlayerView
import java.io.File
import java.util.concurrent.Executors
import kotlinx.coroutines.asCoroutineDispatcher
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.withContext
import kotlinx.coroutines.withTimeoutOrNull

// ---------- Data ----------

@Immutable
data class Video(
    val id: Long,
    val uri: Uri,
    val name: String,
    val folder: String,
    val durationMs: Long,
    val sizeBytes: Long,
    val added: Long
)

@Immutable
data class FolderItem(val key: String, val title: String, val videos: List<Video>)

@Immutable
data class Root(val name: String, val path: String)

@Immutable
data class FsEntry(
    val file: File,
    val isDir: Boolean,
    val size: Long,
    val modified: Long,
    val isVideo: Boolean,
    val isAudio: Boolean,
    val items: Int
)

class Listing(val entries: List<FsEntry>?)

class FsState(startPath: String) {
    var path by mutableStateOf<String?>(startPath)
    var sort by mutableIntStateOf(0)
    var videosOnly by mutableStateOf(false)
}

object AppState {
    var inPip by mutableStateOf(false)
    var movieActive = false
    var moviePlaying = false
    var autoPip = true
    var pipRequested = false
    var videoW = 0
    var videoH = 0
    var nowPlayingRequest by mutableIntStateOf(0)
    var libraryTick by mutableIntStateOf(0)
}

sealed class Screen {
    data class Reels(val list: List<Video>, val start: Int, val fromBrowse: Boolean) : Screen()
    object Home : Screen()
    object Browse : Screen()
    data class ReelsGrid(val list: List<Video>, val focus: Int) : Screen()
    object MusicTab : Screen()
    object SettingsTab : Screen()
    data class Movie(val list: List<Video>, val index: Int, val back: Screen) : Screen()
}

val fitNames = listOf("Smart", "Fit (full video)", "Fill (crop to screen)")

/** Decides whether to crop-to-fill (true) or letterbox (false). Smart = crop only when almost no content is lost. */
fun useZoom(videoAspect: Float, screenAspect: Float, mode: Int): Boolean = when (mode) {
    1 -> false
    2 -> videoAspect < 1f
    else -> (videoAspect / screenAspect) in 0.9f..1.11f
}

const val ALL_KEY = "__all__"
val Accent = Color(0xFFE1306C)
val LikeRed = Color(0xFFFF3B5C)
val sortNames = listOf("Newest", "Oldest", "Name A-Z", "Name Z-A", "Largest", "Smallest", "Longest", "Shortest")
val fsSortNames = listOf("Name", "Newest", "Size")
val videoExts = setOf("mp4", "mkv", "webm", "3gp", "3g2", "avi", "mov", "m4v", "ts", "flv", "wmv", "mpg", "mpeg", "mts")
val dateFmt = SimpleDateFormat("dd MMM yyyy", Locale.getDefault())

fun sortVideos(l: List<Video>, mode: Int): List<Video> = when (mode) {
    0 -> l.sortedByDescending { it.added }
    1 -> l.sortedBy { it.added }
    2 -> l.sortedBy { it.name.lowercase() }
    3 -> l.sortedByDescending { it.name.lowercase() }
    4 -> l.sortedByDescending { it.sizeBytes }
    5 -> l.sortedBy { it.sizeBytes }
    6 -> l.sortedByDescending { it.durationMs }
    else -> l.sortedBy { it.durationMs }
}

fun fmt(ms: Long): String {
    val s = (ms / 1000).coerceAtLeast(0)
    val h = s / 3600
    val m = (s % 3600) / 60
    val sec = s % 60
    return if (h > 0) "%d:%02d:%02d".format(h, m, sec) else "%d:%02d".format(m, sec)
}

fun fmtSize(b: Long): String {
    val kb = 1024.0
    val mb = kb * 1024
    val gb = mb * 1024
    return when {
        b >= gb -> "%.1f GB".format(b / gb)
        b >= mb -> "%.1f MB".format(b / mb)
        b >= kb -> "%.0f KB".format(b / kb)
        else -> "$b B"
    }
}

fun loadVideos(ctx: Context): List<Video> {
    val list = mutableListOf<Video>()
    val collection = MediaStore.Video.Media.EXTERNAL_CONTENT_URI
    val projection = arrayOf(
        MediaStore.Video.Media._ID,
        MediaStore.Video.Media.DISPLAY_NAME,
        MediaStore.Video.Media.BUCKET_DISPLAY_NAME,
        MediaStore.Video.Media.DURATION,
        MediaStore.Video.Media.SIZE,
        MediaStore.Video.Media.DATE_ADDED
    )
    ctx.contentResolver.query(
        collection, projection, null, null, "${MediaStore.Video.Media.DATE_ADDED} DESC"
    )?.use { c ->
        val idCol = c.getColumnIndexOrThrow(MediaStore.Video.Media._ID)
        val nameCol = c.getColumnIndexOrThrow(MediaStore.Video.Media.DISPLAY_NAME)
        val folderCol = c.getColumnIndexOrThrow(MediaStore.Video.Media.BUCKET_DISPLAY_NAME)
        val durCol = c.getColumnIndexOrThrow(MediaStore.Video.Media.DURATION)
        val sizeCol = c.getColumnIndexOrThrow(MediaStore.Video.Media.SIZE)
        val addCol = c.getColumnIndexOrThrow(MediaStore.Video.Media.DATE_ADDED)
        while (c.moveToNext()) {
            val id = c.getLong(idCol)
            list += Video(
                id = id,
                uri = ContentUris.withAppendedId(collection, id),
                name = c.getString(nameCol) ?: "",
                folder = c.getString(folderCol) ?: "Other",
                durationMs = c.getLong(durCol),
                sizeBytes = c.getLong(sizeCol),
                added = c.getLong(addCol)
            )
        }
    }
    return list
}

// ---------- File system helpers ----------

val durCache = LruCache<String, Long>(800)

fun readDuration(path: String): Long {
    val c = durCache.get(path)
    if (c != null) return c
    val r = MediaMetadataRetriever()
    val d = try {
        r.setDataSource(path)
        r.extractMetadata(MediaMetadataRetriever.METADATA_KEY_DURATION)?.toLongOrNull() ?: 0L
    } catch (e: Exception) {
        0L
    } finally {
        try { r.release() } catch (e: Exception) { }
    }
    durCache.put(path, d)
    return d
}

fun isVideoFile(f: File): Boolean = f.extension.lowercase() in videoExts

fun fileVideo(f: File): Video = Video(
    id = f.absolutePath.hashCode().toLong(),
    uri = Uri.fromFile(f),
    name = f.name,
    folder = f.parentFile?.name ?: "",
    durationMs = durCache.get(f.absolutePath) ?: 0L,
    sizeBytes = f.length(),
    added = f.lastModified() / 1000
)

fun storageRoots(ctx: Context): List<Root> {
    val out = mutableListOf<Root>()
    val primary = Environment.getExternalStorageDirectory().absolutePath
    out += Root("Internal storage", primary)
    ctx.getExternalFilesDirs(null).forEach { d ->
        val p = d?.absolutePath
        if (p != null) {
            val root = p.substringBefore("/Android/data")
            if (root != p && root != primary && out.none { it.path == root }) {
                out += Root("SD card (${File(root).name})", root)
            }
        }
    }
    return out
}

fun hasFileAccess(ctx: Context): Boolean =
    if (Build.VERSION.SDK_INT >= 30) Environment.isExternalStorageManager()
    else ContextCompat.checkSelfPermission(ctx, Manifest.permission.READ_EXTERNAL_STORAGE) == PackageManager.PERMISSION_GRANTED

fun openAllFilesSettings(ctx: Context) {
    if (Build.VERSION.SDK_INT >= 30) {
        try {
            ctx.startActivity(
                Intent(Settings.ACTION_MANAGE_APP_ALL_FILES_ACCESS_PERMISSION, Uri.parse("package:${ctx.packageName}"))
            )
        } catch (e: Exception) {
            ctx.startActivity(Intent(Settings.ACTION_MANAGE_ALL_FILES_ACCESS_PERMISSION))
        }
    }
}

fun listDir(path: String, sort: Int, videosOnly: Boolean): List<FsEntry>? {
    val files = File(path).listFiles() ?: return null
    val all = files.map { f ->
        val d = f.isDirectory
        FsEntry(
            file = f,
            isDir = d,
            size = if (d) 0L else f.length(),
            modified = f.lastModified(),
            isVideo = !d && isVideoFile(f),
            isAudio = !d && isAudioFile(f),
            items = 0
        )
    }
    val filtered = if (videosOnly) all.filter { it.isDir || it.isVideo || it.isAudio } else all
    val cmp: Comparator<FsEntry> = when (sort) {
        1 -> compareByDescending<FsEntry> { it.modified }
        2 -> compareByDescending<FsEntry> { it.size }
        else -> compareBy<FsEntry> { it.file.name.lowercase() }
    }
    return filtered.sortedWith(compareByDescending<FsEntry> { it.isDir }.then(cmp))
}

// ---------- Thumbnails ----------

val thumbDispatcher = Executors.newFixedThreadPool(3).asCoroutineDispatcher()

val thumbCache = object : LruCache<String, ImageBitmap>((Runtime.getRuntime().maxMemory() / 8).toInt()) {
    override fun sizeOf(key: String, value: ImageBitmap): Int = value.width * value.height * 4
}

@Suppress("DEPRECATION")
fun thumbRaw(ctx: Context, v: Video, w: Int, h: Int): Bitmap? {
    if (v.uri.scheme == "file") {
        val path = v.uri.path ?: return null
        return if (Build.VERSION.SDK_INT >= 29) {
            ThumbnailUtils.createVideoThumbnail(File(path), Size(w, h), null)
        } else {
            ThumbnailUtils.createVideoThumbnail(path, MediaStore.Video.Thumbnails.MINI_KIND)
        }
    }
    return if (Build.VERSION.SDK_INT >= 29) {
        ctx.contentResolver.loadThumbnail(v.uri, Size(w, h), null)
    } else {
        MediaStore.Video.Thumbnails.getThumbnail(
            ctx.contentResolver, v.id, MediaStore.Video.Thumbnails.MINI_KIND, null
        )
    }
}

suspend fun loadThumb(ctx: Context, v: Video, w: Int, h: Int): ImageBitmap? {
    val k = "${v.id}_${w}x$h"
    val cached = thumbCache.get(k)
    if (cached != null) return cached
    val raw: Bitmap? = withContext(thumbDispatcher) {
        runCatching { thumbRaw(ctx, v, w, h) }.getOrNull()
    }
    val bmp = raw?.asImageBitmap()
    if (bmp != null) thumbCache.put(k, bmp)
    return bmp
}

@Composable
fun Thumb(video: Video, w: Int, h: Int, modifier: Modifier) {
    val ctx = LocalContext.current
    var bmp by remember(video.id) { mutableStateOf<ImageBitmap?>(thumbCache.get("${video.id}_${w}x$h")) }
    LaunchedEffect(video.id) {
        if (bmp == null) {
            delay(40)
            bmp = loadThumb(ctx, video, w, h)
        }
    }
    Box(modifier.background(CardBg)) {
        bmp?.let {
            Image(
                bitmap = it,
                contentDescription = null,
                contentScale = ContentScale.Crop,
                modifier = Modifier.fillMaxSize()
            )
        }
    }
}

// ---------- Small UI pieces ----------

@Composable
fun Ic(res: Int, size: Dp = 24.dp, tint: Color = Fg, modifier: Modifier = Modifier) {
    Icon(
        painter = painterResource(res),
        contentDescription = null,
        tint = tint,
        modifier = modifier.size(size)
    )
}

@Composable
fun CircleBtn(res: Int, onClick: () -> Unit, modifier: Modifier = Modifier, size: Dp = 42.dp) {
    Box(
        modifier
            .size(size)
            .clip(CircleShape)
            .background(if (LocalDark.current) Color.Black.copy(alpha = 0.35f) else Color.Black.copy(alpha = 0.07f))
            .clickable(onClick = onClick),
        contentAlignment = Alignment.Center
    ) {
        Ic(res, 22.dp)
    }
}

@Composable
fun Chip(res: Int, text: String?, active: Boolean = false, onClick: () -> Unit) {
    val fg = if (active) Color.White else Fg
    Row(
        Modifier.clip(RoundedCornerShape(20.dp))
            .background(if (active) Accent else CardBg)
            .clickable(onClick = onClick)
            .padding(horizontal = 12.dp, vertical = 8.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Ic(res, 18.dp, fg)
        if (text != null) {
            Spacer(Modifier.width(6.dp))
            Text(text, color = fg, fontSize = 13.sp)
        }
    }
}

@Composable
fun ActionButton(
    res: Int,
    label: String,
    tint: Color = Color.White,
    scale: Float = 1f,
    onClick: () -> Unit
) {
    Column(
        horizontalAlignment = Alignment.CenterHorizontally,
        modifier = Modifier.padding(vertical = 8.dp).clickable(onClick = onClick)
    ) {
        Box(
            Modifier.size(50.dp).clip(CircleShape).background(Color.Black.copy(alpha = 0.32f)),
            contentAlignment = Alignment.Center
        ) {
            Ic(res, 26.dp, tint, Modifier.graphicsLayer { scaleX = scale; scaleY = scale })
        }
        Text(label, color = Color.White, fontSize = 11.sp, modifier = Modifier.padding(top = 3.dp))
    }
}

@Composable
fun CenterMessage(iconRes: Int, title: String, text: String, button: String?, onClick: () -> Unit) {
    Column(horizontalAlignment = Alignment.CenterHorizontally, modifier = Modifier.padding(32.dp)) {
        Ic(iconRes, 72.dp, Accent)
        Text(title, color = Fg, fontSize = 22.sp, fontWeight = FontWeight.Bold, modifier = Modifier.padding(top = 12.dp))
        Text(text, color = Fg.copy(alpha = 0.7f), textAlign = TextAlign.Center, modifier = Modifier.padding(top = 8.dp))
        if (button != null) {
            Button(onClick = onClick, modifier = Modifier.padding(top = 20.dp)) { Text(button) }
        }
    }
}

// ---------- Activity / App ----------

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        WindowCompat.setDecorFitsSystemWindows(window, false)
        WindowInsetsControllerCompat(window, window.decorView).apply {
            systemBarsBehavior = WindowInsetsControllerCompat.BEHAVIOR_SHOW_TRANSIENT_BARS_BY_SWIPE
            hide(WindowInsetsCompat.Type.systemBars())
        }
        CrashReporter.install(this)
        AppSettings.load(this)
        handleIntent(intent)
        setContent {
            AppRoot()
        }
    }

    private fun handleIntent(i: Intent?) {
        if (i != null && i.getBooleanExtra("open_now_playing", false)) {
            i.removeExtra("open_now_playing")
            AppState.nowPlayingRequest++
        }
    }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        setIntent(intent)
        handleIntent(intent)
    }

    override fun onDestroy() {
        MusicHub.release()
        super.onDestroy()
    }

    override fun onStop() {
        super.onStop()
        if (!isInPictureInPictureMode) PrivateVault.unlocked = false
    }

    override fun onUserLeaveHint() {
        super.onUserLeaveHint()
        if (AppState.movieActive && AppState.moviePlaying && AppState.autoPip && Build.VERSION.SDK_INT >= 26) {
            AppState.pipRequested = true
            enterPip(this, AppState.videoW, AppState.videoH)
        }
    }

    override fun onPictureInPictureModeChanged(isInPictureInPictureMode: Boolean, newConfig: Configuration) {
        super.onPictureInPictureModeChanged(isInPictureInPictureMode, newConfig)
        AppState.inPip = isInPictureInPictureMode
        if (!isInPictureInPictureMode) AppState.pipRequested = false
    }
}

fun lastIndex(ctx: Context, all: List<Video>): Int {
    val last = ctx.getSharedPreferences("reels", Context.MODE_PRIVATE).getString("last", null)
    return all.indexOfFirst { it.uri.toString() == last }.coerceAtLeast(0)
}

// ---------- Browse: common ----------

@Composable
fun BrowseHeader(title: String, subtitle: String, onBack: (() -> Unit)?, trailing: @Composable () -> Unit) {
    Row(
        Modifier.fillMaxWidth().padding(start = 12.dp, end = 12.dp, top = 32.dp, bottom = 10.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        if (onBack != null) {
            CircleBtn(R.drawable.ic_back, onClick = onBack)
        }
        Column(Modifier.weight(1f).padding(start = if (onBack != null) 12.dp else 4.dp, end = 12.dp)) {
            Text(title, color = Fg, fontSize = 22.sp, fontWeight = FontWeight.Bold, maxLines = 1, overflow = TextOverflow.Ellipsis)
            Text(subtitle, color = Fg.copy(alpha = 0.6f), fontSize = 13.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
        }
        trailing()
    }
}

@Composable
fun ModeTabs(mode: Int, onMode: (Int) -> Unit) {
    Row(
        Modifier.padding(horizontal = 12.dp, vertical = 4.dp),
        horizontalArrangement = Arrangement.spacedBy(8.dp)
    ) {
        Chip(R.drawable.ic_folder, "Files", mode == 0) { onMode(0) }
        Chip(R.drawable.ic_video, "Gallery", mode == 1) { onMode(1) }
        Chip(R.drawable.ic_replay, "Continue", mode == 2) { onMode(2) }
        Chip(R.drawable.ic_lock, "Private", mode == 3) { onMode(3) }
    }
}

// ---------- Browse: Files (real storage) ----------

@Composable
fun Crumbs(path: String, roots: List<Root>, onNavigate: (String?) -> Unit) {
    val root = roots.firstOrNull { path.startsWith(it.path) } ?: roots.first()
    val parts = path.removePrefix(root.path).split('/').filter { it.isNotEmpty() }
    val scroll = rememberScrollState()
    LaunchedEffect(path) {
        delay(60)
        scroll.scrollTo(scroll.maxValue)
    }
    Row(
        Modifier.fillMaxWidth().horizontalScroll(scroll).padding(horizontal = 12.dp, vertical = 4.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Box(Modifier.clip(CircleShape).clickable { onNavigate(null) }.padding(6.dp)) {
            Ic(R.drawable.ic_storage, 18.dp, Accent)
        }
        Text(
            root.name,
            color = Fg.copy(alpha = 0.85f),
            fontSize = 13.sp,
            modifier = Modifier.clickable { onNavigate(root.path) }.padding(6.dp)
        )
        var acc = root.path
        parts.forEach { part ->
            acc = "$acc/$part"
            val target = acc
            Ic(R.drawable.ic_chevron, 16.dp, Fg.copy(alpha = 0.4f))
            Text(
                part,
                color = Fg.copy(alpha = 0.85f),
                fontSize = 13.sp,
                modifier = Modifier.clickable { onNavigate(target) }.padding(6.dp)
            )
        }
    }
}

@Composable
fun RootCard(root: Root, onClick: () -> Unit) {
    val (free, total) = remember(root.path) {
        runCatching {
            val st = StatFs(root.path)
            st.availableBytes to st.totalBytes
        }.getOrDefault(0L to 0L)
    }
    val used = if (total > 0) (1f - free.toFloat() / total).coerceIn(0f, 1f) else 0f
    Row(
        Modifier.fillMaxWidth().clip(RoundedCornerShape(14.dp)).background(CardBg)
            .clickable(onClick = onClick).padding(14.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Box(
            Modifier.size(52.dp).clip(RoundedCornerShape(12.dp)).background(Accent.copy(alpha = 0.16f)),
            contentAlignment = Alignment.Center
        ) {
            Ic(R.drawable.ic_storage, 28.dp, Accent)
        }
        Spacer(Modifier.width(14.dp))
        Column(Modifier.weight(1f)) {
            Text(root.name, color = Fg, fontSize = 16.sp, fontWeight = FontWeight.SemiBold)
            Text("${fmtSize(free)} free of ${fmtSize(total)}", color = Fg.copy(alpha = 0.6f), fontSize = 12.sp)
            Box(
                Modifier.padding(top = 8.dp).fillMaxWidth().height(5.dp)
                    .clip(RoundedCornerShape(3.dp)).background(Fg.copy(alpha = 0.15f))
            ) {
                Box(Modifier.fillMaxWidth(used).height(5.dp).background(Accent))
            }
        }
    }
}

@Composable
fun FsRow(e: FsEntry, onClick: () -> Unit) {
    val usable = e.isDir || e.isVideo || e.isAudio
    val path = e.file.absolutePath
    var dur by remember(path) { mutableStateOf<Long?>(if (e.isVideo) durCache.get(path) else null) }
    LaunchedEffect(path) {
        if (e.isVideo && dur == null) {
            delay(250)
            dur = withContext(thumbDispatcher) { readDuration(path) }
        }
    }
    var childCount by remember(path) { mutableStateOf(-1) }
    LaunchedEffect(path) {
        if (e.isDir) {
            delay(120)
            childCount = withContext(thumbDispatcher) { e.file.list()?.size ?: 0 }
        }
    }
    val video = remember(path) { if (e.isVideo) fileVideo(e.file) else null }
    Row(
        Modifier.fillMaxWidth()
            .clickable(enabled = usable, onClick = onClick)
            .padding(horizontal = 14.dp, vertical = 8.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        val shape = RoundedCornerShape(10.dp)
        if (e.isDir) {
            Box(
                Modifier.size(54.dp).clip(shape).background(Accent.copy(alpha = 0.16f)),
                contentAlignment = Alignment.Center
            ) { Ic(R.drawable.ic_folder, 28.dp, Accent) }
        } else if (video != null) {
            Box(Modifier.size(54.dp).clip(shape)) {
                Thumb(video, 160, 160, Modifier.fillMaxSize())
            }
        } else if (e.isAudio) {
            Box(
                Modifier.size(54.dp).clip(shape).background(Accent.copy(alpha = 0.16f)),
                contentAlignment = Alignment.Center
            ) { Ic(R.drawable.ic_music_note, 26.dp, Accent) }
        } else {
            Box(
                Modifier.size(54.dp).clip(shape).background(CardBg),
                contentAlignment = Alignment.Center
            ) { Ic(R.drawable.ic_file, 26.dp, Fg.copy(alpha = 0.45f)) }
        }
        Spacer(Modifier.width(12.dp))
        Column(Modifier.weight(1f)) {
            Text(
                e.file.name,
                color = Fg.copy(alpha = if (usable) 1f else 0.45f),
                fontSize = 15.sp,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis
            )
            val date = dateFmt.format(Date(e.modified))
            val d = dur
            val sub = if (e.isDir) {
                if (childCount >= 0) "$childCount items  •  $date" else date
            } else if (e.isVideo) {
                if (d != null && d > 0) "${fmtSize(e.size)}  •  ${fmt(d)}  •  $date"
                else "${fmtSize(e.size)}  •  $date"
            } else {
                "${fmtSize(e.size)}  •  $date"
            }
            Text(sub, color = Fg.copy(alpha = 0.6f), fontSize = 12.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
        }
        if (e.isDir) {
            Ic(R.drawable.ic_chevron, 22.dp, Fg.copy(alpha = 0.5f))
        }
    }
}

@Composable
fun FilesScreen(
    fs: FsState,
    roots: List<Root>,
    onMode: (Int) -> Unit,
    onPlay: (List<Video>, Int) -> Unit,
    onMusic: (List<Song>, Int) -> Unit,
    onBack: () -> Unit
) {
    val ctx = LocalContext.current
    var access by remember { mutableStateOf(hasFileAccess(ctx)) }
    val owner = LocalLifecycleOwner.current
    DisposableEffect(owner) {
        val obs = LifecycleEventObserver { _, e ->
            if (e == Lifecycle.Event.ON_RESUME) {
                access = hasFileAccess(ctx)
            }
        }
        owner.lifecycle.addObserver(obs)
        onDispose { owner.lifecycle.removeObserver(obs) }
    }

    val path = fs.path
    var listing by remember { mutableStateOf<Listing?>(null) }
    LaunchedEffect(path, access, fs.sort, fs.videosOnly) {
        listing = null
        if (path != null && access) {
            listing = withContext(Dispatchers.IO) { Listing(listDir(path, fs.sort, fs.videosOnly)) }
        }
    }

    val l = listing
    val ents = l?.entries
    val root = roots.firstOrNull { path != null && path.startsWith(it.path) }
    val title = if (path == null) "Storage"
    else if (root != null && root.path == path) root.name
    else File(path).name
    val subtitle = if (path == null) "${roots.size} storage"
    else if (!access) "Permission required"
    else if (l == null) "Loading..."
    else if (ents == null) "Can't open folder"
    else "${ents.size} items"

    Column(Modifier.fillMaxSize().background(Bg)) {
        BrowseHeader(
            title,
            subtitle,
            if (path == null || (roots.size == 1 && roots.any { it.path == path })) null else onBack
        ) {
            if (path != null && access) {
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    Chip(R.drawable.ic_video, null, fs.videosOnly) { fs.videosOnly = !fs.videosOnly }
                    Chip(R.drawable.ic_sort, fsSortNames[fs.sort]) { fs.sort = (fs.sort + 1) % fsSortNames.size }
                }
            }
        }
        ModeTabs(0, onMode)
        if (path != null && access) {
            Crumbs(path, roots) { fs.path = it }
        }

        when {
            !access -> Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                CenterMessage(
                    R.drawable.ic_folder,
                    "Storage access required",
                    "To browse every folder on your device, allow 'All files access', then come back.",
                    "Allow access"
                ) { openAllFilesSettings(ctx) }
            }
            path == null -> Column(
                Modifier.padding(12.dp),
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                roots.forEach { r -> RootCard(r) { fs.path = r.path } }
            }
            l == null -> Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                Text("Loading...", color = Fg.copy(alpha = 0.6f))
            }
            ents == null -> Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                Text(
                    "This folder can't be opened (restricted by the system)",
                    color = Fg.copy(alpha = 0.6f),
                    textAlign = TextAlign.Center,
                    modifier = Modifier.padding(32.dp)
                )
            }
            ents.isEmpty() -> Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                Text("This folder is empty", color = Fg.copy(alpha = 0.6f))
            }
            else -> LazyColumn(Modifier.fillMaxSize(), contentPadding = PaddingValues(bottom = 24.dp)) {
                items(ents, key = { it.file.path }) { e ->
                    FsRow(e) {
                        if (e.isDir) {
                            fs.path = e.file.absolutePath
                        } else if (e.isVideo) {
                            val vids = ents.filter { it.isVideo }
                            val idx = vids.indexOfFirst { it.file == e.file }.coerceAtLeast(0)
                            onPlay(vids.map { fileVideo(it.file) }, idx)
                        } else if (e.isAudio) {
                            val auds = ents.filter { it.isAudio }
                            val ai = auds.indexOfFirst { it.file == e.file }.coerceAtLeast(0)
                            onMusic(auds.map { fileSong(it.file) }, ai)
                        }
                    }
                }
            }
        }
    }
}

// ---------- Browse: Gallery (MediaStore folders) ----------

@Composable
fun GalleryScreen(
    all: List<Video>,
    folder: String?,
    sort: Int,
    onFolder: (String?) -> Unit,
    onSort: (Int) -> Unit,
    onMode: (Int) -> Unit,
    onPlay: (List<Video>, Int) -> Unit,
    onBack: () -> Unit
) {
    val ctx = LocalContext.current
    var searching by remember { mutableStateOf(false) }
    var query by remember { mutableStateOf("") }
    var showSort by remember { mutableStateOf(false) }
    var actionVideo by remember { mutableStateOf<Video?>(null) }
    var hideItem by remember { mutableStateOf<FolderItem?>(null) }
    val searchActive = searching && query.isNotBlank()

    val folderItems = remember(all) {
        if (all.isEmpty()) emptyList<FolderItem>()
        else listOf(FolderItem(ALL_KEY, "All videos", all)) +
            all.groupBy { it.folder }
                .map { FolderItem(it.key, it.key, it.value) }
                .sortedBy { it.title.lowercase() }
    }
    val videoList = remember(all, folder, sort, searchActive, query) {
        if (searchActive) {
            val q = query.trim()
            sortVideos(all.filter { it.name.contains(q, ignoreCase = true) || it.folder.contains(q, ignoreCase = true) }, sort)
        } else if (folder == null) {
            emptyList()
        } else {
            sortVideos(if (folder == ALL_KEY) all else all.filter { it.folder == folder }, sort)
        }
    }
    val title = if (searching) "Search" else when (folder) {
        null -> "Gallery"
        ALL_KEY -> "All videos"
        else -> folder
    }
    val subtitle = if (searchActive) "${videoList.size} results"
    else if (folder == null) "${(folderItems.size - 1).coerceAtLeast(0)} folders  •  ${all.size} videos"
    else "${videoList.size} videos"

    Box(Modifier.fillMaxSize().background(Bg)) {
        Column(Modifier.fillMaxSize()) {
            BrowseHeader(title, subtitle, if (folder == null) null else onBack) {
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    Chip(R.drawable.ic_search, null, searching) {
                        searching = !searching
                        if (!searching) query = ""
                    }
                    if (folder != null || searching) {
                        Chip(R.drawable.ic_sort, sortNames[sort]) { showSort = true }
                    }
                }
            }
            ModeTabs(1, onMode)
            if (searching) {
                BasicTextField(
                    value = query,
                    onValueChange = { query = it },
                    singleLine = true,
                    textStyle = TextStyle(color = Fg, fontSize = 15.sp),
                    cursorBrush = SolidColor(Accent),
                    modifier = Modifier.fillMaxWidth().padding(horizontal = 12.dp, vertical = 6.dp)
                        .clip(RoundedCornerShape(12.dp)).background(CardBg)
                        .padding(horizontal = 14.dp, vertical = 12.dp),
                    decorationBox = { inner ->
                        Box {
                            if (query.isEmpty()) {
                                Text("Search all videos", color = Fg.copy(alpha = 0.5f), fontSize = 15.sp)
                            }
                            inner()
                        }
                    }
                )
            }

            if (folder == null && !searchActive) {
                LazyVerticalGrid(
                    columns = GridCells.Fixed(2),
                    contentPadding = PaddingValues(12.dp),
                    horizontalArrangement = Arrangement.spacedBy(10.dp),
                    verticalArrangement = Arrangement.spacedBy(10.dp),
                    modifier = Modifier.fillMaxSize()
                ) {
                    items(folderItems, key = { it.key }) { f ->
                        Box(
                            Modifier.fillMaxWidth().aspectRatio(1.25f)
                                .clip(RoundedCornerShape(14.dp))
                                .background(CardBg)
                                .combinedClickable(
                                    onClick = { onFolder(f.key) },
                                    onLongClick = { if (f.key != ALL_KEY) hideItem = f }
                                )
                        ) {
                            Thumb(f.videos.first(), 360, 288, Modifier.fillMaxSize())
                            Box(
                                Modifier.fillMaxSize().background(
                                    Brush.verticalGradient(listOf(Color.Transparent, Color.Black.copy(alpha = 0.78f)))
                                )
                            )
                            Column(Modifier.align(Alignment.BottomStart).padding(10.dp)) {
                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    Ic(R.drawable.ic_folder, 16.dp, Accent)
                                    Spacer(Modifier.width(6.dp))
                                    Text(f.title, color = Color.White, fontSize = 14.sp, fontWeight = FontWeight.SemiBold, maxLines = 1, overflow = TextOverflow.Ellipsis)
                                }
                                Text("${f.videos.size} videos", color = Color.White.copy(alpha = 0.7f), fontSize = 12.sp)
                            }
                        }
                    }
                }
            } else {
                LazyVerticalGrid(
                    columns = GridCells.Fixed(3),
                    contentPadding = PaddingValues(8.dp),
                    horizontalArrangement = Arrangement.spacedBy(6.dp),
                    verticalArrangement = Arrangement.spacedBy(6.dp),
                    modifier = Modifier.fillMaxSize()
                ) {
                    itemsIndexed(videoList, key = { _, v -> v.id }) { idx, v ->
                        Box(
                            Modifier.fillMaxWidth().aspectRatio(0.62f)
                                .clip(RoundedCornerShape(10.dp))
                                .background(CardBg)
                                .combinedClickable(
                                    onClick = { onPlay(videoList, idx) },
                                    onLongClick = { actionVideo = v }
                                )
                        ) {
                            Thumb(v, 300, 480, Modifier.fillMaxSize())
                            Box(
                                Modifier.align(Alignment.BottomCenter).fillMaxWidth().height(70.dp).background(
                                    Brush.verticalGradient(listOf(Color.Transparent, Color.Black.copy(alpha = 0.8f)))
                                )
                            )
                            Text(
                                fmt(v.durationMs),
                                color = Color.White,
                                fontSize = 11.sp,
                                fontWeight = FontWeight.Medium,
                                modifier = Modifier.align(Alignment.TopEnd).padding(6.dp)
                                    .background(Color.Black.copy(alpha = 0.6f), RoundedCornerShape(6.dp))
                                    .padding(horizontal = 5.dp, vertical = 2.dp)
                            )
                            Text(
                                v.name.substringBeforeLast('.'),
                                color = Color.White,
                                fontSize = 11.sp,
                                maxLines = 2,
                                overflow = TextOverflow.Ellipsis,
                                modifier = Modifier.align(Alignment.BottomStart).padding(6.dp)
                            )
                        }
                    }
                }
            }
        }

        if (showSort) {
            ChoiceDialog(
                title = "Sort by",
                options = sortNames,
                selected = sort,
                onPick = { i ->
                    onSort(i)
                    showSort = false
                },
                onDismiss = { showSort = false }
            )
        }
        val av = actionVideo
        if (av != null) {
            VideoActionsHost(
                v = av,
                onDismiss = { actionVideo = null },
                onGone = { msg ->
                    actionVideo = null
                    android.widget.Toast.makeText(ctx, msg, android.widget.Toast.LENGTH_SHORT).show()
                    AppState.libraryTick++
                }
            )
        }
        val hi = hideItem
        if (hi != null) {
            HideFolderDialog(
                folderTitle = hi.title,
                onHide = {
                    AppSettings.hideFolder(ctx, hi.key)
                    hideItem = null
                },
                onDismiss = { hideItem = null }
            )
        }
    }
}

// ---------- Reels ----------

@Composable
fun ReelsScreen(
    videos: List<Video>,
    startIndex: Int,
    rememberLast: Boolean,
    onBrowse: () -> Unit,
    onBack: ((Int) -> Unit)?,
    onMovie: (Video, Int) -> Unit
) {
    val ctx = LocalContext.current
    val haptic = LocalHapticFeedback.current
    val prefs = remember { ctx.getSharedPreferences("reels", Context.MODE_PRIVATE) }

    var liked by remember { mutableStateOf(prefs.getStringSet("liked", emptySet())!!.toSet()) }
    var muted by remember { mutableStateOf(prefs.getBoolean("muted", false)) }
    var uiVisible by remember { mutableStateOf(prefs.getBoolean("ui_visible", true)) }
    var fitMode by remember { mutableIntStateOf(prefs.getInt("fit_mode", 0)) }
    val cfg = LocalConfiguration.current
    val screenAspect = cfg.screenWidthDp.toFloat() / cfg.screenHeightDp.coerceAtLeast(1)
    var userPaused by remember { mutableStateOf(false) }
    var fast by remember { mutableStateOf(false) }
    var holdSpeed by remember { mutableFloatStateOf(2f) }
    var menuVideo by remember { mutableStateOf<Video?>(null) }
    var infoVideo by remember { mutableStateOf<Video?>(null) }

    fun setLiked(key: String, on: Boolean) {
        liked = if (on) liked + key else liked - key
        prefs.edit().putStringSet("liked", liked.toSet()).apply()
    }

    val players = remember {
        Array(2) {
            ExoPlayer.Builder(ctx).build().apply {
                repeatMode = Player.REPEAT_MODE_ONE
                playWhenReady = false
            }
        }
    }
    var aspect0 by remember { mutableFloatStateOf(0.5625f) }
    var aspect1 by remember { mutableFloatStateOf(0.5625f) }
    var uri0 by remember { mutableStateOf<Uri?>(null) }
    var uri1 by remember { mutableStateOf<Uri?>(null) }

    DisposableEffect(players) {
        val listeners = Array<Player.Listener>(2) { i ->
            object : Player.Listener {
                override fun onVideoSizeChanged(videoSize: VideoSize) {
                    var w = videoSize.width * videoSize.pixelWidthHeightRatio
                    var h = videoSize.height.toFloat()
                    if (videoSize.unappliedRotationDegrees % 180 != 0) {
                        val t = w
                        w = h
                        h = t
                    }
                    if (w > 0f && h > 0f) {
                        if (i == 0) aspect0 = w / h else aspect1 = w / h
                    }
                }

                override fun onMediaItemTransition(mediaItem: MediaItem?, reason: Int) {
                    val u = mediaItem?.localConfiguration?.uri
                    if (i == 0) uri0 = u else uri1 = u
                }
            }
        }
        players[0].addListener(listeners[0])
        players[1].addListener(listeners[1])
        onDispose {
            players[0].removeListener(listeners[0])
            players[1].removeListener(listeners[1])
            players[0].release()
            players[1].release()
        }
    }

    val pager = rememberPagerState(initialPage = startIndex.coerceIn(0, videos.size - 1)) { videos.size }
    val settled = pager.settledPage
    val exo = players[settled % 2]
    BackHandler { onBack?.invoke(settled) }

    val owner = LocalLifecycleOwner.current
    DisposableEffect(owner) {
        val obs = LifecycleEventObserver { _, e ->
            val cur = players[pager.settledPage % 2]
            if (e == Lifecycle.Event.ON_PAUSE) {
                cur.pause()
            }
            if (e == Lifecycle.Event.ON_RESUME && !userPaused) {
                cur.play()
            }
        }
        owner.lifecycle.addObserver(obs)
        onDispose { owner.lifecycle.removeObserver(obs) }
    }

    LaunchedEffect(settled) {
        val v = videos[settled]
        if (rememberLast) prefs.edit().putString("last", v.uri.toString()).apply()
        userPaused = false
        fast = false
        val cur = players[settled % 2]
        val other = players[(settled + 1) % 2]
        other.pause()
        other.setPlaybackSpeed(1f)
        cur.setPlaybackSpeed(1f)
        val loaded = cur.currentMediaItem?.localConfiguration?.uri
        if (loaded != v.uri) {
            cur.setMediaItem(MediaItem.fromUri(v.uri))
            cur.prepare()
        } else {
            cur.seekTo(0L)
        }
        cur.volume = if (muted) 0f else 1f
        cur.play()
        // Preload the next reel on the other player so the swipe is instant
        val ni = settled + 1
        if (ni < videos.size) {
            val nu = videos[ni].uri
            if (other.currentMediaItem?.localConfiguration?.uri != nu) {
                other.setMediaItem(MediaItem.fromUri(nu))
                other.prepare()
            } else {
                other.seekTo(0L)
            }
            other.volume = 0f
            other.playWhenReady = false
        }
    }
    LaunchedEffect(muted) {
        players[pager.settledPage % 2].volume = if (muted) 0f else 1f
        prefs.edit().putBoolean("muted", muted).apply()
    }
    LaunchedEffect(uiVisible) {
        prefs.edit().putBoolean("ui_visible", uiVisible).apply()
    }

    Box(Modifier.fillMaxSize().background(Color.Black)) {
        VerticalPager(state = pager, modifier = Modifier.fillMaxSize()) { page ->
            val video = videos[page]
            val key = video.uri.toString()
            val isCurrent = page == pager.settledPage
            val isLiked = key in liked

            var heartTick by remember { mutableIntStateOf(0) }
            var showHeart by remember { mutableStateOf(false) }
            var heartPos by remember { mutableStateOf(Offset.Zero) }
            var thumb by remember(key) { mutableStateOf<ImageBitmap?>(null) }
            val likeScale = remember { Animatable(1f) }

            LaunchedEffect(heartTick) {
                if (heartTick > 0) {
                    showHeart = true
                    delay(700)
                    showHeart = false
                }
            }
            LaunchedEffect(isLiked) {
                if (isLiked) {
                    likeScale.animateTo(1.35f, tween(120))
                    likeScale.animateTo(1f, spring(Spring.DampingRatioMediumBouncy))
                }
            }
            LaunchedEffect(key) {
                thumb = loadThumb(ctx, video, 360, 640)
            }

            Box(Modifier.fillMaxSize().background(Color.Black)) {
                thumb?.let {
                    Image(
                        bitmap = it,
                        contentDescription = null,
                        contentScale = if (useZoom(it.width.toFloat() / it.height, screenAspect, fitMode)) ContentScale.Crop else ContentScale.Fit,
                        modifier = Modifier.fillMaxSize()
                    )
                }

                val pageAspect = if (page % 2 == 0) aspect0 else aspect1
                val bound = (if (page % 2 == 0) uri0 else uri1) == video.uri
                AndroidView(
                    factory = { c ->
                        PlayerView(c).apply {
                            useController = false
                            keepScreenOn = true
                            setShutterBackgroundColor(android.graphics.Color.TRANSPARENT)
                        }
                    },
                    update = { pv ->
                        pv.player = if (bound) players[page % 2] else null
                        pv.resizeMode = if (useZoom(pageAspect, screenAspect, fitMode)) AspectRatioFrameLayout.RESIZE_MODE_ZOOM
                        else AspectRatioFrameLayout.RESIZE_MODE_FIT
                    },
                    modifier = Modifier.fillMaxSize()
                )

                // Scrims for readable text (hidden with the UI)
                AnimatedVisibility(
                    visible = uiVisible,
                    modifier = Modifier.fillMaxSize(),
                    enter = fadeIn(),
                    exit = fadeOut()
                ) {
                    Box(Modifier.fillMaxSize()) {
                        Box(
                            Modifier.align(Alignment.BottomCenter).fillMaxWidth().height(300.dp)
                                .background(Brush.verticalGradient(listOf(Color.Transparent, Color.Black.copy(alpha = 0.75f))))
                        )
                        Box(
                            Modifier.align(Alignment.TopCenter).fillMaxWidth().height(150.dp)
                                .background(Brush.verticalGradient(listOf(Color.Black.copy(alpha = 0.6f), Color.Transparent)))
                        )
                    }
                }

                // Gestures: tap = pause/play, hold = 2x speed, double tap = like
                Box(
                    Modifier.fillMaxSize().pointerInput(page, isCurrent) {
                        detectTapGestures(
                            onLongPress = { },
                            onTap = {
                                if (isCurrent) {
                                    if (userPaused) { exo.play(); userPaused = false }
                                    else { exo.pause(); userPaused = true }
                                }
                            },
                            onDoubleTap = { off ->
                                if (!isLiked) {
                                    setLiked(key, true)
                                    haptic.performHapticFeedback(HapticFeedbackType.LongPress)
                                }
                                heartPos = off
                                heartTick++
                            }
                        )
                    }.pointerInput(page, isCurrent) {
                        holdSlideSpeed(
                            canStart = { isCurrent && !userPaused },
                            onSpeed = { sp ->
                                exo.setPlaybackSpeed(sp)
                                holdSpeed = sp
                                fast = true
                            },
                            onEnd = {
                                exo.setPlaybackSpeed(1f)
                                fast = false
                            }
                        )
                    }
                )

                AnimatedVisibility(
                    visible = showHeart,
                    enter = scaleIn(spring(Spring.DampingRatioMediumBouncy)) + fadeIn(),
                    exit = fadeOut() + scaleOut(),
                    modifier = Modifier.offset {
                        IntOffset((heartPos.x - 45.dp.toPx()).toInt(), (heartPos.y - 55.dp.toPx()).toInt())
                    }
                ) {
                    Ic(R.drawable.ic_heart, 90.dp, LikeRed)
                }

                if (isCurrent && userPaused) {
                    Box(
                        Modifier.align(Alignment.Center).size(76.dp).clip(CircleShape)
                            .background(Color.Black.copy(alpha = 0.45f)),
                        contentAlignment = Alignment.Center
                    ) {
                        Ic(R.drawable.ic_play, 44.dp)
                    }
                }

                // Side actions + caption (hidden with the UI)
                AnimatedVisibility(
                    visible = uiVisible,
                    modifier = Modifier.fillMaxSize(),
                    enter = fadeIn(),
                    exit = fadeOut()
                ) {
                    Box(Modifier.fillMaxSize()) {
                        Column(
                            modifier = Modifier.align(Alignment.BottomEnd).padding(end = 12.dp, bottom = 84.dp),
                            horizontalAlignment = Alignment.CenterHorizontally
                        ) {
                            ActionButton(
                                res = if (isLiked) R.drawable.ic_heart else R.drawable.ic_heart_outline,
                                label = if (isLiked) "Liked" else "Like",
                                tint = if (isLiked) LikeRed else Color.White,
                                scale = likeScale.value
                            ) { setLiked(key, !isLiked) }
                            ActionButton(
                                res = if (muted) R.drawable.ic_volume_off else R.drawable.ic_volume_on,
                                label = if (muted) "Unmute" else "Mute"
                            ) { muted = !muted }
                            ActionButton(res = R.drawable.ic_share, label = "Share") {
                                val shareUri = if (video.uri.scheme == "file") {
                                    runCatching {
                                        FileProvider.getUriForFile(
                                            ctx, "${ctx.packageName}.fileprovider", File(video.uri.path ?: "")
                                        )
                                    }.getOrDefault(video.uri)
                                } else {
                                    video.uri
                                }
                                val i = Intent(Intent.ACTION_SEND).apply {
                                    type = "video/*"
                                    putExtra(Intent.EXTRA_STREAM, shareUri)
                                    addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
                                }
                                ctx.startActivity(Intent.createChooser(i, "Share video"))
                            }
                            ActionButton(res = R.drawable.ic_more_vert, label = "More") {
                                menuVideo = video
                            }
                        }

                        Column(
                            Modifier.align(Alignment.BottomStart).padding(start = 16.dp, end = 86.dp, bottom = 80.dp)
                        ) {
                            Text(
                                video.name.substringBeforeLast('.'),
                                color = Color.White,
                                fontSize = 15.sp,
                                fontWeight = FontWeight.SemiBold,
                                maxLines = 2,
                                overflow = TextOverflow.Ellipsis
                            )
                            Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.padding(top = 4.dp)) {
                                Ic(R.drawable.ic_folder, 14.dp, Color.White.copy(alpha = 0.75f))
                                Spacer(Modifier.width(4.dp))
                                Text(
                                    video.folder,
                                    color = Color.White.copy(alpha = 0.75f),
                                    fontSize = 12.sp,
                                    maxLines = 1,
                                    overflow = TextOverflow.Ellipsis
                                )
                            }
                        }
                    }
                }
            }
        }

        // Fixed header, time and progress bar (hidden with the UI)
        AnimatedVisibility(
            visible = uiVisible,
            modifier = Modifier.fillMaxSize(),
            enter = fadeIn(),
            exit = fadeOut()
        ) {
            Box(Modifier.fillMaxSize()) {
                Row(
                    Modifier.align(Alignment.TopCenter).fillMaxWidth()
                        .padding(start = 12.dp, end = 64.dp, top = 28.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    if (onBack != null) {
                        CircleBtn(R.drawable.ic_back, onClick = { onBack(pager.settledPage) })
                        Spacer(Modifier.width(10.dp))
                    }
                    Text("Reels", color = Color.White, fontSize = 26.sp, fontWeight = FontWeight.Bold, modifier = Modifier.weight(1f))
                    Text("${pager.currentPage + 1} / ${videos.size}", color = Color.White.copy(alpha = 0.85f), fontSize = 14.sp)
                }
            }
        }

        // Progress line + time badge: always visible, even when the UI is hidden
        ReelsSeekLayer(exo, videos[settled].durationMs)

        // Hold + slide speed badge
        if (fast) {
            SpeedBadge(holdSpeed, Modifier.align(Alignment.TopCenter).padding(top = SpeedBadgeTop))
        }

        // 3-dot menu
        val mv = menuVideo
        if (mv != null) {
            Box(
                Modifier.fillMaxSize().background(Color.Black.copy(alpha = 0.45f))
                    .clickable { menuVideo = null }
            ) {
                Column(
                    Modifier.align(Alignment.BottomEnd).padding(end = 80.dp, bottom = 90.dp)
                        .width(250.dp).clip(RoundedCornerShape(14.dp)).background(Color(0xFF1C1C22))
                        .clickable(onClick = { })
                ) {
                    MenuRow(R.drawable.ic_movie, "Open in Movie player") {
                        menuVideo = null
                        onMovie(mv, videos.indexOfFirst { it.uri == mv.uri }.coerceAtLeast(0))
                    }
                    MenuRow(R.drawable.ic_aspect, "Video fit: ${fitNames[fitMode]}") {
                        fitMode = (fitMode + 1) % fitNames.size
                        prefs.edit().putInt("fit_mode", fitMode).apply()
                        menuVideo = null
                    }
                    MenuRow(R.drawable.ic_info, "Video details") {
                        infoVideo = mv
                        menuVideo = null
                    }
                }
            }
        }
        val iv = infoVideo
        if (iv != null) {
            Box(
                Modifier.fillMaxSize().background(Color.Black.copy(alpha = 0.55f))
                    .clickable { infoVideo = null },
                contentAlignment = Alignment.Center
            ) {
                Column(
                    Modifier.fillMaxWidth(0.88f).clip(RoundedCornerShape(16.dp))
                        .background(Color(0xFF1C1C22)).padding(18.dp)
                        .clickable(onClick = { })
                ) {
                    Text("Video details", color = Color.White, fontSize = 17.sp, fontWeight = FontWeight.Bold)
                    Spacer(Modifier.height(10.dp))
                    Text(iv.name, color = Color.White, fontSize = 14.sp)
                    Text("Folder: ${iv.folder}", color = Color.White.copy(alpha = 0.7f), fontSize = 13.sp, modifier = Modifier.padding(top = 6.dp))
                    Text("Size: ${fmtSize(iv.sizeBytes)}", color = Color.White.copy(alpha = 0.7f), fontSize = 13.sp)
                    Text("Duration: ${fmt(iv.durationMs)}", color = Color.White.copy(alpha = 0.7f), fontSize = 13.sp)
                    Text("Path: ${videoPath(ctx, iv) ?: iv.uri}", color = Color.White.copy(alpha = 0.7f), fontSize = 12.sp)
                }
            }
        }

        // Show / hide UI toggle (always visible, faint when UI is hidden)
        Box(
            Modifier.align(Alignment.TopEnd).padding(end = 12.dp, top = 28.dp)
                .graphicsLayer { alpha = if (uiVisible) 1f else 0.4f }
        ) {
            CircleBtn(
                if (uiVisible) R.drawable.ic_fullscreen else R.drawable.ic_fullscreen_exit,
                onClick = { uiVisible = !uiVisible }
            )
        }
    }
}


/** Position / time / seek bar live here so their 10x-per-second updates never recompose the whole pager. */
@Composable
fun BoxScope.ReelsSeekLayer(exo: ExoPlayer, fallbackDurMs: Long) {
    var posMs by remember(exo) { mutableLongStateOf(0L) }
    var durMs by remember(exo) { mutableLongStateOf(0L) }
    var seeking by remember { mutableStateOf(false) }

    LaunchedEffect(exo) {
        while (true) {
            posMs = exo.currentPosition.coerceAtLeast(0)
            durMs = exo.duration.coerceAtLeast(0)
            delay(100)
        }
    }

    val totalMs = if (durMs > 0) durMs else fallbackDurMs
    val progress = if (totalMs > 0) (posMs.toFloat() / totalMs).coerceIn(0f, 1f) else 0f

    fun seekFraction(f: Float) {
        val d = exo.duration
        if (d > 0) {
            val t = (d * f.coerceIn(0f, 1f)).toLong()
            exo.seekTo(t)
            posMs = t
        }
    }

    if (seeking) {
        Box(
            Modifier.align(Alignment.Center)
                .background(Color.Black.copy(alpha = 0.55f), RoundedCornerShape(12.dp))
                .padding(horizontal = 18.dp, vertical = 10.dp)
        ) {
            Text("${fmt(posMs)} / ${fmt(totalMs)}", color = Color.White, fontSize = 20.sp, fontWeight = FontWeight.Medium)
        }
    }

    Text(
        "${fmt(posMs)} / ${fmt(totalMs)}",
        color = Color.White,
        fontSize = 12.sp,
        fontWeight = FontWeight.Medium,
        modifier = Modifier.align(Alignment.BottomEnd).padding(end = 16.dp, bottom = 40.dp)
            .background(Color.Black.copy(alpha = 0.55f), RoundedCornerShape(8.dp))
            .padding(horizontal = 8.dp, vertical = 3.dp)
    )

    Box(
        Modifier.align(Alignment.BottomCenter).fillMaxWidth().height(34.dp)
            .pointerInput(Unit) {
                detectTapGestures { o -> seekFraction(o.x / size.width) }
            }
            .pointerInput(Unit) {
                detectHorizontalDragGestures(
                    onDragStart = { seeking = true },
                    onDragEnd = { seeking = false },
                    onDragCancel = { seeking = false }
                ) { change, _ ->
                    change.consume()
                    seekFraction(change.position.x / size.width)
                }
            }
    ) {
        val h = if (seeking) 7.dp else 3.dp
        Box(Modifier.align(Alignment.BottomStart).padding(bottom = 4.dp).fillMaxWidth().height(h).background(Color.White.copy(alpha = 0.3f)))
        Box(Modifier.align(Alignment.BottomStart).padding(bottom = 4.dp).fillMaxWidth(progress).height(h).background(Accent))
    }
}
