@file:OptIn(androidx.compose.foundation.ExperimentalFoundationApi::class)

package com.reels.player

import android.Manifest
import android.content.ContentUris
import android.content.Context
import android.content.pm.PackageManager
import android.media.MediaScannerConnection
import android.net.Uri
import android.os.Build
import android.os.Environment
import android.provider.MediaStore
import android.widget.Toast
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.foundation.background
import androidx.compose.foundation.combinedClickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.itemsIndexed
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.ContextCompat
import java.io.File
import java.io.FileInputStream
import java.io.FileOutputStream
import java.security.MessageDigest
import java.util.UUID
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import org.json.JSONArray
import org.json.JSONObject

class VaultItem(
    val file: String,
    val name: String,
    val origPath: String,
    val durationMs: Long,
    val size: Long,
    val hiddenAt: Long
)

class VaultException(msg: String) : Exception(msg)

/**
 * Real "hide": the video is MOVED out of shared storage into the app's private internal storage
 * (/data/data/<package>/files/vault). No gallery, file manager or other app can see it there.
 * It can only be opened from Settings > Hidden videos, behind a PIN.
 */
object VideoVault {
    private const val PREFS = "vault"
    private const val MARK = "/files/vault/"

    /** Bumped whenever the hidden set or the media library changes, so lists reload. */
    val version = mutableIntStateOf(0)

    /** Uris hidden in this session; filtered from in-app lists until MediaStore catches up. */
    val removed = mutableStateListOf<Uri>()

    var unlocked by mutableStateOf(false)

    private var fails = 0
    private var lockUntil = 0L
    private val lock = Any()

    private fun prefs(ctx: Context) = ctx.getSharedPreferences(PREFS, Context.MODE_PRIVATE)

    fun dir(ctx: Context): File = File(ctx.filesDir, "vault").also { it.mkdirs() }

    fun isVault(uri: Uri?): Boolean =
        uri != null && uri.scheme == "file" && (uri.path ?: "").contains(MARK)

    fun isVaultKey(key: String): Boolean = key.startsWith("file:") && key.contains(MARK)

    // ---------- Index ----------

    private fun readIndex(ctx: Context): MutableList<VaultItem> {
        val s = prefs(ctx).getString("items", null) ?: return mutableListOf()
        return runCatching {
            val a = JSONArray(s)
            (0 until a.length()).map { i ->
                val o = a.getJSONObject(i)
                VaultItem(
                    o.getString("f"), o.optString("n"), o.optString("p"),
                    o.optLong("d"), o.optLong("s"), o.optLong("t")
                )
            }.toMutableList()
        }.getOrDefault(mutableListOf())
    }

    private fun writeIndex(ctx: Context, l: List<VaultItem>) {
        val a = JSONArray()
        l.forEach {
            a.put(
                JSONObject().put("f", it.file).put("n", it.name).put("p", it.origPath)
                    .put("d", it.durationMs).put("s", it.size).put("t", it.hiddenAt)
            )
        }
        prefs(ctx).edit().putString("items", a.toString()).commit()
    }

    fun items(ctx: Context): List<VaultItem> = synchronized(lock) {
        val d = dir(ctx)
        val known = readIndex(ctx).filter { File(d, it.file).exists() }
        val orphans = (d.listFiles() ?: emptyArray())
            .filter { f -> f.isFile && isVideoFile(f) && known.none { it.file == f.name } }
            .map { VaultItem(it.name, it.name, "", 0L, it.length(), it.lastModified() / 1000) }
        (known + orphans).sortedByDescending { it.hiddenAt }
    }

    fun toVideo(ctx: Context, item: VaultItem): Video {
        val f = File(dir(ctx), item.file)
        val dur = if (item.durationMs > 0) item.durationMs else readDuration(f.absolutePath)
        return Video(
            id = item.file.hashCode().toLong(),
            uri = Uri.fromFile(f),
            name = item.name,
            folder = "Hidden",
            durationMs = dur,
            sizeBytes = item.size,
            added = item.hiddenAt
        )
    }

    fun videos(ctx: Context): List<Video> = items(ctx).map { toVideo(ctx, it) }

    fun itemFor(ctx: Context, v: Video): VaultItem? {
        val n = File(v.uri.path ?: return null).name
        return items(ctx).firstOrNull { it.file == n }
    }

    /** Leftover half-copied files from a killed process. Call at app start only. */
    fun cleanupPartials(ctx: Context) {
        (dir(ctx).listFiles() ?: emptyArray()).forEach { if (it.name.endsWith(".part")) it.delete() }
    }

    // ---------- Resume positions for hidden videos (never shown in Continue watching) ----------

    fun savePos(ctx: Context, key: String, pos: Long) {
        prefs(ctx).edit().putLong("pos_" + key.hashCode(), pos).apply()
    }

    fun getPos(ctx: Context, key: String): Long = prefs(ctx).getLong("pos_" + key.hashCode(), 0L)

    // ---------- File moving ----------

    private fun moveFile(src: File, dest: File, onProgress: (Float) -> Unit, alive: () -> Boolean) {
        if (src.renameTo(dest)) {
            onProgress(1f)
            return
        }
        val parent = dest.parentFile ?: throw VaultException("Invalid destination.")
        parent.mkdirs()
        val total = src.length()
        if (parent.usableSpace < total + 20L * 1024 * 1024) {
            throw VaultException("Not enough free storage on the phone. Free up ${fmtSize(total)} and try again.")
        }
        val part = File(parent, dest.name + ".part")
        try {
            FileInputStream(src).use { ins ->
                FileOutputStream(part).use { out ->
                    val buf = ByteArray(1 shl 20)
                    var done = 0L
                    while (true) {
                        val n = ins.read(buf)
                        if (n < 0) break
                        if (!alive()) throw VaultException("Cancelled.")
                        out.write(buf, 0, n)
                        done += n
                        if (total > 0) onProgress((done.toFloat() / total).coerceIn(0f, 1f))
                    }
                    out.fd.sync()
                }
            }
            if (part.length() != total) throw VaultException("Copy failed (size mismatch). Your original file is untouched.")
            if (!part.renameTo(dest)) throw VaultException("Couldn't finish the copy.")
        } catch (e: Exception) {
            part.delete()
            dest.delete()
            if (e is VaultException) throw e
            throw VaultException("Couldn't copy the video: ${e.message ?: "unknown error"}. Your original file is untouched.")
        }
        if (!src.delete()) {
            dest.delete()
            throw VaultException(
                "Android didn't allow removing the original file, so nothing was hidden. " +
                    "Allow 'All files access' for KaifsPlayer in Settings and try again."
            )
        }
        onProgress(1f)
    }

    // ---------- Hide ----------

    /** Returns null on success, or an error message. Runs blocking: call from Dispatchers.IO. */
    fun hide(ctx: Context, v: Video, onProgress: (Float) -> Unit, alive: () -> Boolean): String? {
        val path = videoPath(ctx, v) ?: return "Couldn't find this video's file."
        val src = File(path)
        if (!src.exists()) return "The video file no longer exists."
        if (isVault(Uri.fromFile(src))) return "This video is already hidden."
        val d = dir(ctx)
        val size = src.length()
        val id = UUID.randomUUID().toString().replace("-", "").take(20)
        val ext = src.extension.lowercase().ifBlank { "mp4" }
        val dest = File(d, "$id.$ext")
        val base = src.nameWithoutExtension
        val subs = (src.parentFile?.listFiles() ?: emptyArray())
            .filter { it.isFile && it.extension.lowercase() in subExts.keys && it.name.startsWith(base) }
        val dur = if (v.durationMs > 0) v.durationMs else readDuration(path)

        try {
            moveFile(src, dest, onProgress, alive)
        } catch (e: VaultException) {
            return e.message
        }
        // Subtitle files next to the video would still reveal it, so they move too (best effort).
        subs.forEach { s ->
            runCatching { moveFile(s, File(d, id + s.name.removePrefix(base)), { }, { true }) }
        }

        synchronized(lock) {
            val idx = readIndex(ctx)
            idx.add(VaultItem(dest.name, src.name, path, dur, size, System.currentTimeMillis() / 1000))
            writeIndex(ctx, idx)
        }

        // Remove every trace from the in-app lists, resume list and likes.
        val keys = mutableSetOf(v.uri.toString())
        removed.add(v.uri)
        runCatching {
            val coll = MediaStore.Video.Media.EXTERNAL_CONTENT_URI
            ctx.contentResolver.query(
                coll, arrayOf(MediaStore.Video.Media._ID),
                "${MediaStore.MediaColumns.DATA}=?", arrayOf(path), null
            )?.use { c ->
                while (c.moveToNext()) {
                    val u = ContentUris.withAppendedId(coll, c.getLong(0))
                    keys.add(u.toString())
                    removed.add(u)
                    runCatching { ctx.contentResolver.delete(u, null, null) }
                }
            }
        }
        runCatching { ctx.contentResolver.delete(v.uri, null, null) }
        keys.forEach { removeRecent(ctx, it) }
        val rp = ctx.getSharedPreferences("reels", Context.MODE_PRIVATE)
        val liked = rp.getStringSet("liked", emptySet())!!.toMutableSet()
        if (liked.removeAll(keys)) rp.edit().putStringSet("liked", liked).apply()

        // Tell Android the original is gone so the Gallery and other apps drop it.
        runCatching {
            MediaScannerConnection.scanFile(ctx.applicationContext, arrayOf(path), null) { _, _ ->
                version.intValue++
            }
        }
        version.intValue++
        return null
    }

    // ---------- Unhide / delete ----------

    fun unhide(ctx: Context, item: VaultItem, onProgress: (Float) -> Unit, alive: () -> Boolean): String? {
        val d = dir(ctx)
        val f = File(d, item.file)
        if (!f.exists()) {
            removeFromIndex(ctx, item)
            return "The file is missing."
        }
        val fallbackDir = File(Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_MOVIES), "Restored")
        var target = if (item.origPath.isNotBlank()) File(item.origPath) else File(fallbackDir, item.name)
        val parent = target.parentFile
        if (parent == null || !(parent.exists() || parent.mkdirs()) || !parent.canWrite()) {
            fallbackDir.mkdirs()
            target = File(fallbackDir, item.name)
        }
        if (target.exists()) {
            val b = target.nameWithoutExtension
            val e = target.extension.let { if (it.isEmpty()) "" else ".$it" }
            var n = 1
            while (File(target.parentFile, "$b ($n)$e").exists()) n++
            target = File(target.parentFile, "$b ($n)$e")
        }
        try {
            moveFile(f, target, onProgress, alive)
        } catch (e: VaultException) {
            return e.message
        }
        val id = item.file.substringBeforeLast('.')
        val restored = mutableListOf(target.absolutePath)
        (d.listFiles() ?: emptyArray())
            .filter { it.name.startsWith("$id.") && it.extension.lowercase() in subExts.keys }
            .forEach { s ->
                val out = File(target.parentFile, target.nameWithoutExtension + s.name.removePrefix(id))
                runCatching { moveFile(s, out, { }, { true }); restored.add(out.absolutePath) }
            }
        removeFromIndex(ctx, item)
        runCatching {
            MediaScannerConnection.scanFile(ctx.applicationContext, restored.toTypedArray(), null) { _, _ ->
                version.intValue++
            }
        }
        version.intValue++
        return null
    }

    fun deleteForever(ctx: Context, item: VaultItem) {
        val d = dir(ctx)
        val id = item.file.substringBeforeLast('.')
        (d.listFiles() ?: emptyArray()).filter { it.name == item.file || it.name.startsWith("$id.") }.forEach { it.delete() }
        removeFromIndex(ctx, item)
        version.intValue++
    }

    private fun removeFromIndex(ctx: Context, item: VaultItem) = synchronized(lock) {
        writeIndex(ctx, readIndex(ctx).filter { it.file != item.file })
    }

    // ---------- PIN ----------

    private fun hash(salt: String, s: String): String =
        MessageDigest.getInstance("SHA-256").digest((salt + s).toByteArray())
            .joinToString("") { "%02x".format(it) }

    fun hasPin(ctx: Context): Boolean = prefs(ctx).contains("pin_hash")

    fun hasRecovery(ctx: Context): Boolean = prefs(ctx).contains("rec_hash")

    fun setPin(ctx: Context, pin: String, recovery: String?, unlock: Boolean) {
        val p = prefs(ctx)
        val salt = p.getString("salt", null) ?: UUID.randomUUID().toString()
        val e = p.edit().putString("salt", salt).putString("pin_hash", hash(salt, pin))
        if (!recovery.isNullOrBlank()) e.putString("rec_hash", hash(salt, recovery.trim().lowercase()))
        e.commit()
        if (unlock) unlocked = true
    }

    /** 0 = correct, -1 = wrong, > 0 = locked out for that many seconds. */
    fun tryPin(ctx: Context, pin: String, unlock: Boolean = true): Int {
        val now = System.currentTimeMillis()
        if (now < lockUntil) return ((lockUntil - now) / 1000 + 1).toInt()
        val p = prefs(ctx)
        val ok = hash(p.getString("salt", "") ?: "", pin) == p.getString("pin_hash", null)
        if (ok) {
            fails = 0
            if (unlock) unlocked = true
            return 0
        }
        fails++
        if (fails >= 5) {
            fails = 0
            lockUntil = now + 30_000
            return 30
        }
        return -1
    }

    fun tryRecovery(ctx: Context, word: String): Boolean {
        val p = prefs(ctx)
        val h = p.getString("rec_hash", null) ?: return false
        return hash(p.getString("salt", "") ?: "", word.trim().lowercase()) == h
    }
}

// ======================= UI =======================

@Composable
fun PinField(label: String, value: String, onChange: (String) -> Unit) {
    OutlinedTextField(
        value = value,
        onValueChange = onChange,
        singleLine = true,
        label = { Text(label) },
        visualTransformation = PasswordVisualTransformation(),
        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.NumberPassword),
        colors = fieldColors(),
        modifier = Modifier.fillMaxWidth()
    )
}

@Composable
fun fieldColors() = OutlinedTextFieldDefaults.colors(
    focusedTextColor = Fg,
    unfocusedTextColor = Fg,
    focusedBorderColor = Accent,
    unfocusedBorderColor = Fg.copy(alpha = 0.3f),
    focusedLabelColor = Accent,
    unfocusedLabelColor = Fg.copy(alpha = 0.6f),
    cursorColor = Accent
)

private val ErrRed = Color(0xFFE5484D)

@Composable
fun PinSetupDialog(unlock: Boolean, onDone: () -> Unit, onDismiss: () -> Unit) {
    val ctx = LocalContext.current
    var pin by remember { mutableStateOf("") }
    var pin2 by remember { mutableStateOf("") }
    var rec by remember { mutableStateOf("") }
    var err by remember { mutableStateOf<String?>(null) }
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Create a PIN") },
        text = {
            Column {
                Text("Choose a 4 to 8 digit PIN. It will be required to open your hidden videos.", fontSize = 13.sp)
                Spacer(Modifier.height(10.dp))
                PinField("PIN", pin) { pin = it.filter { c -> c.isDigit() }.take(8) }
                Spacer(Modifier.height(8.dp))
                PinField("Confirm PIN", pin2) { pin2 = it.filter { c -> c.isDigit() }.take(8) }
                Spacer(Modifier.height(8.dp))
                OutlinedTextField(
                    value = rec,
                    onValueChange = { rec = it },
                    singleLine = true,
                    label = { Text("Recovery word") },
                    colors = fieldColors(),
                    modifier = Modifier.fillMaxWidth()
                )
                Text(
                    "If you forget your PIN, this word is the only way to reset it. Remember it.",
                    fontSize = 11.sp,
                    modifier = Modifier.padding(top = 6.dp)
                )
                err?.let { Text(it, color = ErrRed, fontSize = 12.sp, modifier = Modifier.padding(top = 6.dp)) }
            }
        },
        confirmButton = {
            TextButton(onClick = {
                when {
                    pin.length < 4 -> err = "The PIN must be at least 4 digits."
                    pin != pin2 -> err = "The PINs don't match."
                    rec.isBlank() -> err = "Please enter a recovery word."
                    else -> {
                        VideoVault.setPin(ctx, pin, rec, unlock)
                        onDone()
                    }
                }
            }) { Text("Save", color = Accent) }
        },
        dismissButton = { TextButton(onClick = onDismiss) { Text("Cancel", color = Fg) } },
        containerColor = CardBg,
        titleContentColor = Fg,
        textContentColor = Fg.copy(alpha = 0.8f)
    )
}

@Composable
fun ForgotPinDialog(onDone: () -> Unit, onDismiss: () -> Unit) {
    val ctx = LocalContext.current
    var word by remember { mutableStateOf("") }
    var pin by remember { mutableStateOf("") }
    var err by remember { mutableStateOf<String?>(null) }
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Reset PIN") },
        text = {
            Column {
                if (!VideoVault.hasRecovery(ctx)) {
                    Text("No recovery word was set, so the PIN can't be reset.", fontSize = 13.sp)
                } else {
                    OutlinedTextField(
                        value = word, onValueChange = { word = it }, singleLine = true,
                        label = { Text("Recovery word") }, colors = fieldColors(),
                        modifier = Modifier.fillMaxWidth()
                    )
                    Spacer(Modifier.height(8.dp))
                    PinField("New PIN (4 to 8 digits)", pin) { pin = it.filter { c -> c.isDigit() }.take(8) }
                    err?.let { Text(it, color = ErrRed, fontSize = 12.sp, modifier = Modifier.padding(top = 6.dp)) }
                }
            }
        },
        confirmButton = {
            if (VideoVault.hasRecovery(ctx)) {
                TextButton(onClick = {
                    if (pin.length < 4) err = "The PIN must be at least 4 digits."
                    else if (!VideoVault.tryRecovery(ctx, word)) err = "That recovery word is incorrect."
                    else {
                        VideoVault.setPin(ctx, pin, null, true)
                        onDone()
                    }
                }) { Text("Reset", color = Accent) }
            }
        },
        dismissButton = { TextButton(onClick = onDismiss) { Text("Close", color = Fg) } },
        containerColor = CardBg,
        titleContentColor = Fg,
        textContentColor = Fg.copy(alpha = 0.8f)
    )
}

@Composable
fun ChangePinDialog(onDone: () -> Unit, onDismiss: () -> Unit) {
    val ctx = LocalContext.current
    var old by remember { mutableStateOf("") }
    var pin by remember { mutableStateOf("") }
    var err by remember { mutableStateOf<String?>(null) }
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Change PIN") },
        text = {
            Column {
                PinField("Current PIN", old) { old = it.filter { c -> c.isDigit() }.take(8) }
                Spacer(Modifier.height(8.dp))
                PinField("New PIN (4 to 8 digits)", pin) { pin = it.filter { c -> c.isDigit() }.take(8) }
                err?.let { Text(it, color = ErrRed, fontSize = 12.sp, modifier = Modifier.padding(top = 6.dp)) }
            }
        },
        confirmButton = {
            TextButton(onClick = {
                if (pin.length < 4) {
                    err = "The new PIN must be at least 4 digits."
                } else {
                    val r = VideoVault.tryPin(ctx, old)
                    if (r == 0) {
                        VideoVault.setPin(ctx, pin, null, true)
                        Toast.makeText(ctx, "PIN changed", Toast.LENGTH_SHORT).show()
                        onDone()
                    } else if (r < 0) err = "The current PIN is wrong."
                    else err = "Too many attempts. Try again in $r s."
                }
            }) { Text("Change", color = Accent) }
        },
        dismissButton = { TextButton(onClick = onDismiss) { Text("Cancel", color = Fg) } },
        containerColor = CardBg,
        titleContentColor = Fg,
        textContentColor = Fg.copy(alpha = 0.8f)
    )
}

@Composable
fun ProgressDialog(title: String, progress: Float, onCancel: () -> Unit) {
    AlertDialog(
        onDismissRequest = { },
        title = { Text(title) },
        text = {
            Column {
                LinearProgressIndicator(progress = { progress }, color = Accent, modifier = Modifier.fillMaxWidth())
                Text(
                    "${(progress * 100).toInt()}%  •  Please keep the app open",
                    fontSize = 12.sp,
                    modifier = Modifier.padding(top = 8.dp)
                )
            }
        },
        confirmButton = { },
        dismissButton = { TextButton(onClick = onCancel) { Text("Cancel", color = Fg) } },
        containerColor = CardBg,
        titleContentColor = Fg,
        textContentColor = Fg.copy(alpha = 0.8f)
    )
}

/** Confirm, (create a PIN if needed), then move the video into the vault. */
@Composable
fun HideVideoDialog(video: Video, onDismiss: () -> Unit, onDone: (Video) -> Unit) {
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    var step by remember { mutableIntStateOf(if (VideoVault.hasPin(ctx)) 1 else 0) }
    var prog by remember { mutableFloatStateOf(0f) }
    val cancelled = remember { booleanArrayOf(false) }

    fun start() {
        step = 2
        cancelled[0] = false
        scope.launch {
            val err = withContext(Dispatchers.IO) {
                VideoVault.hide(ctx, video, { prog = it }, { !cancelled[0] })
            }
            if (err == null) {
                Toast.makeText(ctx, "Video hidden", Toast.LENGTH_SHORT).show()
                onDone(video)
            } else {
                Toast.makeText(ctx, err, Toast.LENGTH_LONG).show()
                onDismiss()
            }
        }
    }

    val writeLauncher = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { ok ->
        if (ok) start() else {
            Toast.makeText(ctx, "Storage permission is required to hide videos", Toast.LENGTH_LONG).show()
            onDismiss()
        }
    }

    fun confirm() {
        if (Build.VERSION.SDK_INT >= 30 && !Environment.isExternalStorageManager()) {
            Toast.makeText(ctx, "Allow 'All files access' for KaifsPlayer, then try again", Toast.LENGTH_LONG).show()
            openAllFilesSettings(ctx)
            onDismiss()
        } else if (Build.VERSION.SDK_INT <= 29 &&
            ContextCompat.checkSelfPermission(ctx, Manifest.permission.WRITE_EXTERNAL_STORAGE) != PackageManager.PERMISSION_GRANTED
        ) {
            writeLauncher.launch(Manifest.permission.WRITE_EXTERNAL_STORAGE)
        } else {
            start()
        }
    }

    when (step) {
        0 -> PinSetupDialog(unlock = false, onDone = { step = 1 }, onDismiss = onDismiss)
        1 -> AlertDialog(
            onDismissRequest = onDismiss,
            title = { Text("Hide this video?") },
            text = {
                Text(
                    "\"${video.name}\" will be moved into KaifsPlayer's private storage. It will disappear from " +
                        "Gallery, file managers and every other app. You can open it only from Settings > Hidden videos with your PIN.\n\n" +
                        "Important: if you uninstall KaifsPlayer or clear its data, hidden videos are deleted permanently. " +
                        "Update the app over the existing install instead."
                )
            },
            confirmButton = { TextButton(onClick = { confirm() }) { Text("Hide", color = Accent) } },
            dismissButton = { TextButton(onClick = onDismiss) { Text("Cancel", color = Fg) } },
            containerColor = CardBg,
            titleContentColor = Fg,
            textContentColor = Fg.copy(alpha = 0.8f)
        )
        else -> ProgressDialog("Hiding video...", prog) { cancelled[0] = true }
    }
}

@Composable
fun VaultScreen(onBack: () -> Unit, onPlay: (List<Video>, Int) -> Unit) {
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    var hasPin by remember { mutableStateOf(VideoVault.hasPin(ctx)) }
    val unlocked = VideoVault.unlocked
    var showSetup by remember { mutableStateOf(false) }
    var showChange by remember { mutableStateOf(false) }
    var showForgot by remember { mutableStateOf(false) }
    var vids by remember { mutableStateOf<List<Video>?>(null) }
    var sel by remember { mutableStateOf<Video?>(null) }
    var confirmDelete by remember { mutableStateOf<Video?>(null) }
    var work by remember { mutableStateOf<String?>(null) }
    var prog by remember { mutableFloatStateOf(0f) }
    val cancelled = remember { booleanArrayOf(false) }

    LaunchedEffect(VideoVault.version.intValue, unlocked) {
        if (unlocked) vids = withContext(Dispatchers.IO) { VideoVault.videos(ctx) }
    }

    val list = vids
    Column(Modifier.fillMaxSize().background(Bg)) {
        BrowseHeader(
            "Hidden videos",
            if (!unlocked || list == null) "Locked" else "${list.size} videos",
            onBack
        ) {
            if (unlocked) Chip(R.drawable.ic_lock, "PIN") { showChange = true }
        }

        when {
            !hasPin -> Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                CenterMessage(
                    R.drawable.ic_lock, "Protect your hidden videos",
                    "Create a PIN first. Hidden videos are stored privately inside KaifsPlayer and can only be opened with it.",
                    "Create PIN"
                ) { showSetup = true }
            }
            !unlocked -> VaultGate(onForgot = { showForgot = true })
            list == null -> Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                Text("Loading...", color = Fg.copy(alpha = 0.6f))
            }
            list.isEmpty() -> Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                Text(
                    "No hidden videos yet.\nUse Hide video in the 3-dot menu of Reels or the Movie player, or long-press a video in Gallery or Files.",
                    color = Fg.copy(alpha = 0.6f),
                    textAlign = TextAlign.Center,
                    modifier = Modifier.padding(32.dp)
                )
            }
            else -> LazyVerticalGrid(
                columns = GridCells.Fixed(3),
                contentPadding = PaddingValues(8.dp),
                horizontalArrangement = Arrangement.spacedBy(6.dp),
                verticalArrangement = Arrangement.spacedBy(6.dp),
                modifier = Modifier.fillMaxSize()
            ) {
                itemsIndexed(list, key = { _, v -> v.id }) { idx, v ->
                    Box(
                        Modifier.fillMaxWidth().aspectRatio(0.62f)
                            .clip(RoundedCornerShape(10.dp))
                            .background(CardBg)
                            .combinedClickable(onClick = { onPlay(list, idx) }, onLongClick = { sel = v })
                    ) {
                        Thumb(v, 300, 480, Modifier.fillMaxSize())
                        Box(
                            Modifier.align(Alignment.BottomCenter).fillMaxWidth().height(70.dp).background(
                                Brush.verticalGradient(listOf(Color.Transparent, Color.Black.copy(alpha = 0.8f)))
                            )
                        )
                        Text(
                            fmt(v.durationMs),
                            color = Color.White,
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Medium,
                            modifier = Modifier.align(Alignment.TopEnd).padding(6.dp)
                                .background(Color.Black.copy(alpha = 0.6f), RoundedCornerShape(6.dp))
                                .padding(horizontal = 5.dp, vertical = 2.dp)
                        )
                        Text(
                            v.name.substringBeforeLast('.'),
                            color = Color.White,
                            fontSize = 11.sp,
                            maxLines = 2,
                            overflow = TextOverflow.Ellipsis,
                            modifier = Modifier.align(Alignment.BottomStart).padding(6.dp)
                        )
                    }
                }
            }
        }
    }

    if (showSetup) {
        PinSetupDialog(unlock = true, onDone = { showSetup = false; hasPin = true }, onDismiss = { showSetup = false })
    }
    if (showChange) ChangePinDialog(onDone = { showChange = false }, onDismiss = { showChange = false })
    if (showForgot) ForgotPinDialog(onDone = { showForgot = false }, onDismiss = { showForgot = false })

    val s = sel
    if (s != null) {
        AlertDialog(
            onDismissRequest = { sel = null },
            title = { Text(s.name, maxLines = 2, overflow = TextOverflow.Ellipsis) },
            text = { Text("${fmtSize(s.sizeBytes)}  •  ${fmt(s.durationMs)}") },
            confirmButton = {
                TextButton(onClick = {
                    sel = null
                    val item = VideoVault.itemFor(ctx, s)
                    if (item != null) {
                        work = "Restoring video..."
                        prog = 0f
                        cancelled[0] = false
                        scope.launch {
                            val err = withContext(Dispatchers.IO) {
                                VideoVault.unhide(ctx, item, { prog = it }, { !cancelled[0] })
                            }
                            work = null
                            Toast.makeText(ctx, err ?: "Video restored to its original folder", Toast.LENGTH_LONG).show()
                        }
                    }
                }) { Text("Unhide", color = Accent) }
            },
            dismissButton = {
                TextButton(onClick = { confirmDelete = s; sel = null }) { Text("Delete", color = ErrRed) }
            },
            containerColor = CardBg,
            titleContentColor = Fg,
            textContentColor = Fg.copy(alpha = 0.8f)
        )
    }
    val cd = confirmDelete
    if (cd != null) {
        AlertDialog(
            onDismissRequest = { confirmDelete = null },
            title = { Text("Delete permanently?") },
            text = { Text("\"${cd.name}\" will be deleted from your phone. This action can't be undone.") },
            confirmButton = {
                TextButton(onClick = {
                    VideoVault.itemFor(ctx, cd)?.let { VideoVault.deleteForever(ctx, it) }
                    confirmDelete = null
                    Toast.makeText(ctx, "Video deleted", Toast.LENGTH_SHORT).show()
                }) { Text("Delete", color = ErrRed) }
            },
            dismissButton = { TextButton(onClick = { confirmDelete = null }) { Text("Cancel", color = Fg) } },
            containerColor = CardBg,
            titleContentColor = Fg,
            textContentColor = Fg.copy(alpha = 0.8f)
        )
    }
    val w = work
    if (w != null) ProgressDialog(w, prog) { cancelled[0] = true }
}

@Composable
fun VaultGate(onForgot: () -> Unit) {
    val ctx = LocalContext.current
    var pin by remember { mutableStateOf("") }
    var err by remember { mutableStateOf<String?>(null) }
    Column(
        Modifier.fillMaxSize().padding(horizontal = 32.dp),
        verticalArrangement = Arrangement.Center,
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Ic(R.drawable.ic_lock, 56.dp, Accent)
        Text("Enter your PIN", color = Fg, fontSize = 20.sp, fontWeight = FontWeight.Bold, modifier = Modifier.padding(top = 12.dp, bottom = 16.dp))
        PinField("PIN", pin) { pin = it.filter { c -> c.isDigit() }.take(8) }
        err?.let { Text(it, color = ErrRed, fontSize = 12.sp, modifier = Modifier.padding(top = 8.dp)) }
        Button(
            onClick = {
                val r = VideoVault.tryPin(ctx, pin)
                if (r < 0) err = "Wrong PIN"
                else if (r > 0) err = "Too many attempts. Try again in $r s."
                pin = ""
            },
            modifier = Modifier.padding(top = 16.dp)
        ) { Text("Unlock") }
        TextButton(onClick = onForgot) { Text("Forgot PIN?", color = Fg.copy(alpha = 0.7f)) }
    }
}
