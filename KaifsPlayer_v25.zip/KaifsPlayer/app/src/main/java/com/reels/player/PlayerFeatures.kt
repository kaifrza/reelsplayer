@file:OptIn(
    androidx.media3.common.util.UnstableApi::class,
    androidx.compose.material3.ExperimentalMaterial3Api::class
)

package com.reels.player

import android.content.Context
import android.graphics.ColorMatrix
import android.graphics.ColorMatrixColorFilter
import android.graphics.Paint
import android.media.audiofx.BassBoost
import android.media.audiofx.Equalizer
import android.os.ParcelFileDescriptor
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.awaitEachGesture
import androidx.compose.foundation.gestures.awaitFirstDown
import androidx.compose.foundation.gestures.calculateCentroid
import androidx.compose.foundation.gestures.calculatePan
import androidx.compose.foundation.gestures.calculateZoom
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ColumnScope
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Slider
import androidx.compose.material3.SliderDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Shadow
import androidx.compose.ui.graphics.toArgb
import androidx.compose.ui.input.pointer.PointerInputScope
import androidx.compose.ui.input.pointer.positionChanged
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.media3.ui.CaptionStyleCompat
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.io.FileInputStream
import java.io.RandomAccessFile
import java.nio.ByteBuffer
import java.nio.channels.FileChannel

// =====================================================================
// Shared dialog pieces (dark card, same look as the other player dialogs)
// =====================================================================

@Composable
fun DialogFrame(
    title: String,
    onDismiss: () -> Unit,
    maxW: Dp = 380.dp,
    maxH: Dp = 420.dp,
    content: @Composable ColumnScope.() -> Unit
) {
    Box(
        Modifier.fillMaxSize().background(Color.Black.copy(alpha = 0.55f)).clickable(onClick = onDismiss),
        contentAlignment = Alignment.Center
    ) {
        Column(
            Modifier.widthIn(max = maxW).fillMaxWidth(0.9f).heightIn(max = maxH)
                .clip(RoundedCornerShape(20.dp)).background(Color(0xFF1C1C22))
                .clickable(onClick = { })
                .verticalScroll(rememberScrollState())
                .padding(16.dp)
        ) {
            Text(title, color = Color.White, fontSize = 16.sp, fontWeight = FontWeight.SemiBold)
            Spacer(Modifier.height(8.dp))
            content()
        }
    }
}

@Composable
fun LabeledSlider(
    label: String,
    valueText: String,
    value: Float,
    range: ClosedFloatingPointRange<Float>,
    onChange: (Float) -> Unit
) {
    Column(Modifier.fillMaxWidth().padding(top = 6.dp)) {
        Row(Modifier.fillMaxWidth()) {
            Text(label, color = Color.White.copy(alpha = 0.85f), fontSize = 13.sp, modifier = Modifier.weight(1f))
            Text(valueText, color = Accent, fontSize = 13.sp, fontWeight = FontWeight.Medium)
        }
        Slider(
            value = value.coerceIn(range.start, range.endInclusive),
            onValueChange = onChange,
            valueRange = range,
            colors = SliderDefaults.colors(
                thumbColor = Accent,
                activeTrackColor = Accent,
                inactiveTrackColor = Color.White.copy(alpha = 0.2f)
            )
        )
    }
}

@Composable
fun OptionChips(options: List<String>, selected: Int, onPick: (Int) -> Unit) {
    Row(
        Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()).padding(vertical = 4.dp),
        horizontalArrangement = Arrangement.spacedBy(8.dp)
    ) {
        options.forEachIndexed { i, o ->
            Box(
                Modifier.clip(RoundedCornerShape(18.dp))
                    .background(if (i == selected) Accent else Color.White.copy(alpha = 0.1f))
                    .clickable { onPick(i) }
                    .padding(horizontal = 14.dp, vertical = 8.dp)
            ) {
                Text(o, color = Color.White, fontSize = 13.sp)
            }
        }
    }
}

@Composable
fun SectionLabel(text: String) {
    Text(
        text, color = Color.White.copy(alpha = 0.55f), fontSize = 12.sp,
        modifier = Modifier.padding(top = 12.dp, bottom = 2.dp)
    )
}

@Composable
fun PillButton(text: String, onClick: () -> Unit, modifier: Modifier = Modifier, primary: Boolean = false) {
    Box(
        modifier.clip(RoundedCornerShape(12.dp))
            .background(if (primary) Accent else Color.White.copy(alpha = 0.1f))
            .clickable(onClick = onClick)
            .padding(horizontal = 16.dp, vertical = 11.dp),
        contentAlignment = Alignment.Center
    ) {
        Text(text, color = Color.White, fontSize = 14.sp, fontWeight = FontWeight.Medium)
    }
}

// =====================================================================
// 1. Pinch to zoom + two finger pan
// =====================================================================

/**
 * Only reacts when two or more fingers are down, and only then consumes the movement, so the single-finger
 * gestures (tap, seek, brightness, volume, hold-speed) keep working. Put it LAST in the pointerInput chain.
 */
suspend fun PointerInputScope.pinchPanDetector(
    onTransform: (zoom: Float, pan: Offset, centroid: Offset) -> Unit,
    onEnd: () -> Unit
) {
    awaitEachGesture {
        awaitFirstDown(requireUnconsumed = false)
        var active = false
        do {
            val event = awaitPointerEvent()
            val pressed = event.changes.count { it.pressed }
            if (pressed >= 2) {
                val z = event.calculateZoom()
                val p = event.calculatePan()
                val c = event.calculateCentroid(useCurrent = true)
                if (z != 1f || p != Offset.Zero) {
                    onTransform(z, p, c)
                    event.changes.forEach { if (it.positionChanged()) it.consume() }
                }
                active = true
            }
        } while (event.changes.any { it.pressed })
        if (active) onEnd()
    }
}

// =====================================================================
// 4. Equalizer + bass boost
// =====================================================================

val eqPresetNames = listOf("Off", "Bass", "Vocal", "Movie", "Treble", "Custom")

fun presetGainDb(preset: Int, hz: Int): Float = when (preset) {
    1 -> when {
        hz <= 120 -> 6f
        hz <= 300 -> 4f
        hz <= 700 -> 1.5f
        else -> 0f
    }
    2 -> when {
        hz <= 100 -> -2f
        hz <= 400 -> 0f
        hz <= 900 -> 2.5f
        hz <= 4500 -> 5f
        hz <= 9000 -> 2f
        else -> 0f
    }
    3 -> when {
        hz <= 120 -> 5f
        hz <= 400 -> 2f
        hz <= 3000 -> -1f
        hz <= 8000 -> 3f
        else -> 4f
    }
    4 -> when {
        hz <= 500 -> -1f
        hz <= 2000 -> 0f
        hz <= 5000 -> 3f
        else -> 5f
    }
    else -> 0f
}

class EqEngine {
    private var eq: Equalizer? = null
    private var bass: BassBoost? = null
    private var session = 0
    var bandCount = 0
    var minLevel = -1500
    var maxLevel = 1500
    var centerHz: IntArray = IntArray(0)
    var bassSupported = false

    fun attach(sessionId: Int) {
        if (sessionId == 0) return
        if (sessionId == session && eq != null) return
        release()
        session = sessionId
        runCatching {
            val e = Equalizer(0, sessionId)
            eq = e
            bandCount = e.numberOfBands.toInt()
            val r = e.bandLevelRange
            minLevel = r[0].toInt()
            maxLevel = r[1].toInt()
            centerHz = IntArray(bandCount) { i -> e.getCenterFreq(i.toShort()) / 1000 }
        }
        runCatching {
            val b = BassBoost(0, sessionId)
            bass = b
            bassSupported = b.strengthSupported
        }
    }

    fun apply(eqOn: Boolean, gainsMb: IntArray, bassPct: Int) {
        runCatching {
            val e = eq
            if (e != null) {
                for (i in 0 until bandCount) {
                    val g = (gainsMb.getOrElse(i) { 0 }).coerceIn(minLevel, maxLevel)
                    e.setBandLevel(i.toShort(), g.toShort())
                }
                e.enabled = eqOn
            }
        }
        runCatching {
            val b = bass
            if (b != null && bassSupported) {
                b.setStrength((bassPct.coerceIn(0, 100) * 10).toShort())
                b.enabled = bassPct > 0
            }
        }
    }

    fun release() {
        runCatching { eq?.release() }
        runCatching { bass?.release() }
        eq = null
        bass = null
        session = 0
    }
}

fun loadEqBands(s: String?): List<Int> {
    if (s.isNullOrBlank()) return emptyList()
    return s.split(',').mapNotNull { it.trim().toIntOrNull() }
}

@Composable
fun EqualizerDialog(
    engine: EqEngine,
    preset: Int,
    bassPct: Int,
    bandsMb: List<Int>,
    onPreset: (Int) -> Unit,
    onBass: (Int) -> Unit,
    onBand: (Int, Int) -> Unit,
    onDismiss: () -> Unit
) {
    DialogFrame("Equalizer", onDismiss, maxH = 460.dp) {
        OptionChips(eqPresetNames, preset, onPreset)
        SectionLabel("Bass boost")
        if (!engine.bassSupported) {
            Text("Bass boost is not available on this device.", color = Color.White.copy(alpha = 0.5f), fontSize = 12.sp)
        }
        LabeledSlider("Strength", "$bassPct%", bassPct.toFloat(), 0f..100f) { onBass(it.toInt()) }
        if (engine.bandCount > 0) {
            SectionLabel("Bands (moving a slider switches to Custom)")
            for (i in 0 until engine.bandCount) {
                val hz = engine.centerHz.getOrElse(i) { 0 }
                val label = if (hz >= 1000) "%.1f kHz".format(hz / 1000f) else "$hz Hz"
                val cur = bandsMb.getOrElse(i) { 0 }
                LabeledSlider(
                    label, "%+.1f dB".format(cur / 100f), cur.toFloat(),
                    engine.minLevel.toFloat()..engine.maxLevel.toFloat()
                ) { onBand(i, it.toInt()) }
            }
        } else {
            Text("Equalizer is not available on this device.", color = Color.White.copy(alpha = 0.5f), fontSize = 12.sp)
        }
    }
}

// =====================================================================
// 9. Live video filters (brightness / contrast / saturation)
// =====================================================================

fun buildFilterPaint(brightness: Float, contrast: Float, saturation: Float): Paint {
    val t = (1f - contrast) * 127.5f + brightness * 255f
    val cm = ColorMatrix(
        floatArrayOf(
            contrast, 0f, 0f, 0f, t,
            0f, contrast, 0f, 0f, t,
            0f, 0f, contrast, 0f, t,
            0f, 0f, 0f, 1f, 0f
        )
    )
    val sat = ColorMatrix()
    sat.setSaturation(saturation)
    cm.postConcat(sat)
    val p = Paint()
    p.colorFilter = ColorMatrixColorFilter(cm)
    return p
}

@Composable
fun FilterDialog(
    brightness: Float,
    contrast: Float,
    saturation: Float,
    onBrightness: (Float) -> Unit,
    onContrast: (Float) -> Unit,
    onSaturation: (Float) -> Unit,
    onReset: () -> Unit,
    onDismiss: () -> Unit
) {
    DialogFrame("Video filters", onDismiss) {
        LabeledSlider("Brightness", "%+d".format((brightness * 100).toInt()), brightness, -0.5f..0.5f, onBrightness)
        LabeledSlider("Contrast", "${(contrast * 100).toInt()}%", contrast, 0.5f..1.5f, onContrast)
        LabeledSlider("Saturation", "${(saturation * 100).toInt()}%", saturation, 0f..2f, onSaturation)
        Spacer(Modifier.height(10.dp))
        PillButton("Reset", onReset, Modifier.fillMaxWidth())
    }
}

// =====================================================================
// 10. Subtitle styling
// =====================================================================

val subColorNames = listOf("White", "Yellow", "Cyan", "Green", "Pink")
val subColors = listOf(
    Color.White, Color(0xFFFFEB3B), Color(0xFF4DD0E1), Color(0xFF69F0AE), Color(0xFFFF80AB)
)
val subBgNames = listOf("None", "Shadow box", "Solid")

fun subBgColor(i: Int): Color = when (i) {
    1 -> Color.Black.copy(alpha = 0.6f)
    2 -> Color.Black
    else -> Color.Transparent
}

fun captionStyleFor(colorIdx: Int, bgIdx: Int): CaptionStyleCompat {
    val fg = subColors[colorIdx.coerceIn(0, subColors.size - 1)].toArgbCompat()
    val bg = subBgColor(bgIdx).toArgbCompat()
    val edge = if (bgIdx == 2) CaptionStyleCompat.EDGE_TYPE_NONE else CaptionStyleCompat.EDGE_TYPE_OUTLINE
    return CaptionStyleCompat(
        fg, bg, android.graphics.Color.TRANSPARENT, edge, android.graphics.Color.BLACK, null
    )
}

fun Color.toArgbCompat(): Int = this.toArgb()

val subTextShadow = TextStyle(shadow = Shadow(color = Color.Black, offset = Offset(1.5f, 1.5f), blurRadius = 4f))

@Composable
fun SubtitleStyleDialog(
    scale: Float,
    colorIdx: Int,
    bgIdx: Int,
    pos: Float,
    onScale: (Float) -> Unit,
    onColor: (Int) -> Unit,
    onBg: (Int) -> Unit,
    onPos: (Float) -> Unit,
    onReset: () -> Unit,
    onDismiss: () -> Unit
) {
    DialogFrame("Subtitle style", onDismiss, maxH = 460.dp) {
        Box(
            Modifier.fillMaxWidth().clip(RoundedCornerShape(10.dp)).background(Color(0xFF3A3A44)).padding(14.dp),
            contentAlignment = Alignment.Center
        ) {
            Box(Modifier.background(subBgColor(bgIdx), RoundedCornerShape(6.dp)).padding(horizontal = 8.dp, vertical = 3.dp)) {
                Text(
                    "Sample subtitle text",
                    color = subColors[colorIdx.coerceIn(0, subColors.size - 1)],
                    fontSize = (16f * scale).sp,
                    textAlign = TextAlign.Center,
                    style = if (bgIdx == 2) TextStyle.Default else subTextShadow
                )
            }
        }
        LabeledSlider("Size", "${(scale * 100).toInt()}%", scale, 0.5f..2.5f, onScale)
        LabeledSlider("Position (height from bottom)", "${(pos * 100).toInt()}%", pos, 0f..0.4f, onPos)
        SectionLabel("Text color")
        OptionChips(subColorNames, colorIdx, onColor)
        SectionLabel("Background")
        OptionChips(subBgNames, bgIdx, onBg)
        Spacer(Modifier.height(10.dp))
        PillButton("Reset", onReset, Modifier.fillMaxWidth())
    }
}

// =====================================================================
// 5. Bookmarks
// =====================================================================

class Bookmark(val posMs: Long, val label: String)

private fun bmPrefs(ctx: Context) = ctx.getSharedPreferences("bookmarks", Context.MODE_PRIVATE)

fun loadBookmarks(ctx: Context, key: String): List<Bookmark> {
    val s = bmPrefs(ctx).getString("bm_$key", null) ?: return emptyList()
    return runCatching {
        val a = JSONArray(s)
        (0 until a.length()).map { i ->
            val o = a.getJSONObject(i)
            Bookmark(o.getLong("p"), o.optString("l"))
        }.sortedBy { it.posMs }
    }.getOrDefault(emptyList())
}

fun saveBookmarks(ctx: Context, key: String, list: List<Bookmark>) {
    val a = JSONArray()
    list.forEach { a.put(JSONObject().put("p", it.posMs).put("l", it.label)) }
    val e = bmPrefs(ctx).edit()
    if (list.isEmpty()) e.remove("bm_$key") else e.putString("bm_$key", a.toString())
    e.apply()
}

@Composable
fun BookmarksDialog(
    list: List<Bookmark>,
    curMs: Long,
    onAdd: () -> Unit,
    onJump: (Bookmark) -> Unit,
    onDelete: (Bookmark) -> Unit,
    onDismiss: () -> Unit
) {
    DialogFrame("Bookmarks", onDismiss) {
        PillButton("+ Add bookmark at ${fmt(curMs)}", onAdd, Modifier.fillMaxWidth(), primary = true)
        Spacer(Modifier.height(6.dp))
        if (list.isEmpty()) {
            Text(
                "No bookmarks for this video yet.",
                color = Color.White.copy(alpha = 0.55f), fontSize = 13.sp,
                modifier = Modifier.padding(vertical = 10.dp)
            )
        }
        list.forEach { b ->
            Row(
                Modifier.fillMaxWidth().clickable { onJump(b) }.padding(vertical = 6.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Ic(R.drawable.ic_bookmark, 20.dp, Color(0xFFFFC107))
                Spacer(Modifier.size(12.dp))
                Column(Modifier.weight(1f)) {
                    Text(fmt(b.posMs), color = Color.White, fontSize = 15.sp, fontWeight = FontWeight.Medium)
                    if (b.label.isNotBlank()) {
                        Text(b.label, color = Color.White.copy(alpha = 0.55f), fontSize = 12.sp)
                    }
                }
                Box(
                    Modifier.size(36.dp).clip(CircleShape).clickable { onDelete(b) },
                    contentAlignment = Alignment.Center
                ) { Ic(R.drawable.ic_delete, 18.dp, Color.White.copy(alpha = 0.7f)) }
            }
        }
    }
}

/** Little ticks over the seek bar: white = chapter, yellow dot = bookmark. */
@Composable
fun SeekMarkers(durMs: Long, bookmarks: List<Long>, chapterStarts: List<Long>, modifier: Modifier) {
    if (durMs <= 0L) return
    Canvas(modifier) {
        val pad = 10.dp.toPx()
        val w = size.width - 2 * pad
        val cy = size.height / 2f
        chapterStarts.forEach { c ->
            if (c > 0L) {
                val x = pad + w * (c.toFloat() / durMs).coerceIn(0f, 1f)
                drawLine(
                    Color.White.copy(alpha = 0.85f),
                    Offset(x, cy - 5.dp.toPx()), Offset(x, cy + 5.dp.toPx()),
                    strokeWidth = 2.dp.toPx()
                )
            }
        }
        bookmarks.forEach { b ->
            val x = pad + w * (b.toFloat() / durMs).coerceIn(0f, 1f)
            drawCircle(Color(0xFFFFC107), radius = 3.5.dp.toPx(), center = Offset(x, cy - 12.dp.toPx()))
        }
    }
}

// =====================================================================
// 13. Chapters (Matroska + MP4 "chpl")
// =====================================================================

class Chapter(val startMs: Long, val title: String)

private class Src(val ch: FileChannel) {
    val size: Long = ch.size()
    fun read(pos: Long, len: Int): ByteArray? {
        if (pos < 0 || len < 0 || pos + len > size) return null
        val bb = ByteBuffer.allocate(len)
        ch.position(pos)
        while (bb.hasRemaining()) {
            if (ch.read(bb) < 0) break
        }
        return if (bb.hasRemaining()) null else bb.array()
    }
}

private class Hdr(val id: Long, val dataPos: Long, val size: Long)

private fun vintLen(first: Byte): Int {
    val v = first.toInt() and 0xFF
    return if (v == 0) 0 else Integer.numberOfLeadingZeros(v) - 24 + 1
}

private fun readEbmlHeader(src: Src, pos: Long): Hdr? {
    val avail = (src.size - pos).coerceAtMost(16L).toInt()
    if (avail < 2) return null
    val b = src.read(pos, avail) ?: return null
    val il = vintLen(b[0])
    if (il == 0 || il > 4 || il >= avail) return null
    var id = 0L
    for (i in 0 until il) id = (id shl 8) or (b[i].toLong() and 0xFF)
    val sl = vintLen(b[il])
    if (sl == 0 || il + sl > avail) return null
    var sz = (b[il].toLong() and 0xFF) and ((1L shl (8 - sl)) - 1)
    var allOnes = sz == ((1L shl (8 - sl)) - 1)
    for (i in 1 until sl) {
        val x = b[il + i].toLong() and 0xFF
        if (x != 0xFFL) allOnes = false
        sz = (sz shl 8) or x
    }
    return Hdr(id, pos + il + sl, if (allOnes) -1L else sz)
}

private fun parseMkvChapterBody(b: ByteArray, from: Int, to: Int, out: MutableList<Chapter>) {
    var p = from
    while (p < to) {
        val il = vintLen(b[p])
        if (il == 0 || il > 4 || p + il >= to) return
        var id = 0L
        for (i in 0 until il) id = (id shl 8) or (b[p + i].toLong() and 0xFF)
        p += il
        val sl = vintLen(b[p])
        if (sl == 0 || p + sl > to) return
        var sz = (b[p].toLong() and 0xFF) and ((1L shl (8 - sl)) - 1)
        for (i in 1 until sl) sz = (sz shl 8) or (b[p + i].toLong() and 0xFF)
        p += sl
        val end = (p.toLong() + sz).coerceAtMost(to.toLong()).toInt()
        if (end < p) return
        when (id) {
            0x45B9L -> parseMkvChapterBody(b, p, end, out)
            0xB6L -> parseMkvAtom(b, p, end, out)
        }
        p = end
    }
}

private fun parseMkvAtom(b: ByteArray, from: Int, to: Int, out: MutableList<Chapter>) {
    var p = from
    var startNs = -1L
    var title = ""
    while (p < to) {
        val il = vintLen(b[p])
        if (il == 0 || il > 4 || p + il >= to) break
        var id = 0L
        for (i in 0 until il) id = (id shl 8) or (b[p + i].toLong() and 0xFF)
        p += il
        val sl = vintLen(b[p])
        if (sl == 0 || p + sl > to) break
        var sz = (b[p].toLong() and 0xFF) and ((1L shl (8 - sl)) - 1)
        for (i in 1 until sl) sz = (sz shl 8) or (b[p + i].toLong() and 0xFF)
        p += sl
        val end = (p.toLong() + sz).coerceAtMost(to.toLong()).toInt()
        if (end < p) break
        when (id) {
            0x91L -> {
                var v = 0L
                for (i in p until end) v = (v shl 8) or (b[i].toLong() and 0xFF)
                startNs = v
            }
            0x80L -> {
                // ChapterDisplay: look for ChapString (0x85)
                var q = p
                while (q < end) {
                    val il2 = vintLen(b[q])
                    if (il2 == 0 || il2 > 4 || q + il2 >= end) break
                    var id2 = 0L
                    for (i in 0 until il2) id2 = (id2 shl 8) or (b[q + i].toLong() and 0xFF)
                    q += il2
                    val sl2 = vintLen(b[q])
                    if (sl2 == 0 || q + sl2 > end) break
                    var sz2 = (b[q].toLong() and 0xFF) and ((1L shl (8 - sl2)) - 1)
                    for (i in 1 until sl2) sz2 = (sz2 shl 8) or (b[q + i].toLong() and 0xFF)
                    q += sl2
                    val e2 = (q.toLong() + sz2).coerceAtMost(end.toLong()).toInt()
                    if (e2 < q) break
                    if (id2 == 0x85L && title.isEmpty()) {
                        title = String(b, q, e2 - q, Charsets.UTF_8).trim { it <= ' ' || it == '\u0000' }
                    }
                    q = e2
                }
            }
            0xB6L -> parseMkvAtom(b, p, end, out)
        }
        p = end
    }
    if (startNs >= 0L) out.add(Chapter(startNs / 1_000_000L, title))
}

private fun readMkvChapters(src: Src): List<Chapter> {
    val h0 = readEbmlHeader(src, 0L) ?: return emptyList()
    if (h0.id != 0x1A45DFA3L || h0.size < 0) return emptyList()
    val seg = readEbmlHeader(src, h0.dataPos + h0.size) ?: return emptyList()
    if (seg.id != 0x18538067L) return emptyList()
    val segEnd = if (seg.size < 0) src.size else (seg.dataPos + seg.size).coerceAtMost(src.size)
    var p = seg.dataPos
    var n = 0
    while (p < segEnd && n < 6000) {
        n++
        val h = readEbmlHeader(src, p) ?: break
        if (h.size < 0) break
        if (h.id == 0x1043A770L) {
            if (h.size > 2_000_000L) break
            val body = src.read(h.dataPos, h.size.toInt()) ?: break
            val out = ArrayList<Chapter>()
            parseMkvChapterBody(body, 0, body.size, out)
            return out
        }
        p = h.dataPos + h.size
    }
    return emptyList()
}

private fun readMp4Chapters(src: Src): List<Chapter> {
    // top level -> moov -> udta -> chpl
    fun boxAt(pos: Long, limit: Long): Triple<String, Long, Long>? {
        if (pos + 8 > limit) return null
        val b = src.read(pos, 8) ?: return null
        var size = ((b[0].toLong() and 0xFF) shl 24) or ((b[1].toLong() and 0xFF) shl 16) or
            ((b[2].toLong() and 0xFF) shl 8) or (b[3].toLong() and 0xFF)
        val type = String(b, 4, 4, Charsets.ISO_8859_1)
        var header = 8L
        if (size == 1L) {
            val e = src.read(pos + 8, 8) ?: return null
            size = 0L
            for (i in 0 until 8) size = (size shl 8) or (e[i].toLong() and 0xFF)
            header = 16L
        } else if (size == 0L) {
            size = limit - pos
        }
        if (size < header || pos + size > limit) return null
        return Triple(type, pos + header, pos + size)
    }

    fun find(start: Long, end: Long, type: String): Pair<Long, Long>? {
        var p = start
        var n = 0
        while (p < end && n < 4000) {
            n++
            val bx = boxAt(p, end) ?: return null
            if (bx.first == type) return Pair(bx.second, bx.third)
            p = bx.third
        }
        return null
    }

    val moov = find(0L, src.size, "moov") ?: return emptyList()
    val udta = find(moov.first, moov.second, "udta") ?: return emptyList()
    val chpl = find(udta.first, udta.second, "chpl") ?: return emptyList()
    val len = (chpl.second - chpl.first).toInt()
    if (len < 6 || len > 1_000_000) return emptyList()
    val b = src.read(chpl.first, len) ?: return emptyList()
    var p = 0
    val version = b[p].toInt() and 0xFF
    p += 4
    if (version == 1) p += 4
    if (p >= len) return emptyList()
    val count = b[p].toInt() and 0xFF
    p++
    val out = ArrayList<Chapter>()
    for (i in 0 until count) {
        if (p + 9 > len) break
        var t = 0L
        for (k in 0 until 8) t = (t shl 8) or (b[p + k].toLong() and 0xFF)
        p += 8
        val tl = b[p].toInt() and 0xFF
        p++
        if (p + tl > len) break
        val title = String(b, p, tl, Charsets.UTF_8)
        p += tl
        out.add(Chapter(t / 10_000L, title))
    }
    return out
}

/** Reads chapter marks from the file itself. Returns an empty list when there are none (or the format is unsupported). */
fun readChapters(ctx: Context, v: Video): List<Chapter> {
    val scheme = v.uri.scheme ?: return emptyList()
    if (scheme == "http" || scheme == "https") return emptyList()
    var raf: RandomAccessFile? = null
    var pfd: ParcelFileDescriptor? = null
    return try {
        val ch: FileChannel = if (scheme == "file") {
            val r = RandomAccessFile(File(v.uri.path ?: return emptyList()), "r")
            raf = r
            r.channel
        } else {
            val p = ctx.contentResolver.openFileDescriptor(v.uri, "r") ?: return emptyList()
            pfd = p
            FileInputStream(p.fileDescriptor).channel
        }
        val src = Src(ch)
        val head = src.read(0L, 4)
        val list = if (head != null && (head[0].toInt() and 0xFF) == 0x1A && (head[1].toInt() and 0xFF) == 0x45) {
            readMkvChapters(src)
        } else {
            readMp4Chapters(src)
        }
        list.sortedBy { it.startMs }.distinctBy { it.startMs }
    } catch (e: Exception) {
        emptyList()
    } finally {
        runCatching { raf?.close() }
        runCatching { pfd?.close() }
    }
}

@Composable
fun ChaptersDialog(
    chapters: List<Chapter>,
    curMs: Long,
    onJump: (Chapter) -> Unit,
    onDismiss: () -> Unit
) {
    DialogFrame("Chapters", onDismiss) {
        if (chapters.isEmpty()) {
            Text(
                "This video has no chapter marks.\nChapters are read from MKV and MP4 files that contain them.",
                color = Color.White.copy(alpha = 0.6f), fontSize = 13.sp,
                modifier = Modifier.padding(vertical = 8.dp)
            )
        }
        val currentIdx = chapters.indexOfLast { it.startMs <= curMs }
        chapters.forEachIndexed { i, c ->
            Row(
                Modifier.fillMaxWidth().clickable { onJump(c) }.padding(vertical = 9.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    fmt(c.startMs), color = if (i == currentIdx) Accent else Color.White.copy(alpha = 0.6f),
                    fontSize = 13.sp, modifier = Modifier.size(width = 62.dp, height = 20.dp)
                )
                Text(
                    if (c.title.isBlank()) "Chapter ${i + 1}" else c.title,
                    color = if (i == currentIdx) Accent else Color.White,
                    fontSize = 14.sp, modifier = Modifier.weight(1f)
                )
            }
        }
    }
}

// =====================================================================
// 2 + 3. Player settings (double tap seek time, play mode)
// =====================================================================

val dtSeekOptions = listOf(5, 10, 15, 30)
val playModeNames = listOf("Play next", "Repeat all", "Shuffle", "Repeat one", "Stop after video")

@Composable
fun PlayerSettingsDialog(
    dtSeekSec: Int,
    playMode: Int,
    onDtSeek: (Int) -> Unit,
    onPlayMode: (Int) -> Unit,
    onDismiss: () -> Unit
) {
    DialogFrame("Player settings", onDismiss) {
        SectionLabel("Double-tap seek time")
        OptionChips(dtSeekOptions.map { "$it s" }, dtSeekOptions.indexOf(dtSeekSec).coerceAtLeast(0)) {
            onDtSeek(dtSeekOptions[it])
        }
        SectionLabel("When a video ends")
        OptionChips(playModeNames, playMode, onPlayMode)
        Text(
            "Play next: continue with the next video in the folder.\n" +
                "Repeat all: loop the whole list.\nShuffle: random order.",
            color = Color.White.copy(alpha = 0.45f), fontSize = 11.sp,
            modifier = Modifier.padding(top = 8.dp)
        )
    }
}
