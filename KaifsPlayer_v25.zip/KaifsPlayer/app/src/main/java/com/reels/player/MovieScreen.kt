@file:OptIn(
    androidx.media3.common.util.UnstableApi::class,
    androidx.compose.foundation.ExperimentalFoundationApi::class,
    androidx.compose.material3.ExperimentalMaterial3Api::class
)

package com.reels.player

import android.Manifest
import android.app.Activity
import android.app.PictureInPictureParams
import android.content.Context
import android.content.ContextWrapper
import android.content.Intent
import android.content.pm.ActivityInfo
import android.content.pm.PackageManager
import android.media.AudioManager
import android.net.Uri
import android.os.Build
import android.provider.MediaStore
import android.provider.OpenableColumns
import android.util.Rational
import android.view.WindowManager
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.foundation.Image
import androidx.compose.foundation.layout.offset
import androidx.compose.ui.layout.onGloballyPositioned
import androidx.compose.ui.layout.positionInRoot
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.unit.IntOffset
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.ui.graphics.asImageBitmap
import android.graphics.Bitmap
import android.media.audiofx.LoudnessEnhancer
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.awaitEachGesture
import androidx.compose.foundation.gestures.awaitFirstDown
import androidx.compose.foundation.gestures.detectDragGestures
import androidx.compose.foundation.gestures.waitForUpOrCancellation
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Slider
import androidx.compose.material3.SliderDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.Immutable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableLongStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.draw.clipToBounds
import androidx.compose.ui.layout.onSizeChanged
import androidx.compose.material3.CircularProgressIndicator
import androidx.media3.common.PlaybackException
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.input.pointer.PointerInputScope
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.displayCutout
import androidx.compose.foundation.layout.systemBars
import androidx.compose.foundation.layout.union
import androidx.compose.foundation.layout.windowInsetsPadding
import androidx.compose.ui.platform.LocalConfiguration
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalLifecycleOwner
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.core.content.ContextCompat
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.LifecycleEventObserver
import androidx.media3.common.AudioAttributes
import androidx.media3.common.C
import androidx.media3.common.Format
import androidx.media3.common.MediaItem
import androidx.media3.common.MimeTypes
import androidx.media3.common.Player
import androidx.media3.common.TrackSelectionOverride
import androidx.media3.common.Tracks
import androidx.media3.common.VideoSize
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.ui.AspectRatioFrameLayout
import androidx.media3.ui.CaptionStyleCompat
import androidx.media3.ui.PlayerView
import java.io.File
import java.util.Locale
import kotlin.math.abs
import kotlin.math.roundToInt
import androidx.compose.runtime.rememberUpdatedState
import androidx.compose.ui.draw.rotate
import kotlinx.coroutines.coroutineScope
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlinx.coroutines.withTimeoutOrNull
import org.json.JSONArray
import org.json.JSONObject

// ---------- Helpers ----------

@Immutable
data class PanelItem(val label: String, val selected: Boolean, val onClick: () -> Unit)

@Immutable
data class Recent(
    val uri: String,
    val name: String,
    val folder: String,
    val pos: Long,
    val dur: Long,
    val ts: Long
)

val speedOptions = listOf(0.5f, 0.75f, 1f, 1.25f, 1.5f, 2f, 3f)
val resizeModes = listOf(
    AspectRatioFrameLayout.RESIZE_MODE_FIT,
    AspectRatioFrameLayout.RESIZE_MODE_ZOOM,
    AspectRatioFrameLayout.RESIZE_MODE_FILL
)
val resizeNames = listOf("Fit", "Crop", "Stretch")
val subSizeNames = listOf("Small", "Medium", "Large")
val subSizeScale = listOf(0.7f, 1f, 1.4f)
val subExts = mapOf(
    "srt" to MimeTypes.APPLICATION_SUBRIP,
    "vtt" to MimeTypes.TEXT_VTT,
    "ass" to MimeTypes.TEXT_SSA,
    "ssa" to MimeTypes.TEXT_SSA,
    "ttml" to MimeTypes.APPLICATION_TTML
)

fun Context.findActivity(): Activity? {
    var c: Context = this
    while (c is ContextWrapper) {
        if (c is Activity) return c
        c = c.baseContext
    }
    return null
}

fun enterPip(activity: Activity, w: Int, h: Int) {
    if (Build.VERSION.SDK_INT >= 26) {
        val r = if (w > 0 && h > 0) (w.toFloat() / h).coerceIn(0.5f, 2.3f) else 16f / 9f
        runCatching {
            activity.enterPictureInPictureMode(
                PictureInPictureParams.Builder()
                    .setAspectRatio(Rational((r * 1000).toInt(), 1000))
                    .build()
            )
        }
    }
}

fun naturalCompare(a: String, b: String): Int {
    var i = 0
    var j = 0
    while (i < a.length && j < b.length) {
        if (a[i].isDigit() && b[j].isDigit()) {
            var ie = i
            while (ie < a.length && a[ie].isDigit()) ie++
            var je = j
            while (je < b.length && b[je].isDigit()) je++
            val na = a.substring(i, ie).trimStart('0')
            val nb = b.substring(j, je).trimStart('0')
            if (na.length != nb.length) return na.length - nb.length
            val c = na.compareTo(nb)
            if (c != 0) return c
            i = ie
            j = je
        } else {
            val c = a[i].lowercaseChar().compareTo(b[j].lowercaseChar())
            if (c != 0) return c
            i++
            j++
        }
    }
    return (a.length - i) - (b.length - j)
}

fun siblingsOf(v: Video, all: List<Video>): List<Video> {
    val sib: List<Video> = if (v.uri.scheme == "file") {
        val f = File(v.uri.path ?: "")
        val files = f.parentFile?.listFiles() ?: emptyArray<File>()
        files.filter { it.isFile && isVideoFile(it) }
            .sortedWith(Comparator { a, b -> naturalCompare(a.name, b.name) })
            .map { fileVideo(it) }
    } else {
        all.filter { it.folder == v.folder }
            .sortedWith(Comparator { a, b -> naturalCompare(a.name, b.name) })
    }
    return if (sib.any { it.uri == v.uri }) sib else listOf(v)
}

fun videoPath(ctx: Context, v: Video): String? {
    if (v.uri.scheme == "file") return v.uri.path
    return runCatching {
        ctx.contentResolver.query(v.uri, arrayOf(MediaStore.MediaColumns.DATA), null, null, null)
            ?.use { c -> if (c.moveToFirst()) c.getString(0) else null }
    }.getOrNull()
}

fun findSubtitleConfigs(ctx: Context, v: Video): List<MediaItem.SubtitleConfiguration> {
    val p = videoPath(ctx, v) ?: return emptyList()
    val f = File(p)
    val dir = f.parentFile ?: return emptyList()
    val base = f.nameWithoutExtension
    val files = dir.listFiles() ?: return emptyList()
    val found = files
        .filter { it.isFile && it.extension.lowercase() in subExts.keys && it.name.startsWith(base) }
        .sortedBy { it.name }
    return found.mapIndexed { i, s ->
        MediaItem.SubtitleConfiguration.Builder(Uri.fromFile(s))
            .setMimeType(subExts.getValue(s.extension.lowercase()))
            .setLabel(s.name)
            .setSelectionFlags(if (i == 0) C.SELECTION_FLAG_DEFAULT else 0)
            .build()
    }
}

fun trackLabel(f: Format, idx: Int, kind: String): String {
    val lang = f.language?.let { l -> runCatching { Locale(l).displayLanguage }.getOrNull() }
        ?.takeIf { it.isNotBlank() }
    val base = f.label ?: lang ?: "$kind ${idx + 1}"
    val extra = if (kind == "Audio" && f.channelCount > 0) "  •  ${f.channelCount}ch" else ""
    return base + extra
}

// ---------- Recents (continue watching) ----------

fun loadRecents(ctx: Context): List<Recent> {
    val s = ctx.getSharedPreferences("movie", Context.MODE_PRIVATE).getString("recents", null)
        ?: return emptyList()
    return runCatching {
        val a = JSONArray(s)
        (0 until a.length()).map { i ->
            val o = a.getJSONObject(i)
            Recent(o.getString("u"), o.optString("n"), o.optString("f"), o.optLong("p"), o.optLong("d"), o.optLong("t"))
        }
    }.getOrDefault(emptyList())
}

fun saveRecents(ctx: Context, list: List<Recent>) {
    val a = JSONArray()
    list.forEach { r ->
        a.put(
            JSONObject().put("u", r.uri).put("n", r.name).put("f", r.folder)
                .put("p", r.pos).put("d", r.dur).put("t", r.ts)
        )
    }
    ctx.getSharedPreferences("movie", Context.MODE_PRIVATE).edit().putString("recents", a.toString()).apply()
}

fun updateRecent(ctx: Context, v: Video, pos: Long, dur: Long) {
    if (pos < 5_000) return
    if (v.uri.scheme == "http" || v.uri.scheme == "https") return
    val key = v.uri.toString()
    val rest = loadRecents(ctx).filter { it.uri != key }
    val finished = dur > 0 && pos >= dur - 20_000
    val next = if (finished) rest
    else listOf(Recent(key, v.name, v.folder, pos, dur, System.currentTimeMillis())) + rest
    saveRecents(ctx, next.take(30))
}

fun removeRecent(ctx: Context, key: String) {
    saveRecents(ctx, loadRecents(ctx).filter { it.uri != key })
}

fun savedPosition(ctx: Context, key: String): Long =
    loadRecents(ctx).firstOrNull { it.uri == key }?.pos ?: 0L

fun recentVideo(r: Recent): Video {
    val uri = Uri.parse(r.uri)
    val id = if (uri.scheme == "file") (uri.path ?: "").hashCode().toLong()
    else runCatching { android.content.ContentUris.parseId(uri) }.getOrDefault(0L)
    return Video(id, uri, r.name, r.folder, r.dur, 0L, 0L)
}

// ---------- Shared small composables ----------

@Composable
fun MenuRow(res: Int, text: String, onClick: () -> Unit) {
    Row(
        Modifier.fillMaxWidth().clickable(onClick = onClick).padding(horizontal = 16.dp, vertical = 14.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Ic(res, 22.dp)
        Spacer(Modifier.width(12.dp))
        Text(text, color = Color.White, fontSize = 15.sp)
    }
}

@Composable
fun Panel(title: String, items: List<PanelItem>, onDismiss: () -> Unit) {
    Box(
        Modifier.fillMaxSize().background(Color.Black.copy(alpha = 0.55f)).clickable(onClick = onDismiss),
        contentAlignment = Alignment.Center
    ) {
        Column(
            Modifier.widthIn(max = 380.dp).fillMaxWidth(0.9f).heightIn(max = 280.dp)
                .clip(RoundedCornerShape(16.dp)).background(Color(0xFF1C1C22))
                .clickable(onClick = { })
        ) {
            Text(title, color = Color.White, fontSize = 16.sp, fontWeight = FontWeight.Bold, modifier = Modifier.padding(16.dp))
            LazyColumn {
                items(items) { item ->
                    Row(
                        Modifier.fillMaxWidth().clickable(onClick = item.onClick)
                            .padding(horizontal = 16.dp, vertical = 12.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            item.label,
                            color = if (item.selected) Accent else Color.White,
                            fontSize = 14.sp,
                            modifier = Modifier.weight(1f)
                        )
                        if (item.selected) Ic(R.drawable.ic_check, 20.dp, Accent)
                    }
                }
            }
        }
    }
}

// ---------- Continue watching screen ----------

@Composable
fun ContinueScreen(onMode: (Int) -> Unit, onOpen: (Video) -> Unit, onBack: () -> Unit) {
    val ctx = LocalContext.current
    var recents by remember { mutableStateOf(loadRecents(ctx)) }

    Column(Modifier.fillMaxSize().background(Bg)) {
        BrowseHeader("Continue watching", "${recents.size} videos", null) { }
        ModeTabs(2, onMode)
        if (recents.isEmpty()) {
            Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                Text(
                    "Nothing to continue yet.\nVideos you start in the Movie player will appear here.",
                    color = Fg.copy(alpha = 0.6f),
                    textAlign = TextAlign.Center,
                    modifier = Modifier.padding(32.dp)
                )
            }
        } else {
            LazyColumn(Modifier.fillMaxSize(), contentPadding = androidx.compose.foundation.layout.PaddingValues(bottom = 24.dp)) {
                items(recents) { r ->
                    val v = remember(r.uri) { recentVideo(r) }
                    val frac = if (r.dur > 0) (r.pos.toFloat() / r.dur).coerceIn(0f, 1f) else 0f
                    Row(
                        Modifier.fillMaxWidth().clickable { onOpen(v) }
                            .padding(horizontal = 14.dp, vertical = 8.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Box(Modifier.width(128.dp).height(72.dp).clip(RoundedCornerShape(10.dp))) {
                            Thumb(v, 256, 144, Modifier.fillMaxSize())
                            Box(
                                Modifier.align(Alignment.BottomStart).fillMaxWidth(frac).height(3.dp).background(Accent)
                            )
                        }
                        Spacer(Modifier.width(12.dp))
                        Column(Modifier.weight(1f)) {
                            Text(
                                r.name.substringBeforeLast('.'),
                                color = Fg,
                                fontSize = 15.sp,
                                maxLines = 2,
                                overflow = TextOverflow.Ellipsis
                            )
                            Text(
                                "${fmt(r.pos)} / ${fmt(r.dur)}  •  ${r.folder}",
                                color = Fg.copy(alpha = 0.6f),
                                fontSize = 12.sp,
                                maxLines = 1,
                                overflow = TextOverflow.Ellipsis
                            )
                        }
                        Box(
                            Modifier.size(36.dp).clip(CircleShape).clickable {
                                removeRecent(ctx, r.uri)
                                recents = loadRecents(ctx)
                            },
                            contentAlignment = Alignment.Center
                        ) {
                            Ic(R.drawable.ic_close, 18.dp, Fg.copy(alpha = 0.6f))
                        }
                    }
                }
            }
        }
    }
}

// ---------- Movie player ----------

@Composable
fun MovieScreen(list: List<Video>, startIndex: Int, onExit: (Video) -> Unit, onOpenReels: (Video) -> Unit = {}) {
    val ctx = LocalContext.current
    val activity = remember { ctx.findActivity() }
    val prefs = remember { ctx.getSharedPreferences("movie", Context.MODE_PRIVATE) }

    var idx by remember { mutableIntStateOf(startIndex.coerceIn(0, list.size - 1)) }
    var controlsVisible by remember { mutableStateOf(true) }
    var interactionTick by remember { mutableIntStateOf(0) }
    var locked by remember { mutableStateOf(false) }
    var showUnlock by remember { mutableStateOf(false) }
    var panel by remember { mutableIntStateOf(0) }
    var playMode by remember { mutableIntStateOf(prefs.getInt("play_mode", 0).coerceIn(0, 4)) }
    var dtSeekSec by remember { mutableIntStateOf(prefs.getInt("dt_seek", 10)) }
    var zoom by remember { mutableFloatStateOf(1f) }
    var panX by remember { mutableFloatStateOf(0f) }
    var panY by remember { mutableFloatStateOf(0f) }
    var boxW by remember { mutableIntStateOf(0) }
    var boxH by remember { mutableIntStateOf(0) }
    var fBright by remember { mutableFloatStateOf(prefs.getFloat("f_bright", 0f)) }
    var fContrast by remember { mutableFloatStateOf(prefs.getFloat("f_contrast", 1f)) }
    var fSat by remember { mutableFloatStateOf(prefs.getFloat("f_sat", 1f)) }
    val filterOn = fBright != 0f || fContrast != 1f || fSat != 1f
    var subScale by remember {
        mutableFloatStateOf(prefs.getFloat("sub_scale", subSizeScale[prefs.getInt("sub_size", 1).coerceIn(0, 2)]))
    }
    var subColorIdx by remember { mutableIntStateOf(prefs.getInt("sub_color", 0)) }
    var subBgIdx by remember { mutableIntStateOf(prefs.getInt("sub_bg", 0)) }
    var subPos by remember { mutableFloatStateOf(prefs.getFloat("sub_pos", 0f)) }
    val eqEngine = remember { EqEngine() }
    var eqPreset by remember { mutableIntStateOf(prefs.getInt("eq_preset", 0).coerceIn(0, 5)) }
    var bassPct by remember { mutableIntStateOf(prefs.getInt("eq_bass", 0)) }
    var eqBands by remember { mutableStateOf(loadEqBands(prefs.getString("eq_bands", null))) }
    var bookmarks by remember { mutableStateOf<List<Bookmark>>(emptyList()) }
    var chapters by remember { mutableStateOf<List<Chapter>>(emptyList()) }
    var buffering by remember { mutableStateOf(false) }
    val history = remember { ArrayList<Int>() }
    val shufflePlayed = remember { HashSet<Int>() }
    val noPersist = remember { booleanArrayOf(false) }
    var sleepEnd by remember { mutableLongStateOf(0L) }
    var abA by remember { mutableLongStateOf(-1L) }
    var abB by remember { mutableLongStateOf(-1L) }
    var boostMb by remember { mutableIntStateOf(0) }       // 0..1200 millibel, used when volume goes past 100%
    var volPct by remember { mutableFloatStateOf(100f) }   // 0..200, above 100 = boost
    var shotBmp by remember { mutableStateOf<Bitmap?>(null) }
    var shotUri by remember { mutableStateOf<Uri?>(null) }
    var shotTick by remember { mutableIntStateOf(0) }
    val strip = remember { ThumbStrip() }
    var sliderRootX by remember { mutableFloatStateOf(0f) }
    var sliderW by remember { mutableFloatStateOf(1f) }
    var barRootX by remember { mutableFloatStateOf(0f) }
    var barW by remember { mutableFloatStateOf(1f) }
    val density = LocalDensity.current
    var extCues by remember { mutableStateOf<List<ExtCue>>(emptyList()) }
    var extName by remember { mutableStateOf("") }
    var extOn by remember { mutableStateOf(true) }
    var subDelayMs by remember { mutableLongStateOf(0L) }
    var extText by remember { mutableStateOf<String?>(null) }
    var previewBmp by remember { mutableStateOf<Bitmap?>(null) }
    val scope = rememberCoroutineScope()
    val grabber = remember { FrameGrabber() }
    val enhancer = remember { arrayOfNulls<LoudnessEnhancer>(1) }
    val extDisabled = remember { booleanArrayOf(false) }
    var speed by remember { mutableFloatStateOf(prefs.getFloat("speed", 1f)) }
    var showRemaining by remember { mutableStateOf(prefs.getBoolean("show_remaining", false)) }
    var resizeIdx by remember { mutableIntStateOf(0) }
    var bgPlay by remember { mutableStateOf(prefs.getBoolean("bg_play", false)) }
    var landscape by remember { mutableStateOf(true) }
    var isPlaying by remember { mutableStateOf(false) }
    var posMs by remember { mutableLongStateOf(0L) }
    var durMs by remember { mutableLongStateOf(0L) }
    var scrubbing by remember { mutableStateOf(false) }
    var scrubValue by remember { mutableFloatStateOf(0f) }
    var tracks by remember { mutableStateOf(Tracks.EMPTY) }
    var toast by remember { mutableStateOf<String?>(null) }
    var toastIcon by remember { mutableIntStateOf(0) }
    var toastTick by remember { mutableIntStateOf(0) }
    var seekPreview by remember { mutableStateOf<String?>(null) }
    var fast by remember { mutableStateOf(false) }
    var holdSpeed by remember { mutableFloatStateOf(2f) }
    var orientLocked by remember { mutableStateOf(false) }
    var ended by remember { mutableStateOf(false) }
    val speedNow by rememberUpdatedState(speed)
    val pip = AppState.inPip

    val am = remember { ctx.getSystemService(Context.AUDIO_SERVICE) as AudioManager }
    val maxVol = remember { am.getStreamMaxVolume(AudioManager.STREAM_MUSIC).coerceAtLeast(1) }
    var volF by remember { mutableFloatStateOf(am.getStreamVolume(AudioManager.STREAM_MUSIC).toFloat()) }
    var brightness by remember {
        val b = activity?.window?.attributes?.screenBrightness ?: -1f
        mutableFloatStateOf(if (b >= 0f) b else 0.5f)
    }

    fun showToast(text: String, icon: Int = 0) {
        toast = text
        toastIcon = icon
        toastTick++
    }

    fun resetZoom() {
        zoom = 1f
        panX = 0f
        panY = 0f
    }

    val exo = remember {
        ExoPlayer.Builder(ctx)
            .setAudioAttributes(
                AudioAttributes.Builder()
                    .setUsage(C.USAGE_MEDIA)
                    .setContentType(C.AUDIO_CONTENT_TYPE_MOVIE)
                    .build(),
                true
            )
            .setHandleAudioBecomingNoisy(true)
            .setWakeMode(C.WAKE_MODE_LOCAL)
            .build()
            .apply { playWhenReady = true }
    }

    fun persist() {
        if (noPersist[0]) return
        val d = exo.duration
        if (d > 0 && idx in list.indices) updateRecent(ctx, list[idx], exo.currentPosition, d)
    }

    fun loadIndex(i: Int, startMs: Long?) {
        idx = i
        val v = list[i]
        resetZoom()
        bookmarks = loadBookmarks(ctx, v.uri.toString())
        chapters = emptyList()
        // per-video state
        val savedSpeed = prefs.getFloat("vspd_${v.id}", -1f)
        if (savedSpeed > 0f) speed = savedSpeed
        abA = -1L
        abB = -1L
        subDelayMs = 0L
        extCues = emptyList()
        extName = ""
        extOn = true
        extText = null
        // .srt / .vtt next to the video are parsed here (so the delay can be changed); the rest go to ExoPlayer
        val subConfigs = findSubtitleConfigs(ctx, v)
        val own = subConfigs.firstOrNull {
            it.mimeType == MimeTypes.APPLICATION_SUBRIP || it.mimeType == MimeTypes.TEXT_VTT
        }
        if (own != null) {
            val cues = readSubtitleText(ctx, own.uri)?.let { parseSubtitles(it) } ?: emptyList()
            if (cues.isNotEmpty()) {
                extCues = cues
                extName = own.label?.toString() ?: "subtitle"
            }
        }
        val exoConfigs = if (extCues.isNotEmpty()) subConfigs.filter {
            it.mimeType != MimeTypes.APPLICATION_SUBRIP && it.mimeType != MimeTypes.TEXT_VTT
        } else subConfigs
        val item = MediaItem.Builder()
            .setUri(v.uri)
            .setSubtitleConfigurations(exoConfigs)
            .build()
        val resume = startMs ?: savedPosition(ctx, v.uri.toString())
        if (extCues.isNotEmpty()) {
            extDisabled[0] = true
            exo.trackSelectionParameters = exo.trackSelectionParameters.buildUpon()
                .setTrackTypeDisabled(C.TRACK_TYPE_TEXT, true).build()
        } else if (extDisabled[0]) {
            extDisabled[0] = false
            exo.trackSelectionParameters = exo.trackSelectionParameters.buildUpon()
                .setTrackTypeDisabled(C.TRACK_TYPE_TEXT, false).build()
        }
        exo.setMediaItem(item, if (resume > 5_000) resume else 0L)
        exo.prepare()
        exo.play()
        ended = false
        posMs = 0L
        if (startMs == null && resume > 5_000) showToast("Resume: ${fmt(resume)}", R.drawable.ic_play)
    }

    fun nextIndex(): Int {
        if (playMode == 2 && list.size > 1) {
            shufflePlayed.add(idx)
            var cand = list.indices.filter { it !in shufflePlayed }
            if (cand.isEmpty()) {
                shufflePlayed.clear()
                shufflePlayed.add(idx)
                cand = list.indices.filter { it != idx }
            }
            return cand.random()
        }
        if (playMode == 1) return (idx + 1) % list.size
        return if (idx < list.size - 1) idx + 1 else -1
    }

    fun goNext() {
        val n = nextIndex()
        if (n == idx) {
            exo.seekTo(0L)
            exo.play()
        } else if (n >= 0) {
            history.add(idx)
            loadIndex(n, 0L)
        }
    }

    fun goPrev() {
        if (playMode == 2 && history.isNotEmpty()) {
            val p = history.removeAt(history.size - 1)
            loadIndex(p, 0L)
        } else if (idx > 0) {
            loadIndex(idx - 1, 0L)
        } else if (playMode == 1 && list.size > 1) {
            loadIndex(list.size - 1, 0L)
        }
    }

    fun presetGains(p: Int): List<Int> = List(eqEngine.bandCount) { i ->
        (presetGainDb(p, eqEngine.centerHz.getOrElse(i) { 1000 }) * 100f).toInt()
    }

    fun applyEq() {
        runCatching {
            if (eqPreset == 0 && bassPct == 0 && eqEngine.bandCount == 0) return@runCatching
            eqEngine.attach(exo.audioSessionId)
            val gains = IntArray(eqEngine.bandCount) { i ->
                if (eqPreset == 5) eqBands.getOrElse(i) { 0 }
                else (presetGainDb(eqPreset, eqEngine.centerHz.getOrElse(i) { 1000 }) * 100f).toInt()
            }
            eqEngine.apply(eqPreset != 0, gains, bassPct)
        }
    }

    fun saveEq() {
        prefs.edit().putInt("eq_preset", eqPreset).putInt("eq_bass", bassPct)
            .putString("eq_bands", eqBands.joinToString(",")).apply()
    }

    fun seekBy(ms: Long) {
        val d = exo.duration
        val t = (exo.currentPosition + ms).coerceIn(0L, if (d > 0) d else Long.MAX_VALUE)
        exo.seekTo(t)
        posMs = t
    }

    fun togglePlay() {
        if (ended) {
            exo.seekTo(0L)
            exo.play()
            ended = false
        } else if (exo.isPlaying) {
            exo.pause()
        } else {
            exo.play()
        }
    }

    fun exitMovie() {
        persist()
        onExit(list[idx])
    }

    fun openInReels() {
        persist()
        exo.pause()
        onOpenReels(list[idx])
    }

    fun selectTrack(g: Tracks.Group, i: Int) {
        if (g.type == C.TRACK_TYPE_TEXT) extOn = false
        exo.trackSelectionParameters = exo.trackSelectionParameters.buildUpon()
            .setTrackTypeDisabled(g.type, false)
            .setOverrideForType(TrackSelectionOverride(g.mediaTrackGroup, i))
            .build()
    }

    fun disableSubs() {
        exo.trackSelectionParameters = exo.trackSelectionParameters.buildUpon()
            .setTrackTypeDisabled(C.TRACK_TYPE_TEXT, true)
            .build()
    }

    fun addSubtitle(u: Uri) {
        val name = ctx.contentResolver.query(u, arrayOf(OpenableColumns.DISPLAY_NAME), null, null, null)
            ?.use { c -> if (c.moveToFirst()) c.getString(0) else null } ?: "subtitle"
        val ext = name.substringAfterLast('.', "").lowercase()
        val mime = subExts[ext] ?: MimeTypes.APPLICATION_SUBRIP
        if (ext == "srt" || ext == "vtt") {
            val cues = readSubtitleText(ctx, u)?.let { parseSubtitles(it) } ?: emptyList()
            if (cues.isNotEmpty()) {
                extCues = cues
                extName = name
                extOn = true
                exo.trackSelectionParameters = exo.trackSelectionParameters.buildUpon()
                    .setTrackTypeDisabled(C.TRACK_TYPE_TEXT, true)
                    .build()
                showToast("Subtitle loaded", R.drawable.ic_cc)
                return
            }
        }
        val cur = exo.currentMediaItem ?: return
        val existing = cur.localConfiguration?.subtitleConfigurations ?: emptyList()
        val conf = MediaItem.SubtitleConfiguration.Builder(u)
            .setMimeType(mime)
            .setLabel(name)
            .setSelectionFlags(C.SELECTION_FLAG_DEFAULT)
            .build()
        val pos = exo.currentPosition
        exo.trackSelectionParameters = exo.trackSelectionParameters.buildUpon()
            .setTrackTypeDisabled(C.TRACK_TYPE_TEXT, false)
            .build()
        exo.setMediaItem(cur.buildUpon().setSubtitleConfigurations(existing + conf).build(), pos)
        exo.prepare()
        showToast("Subtitle added", R.drawable.ic_cc)
    }

    val pickSub = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { u ->
        if (u != null) addSubtitle(u)
    }
    val notifPerm = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { }

    LaunchedEffect(Unit) { loadIndex(idx, null) }
    LaunchedEffect(speed) {
        exo.setPlaybackSpeed(speed)
        prefs.edit().putFloat("speed", speed).apply()
        if (idx in list.indices) prefs.edit().putFloat("vspd_${list[idx].id}", speed).apply()
    }
    LaunchedEffect(toastTick) {
        if (toastTick > 0) {
            delay(1000)
            toast = null
        }
    }
    LaunchedEffect(showUnlock) {
        if (showUnlock) {
            delay(2500)
            showUnlock = false
        }
    }
    LaunchedEffect(controlsVisible, isPlaying, interactionTick, panel) {
        if (controlsVisible && isPlaying && panel == 0) {
            delay(3500)
            controlsVisible = false
        }
    }
    LaunchedEffect(Unit) {
        while (true) {
            posMs = exo.currentPosition.coerceAtLeast(0)
            durMs = exo.duration.coerceAtLeast(0)
            delay(if (controlsVisible || scrubbing) 250 else 1000)
        }
    }
    LaunchedEffect(Unit) {
        while (true) {
            delay(5000)
            persist()
        }
    }
    LaunchedEffect(bgPlay) { AppState.autoPip = !bgPlay }

    DisposableEffect(exo) {
        val l = object : Player.Listener {
            override fun onIsPlayingChanged(playing: Boolean) {
                isPlaying = playing
                AppState.moviePlaying = playing
            }

            override fun onPlaybackStateChanged(state: Int) {
                buffering = state == Player.STATE_BUFFERING
                if (state == Player.STATE_ENDED) {
                    val d = exo.duration
                    updateRecent(ctx, list[idx], d, d)
                    val n = if (playMode == 4) -1 else nextIndex()
                    if (n == idx) {
                        exo.seekTo(0L)
                        exo.play()
                    } else if (n >= 0) {
                        history.add(idx)
                        loadIndex(n, 0L)
                        showToast("Next: ${list[idx].name.substringBeforeLast('.')}", R.drawable.ic_skip_next)
                    } else {
                        ended = true
                        controlsVisible = true
                    }
                }
            }

            override fun onPlayerError(error: PlaybackException) {
                buffering = false
                showToast("Can't play this video", R.drawable.ic_info)
                controlsVisible = true
            }

            override fun onAudioSessionIdChanged(audioSessionId: Int) {
                applyEq()
            }

            override fun onTracksChanged(t: Tracks) {
                tracks = t
            }

            override fun onVideoSizeChanged(videoSize: VideoSize) {
                AppState.videoW = videoSize.width
                AppState.videoH = videoSize.height
            }
        }
        exo.addListener(l)
        onDispose {
            exo.removeListener(l)
            persist()
            exo.release()
        }
    }

    DisposableEffect(Unit) {
        AppState.movieActive = true
        activity?.requestedOrientation = ActivityInfo.SCREEN_ORIENTATION_SENSOR
        onDispose {
            AppState.movieActive = false
            AppState.moviePlaying = false
            activity?.requestedOrientation = ActivityInfo.SCREEN_ORIENTATION_PORTRAIT
            activity?.window?.let { w ->
                val a = w.attributes
                a.screenBrightness = WindowManager.LayoutParams.BRIGHTNESS_OVERRIDE_NONE
                w.attributes = a
            }
        }
    }

    // A-B repeat
    LaunchedEffect(abA, abB) {
        if (abA >= 0L && abB > abA) {
            while (true) {
                delay(100)
                if (exo.currentPosition >= abB) exo.seekTo(abA)
            }
        }
    }
    // Volume above 100%: LoudnessEnhancer on the player's audio session
    val enhSession = remember { intArrayOf(0) }
    fun applyBoost() {
        runCatching {
            val sid = exo.audioSessionId
            if (boostMb <= 0) {
                enhancer[0]?.let { it.setTargetGain(0); it.enabled = false }
            } else if (sid != 0) {
                if (enhancer[0] == null || enhSession[0] != sid) {
                    enhancer[0]?.release()
                    enhancer[0] = LoudnessEnhancer(sid)
                    enhSession[0] = sid
                }
                enhancer[0]!!.setTargetGain(boostMb)
                enhancer[0]!!.enabled = true
            }
            Unit
        }
    }
    LaunchedEffect(boostMb, idx) {
        if (boostMb > 0 && enhancer[0] == null) delay(200)
        applyBoost()
    }
    DisposableEffect(Unit) {
        onDispose {
            runCatching { enhancer[0]?.release() }
            eqEngine.release()
            grabber.release()
        }
    }
    // Subtitle file overlay: checked often so cues appear on time
    LaunchedEffect(extCues, extOn, subDelayMs) {
        if (extCues.isEmpty() || !extOn) {
            extText = null
        } else {
            while (true) {
                extText = cueAt(extCues, exo.currentPosition - subDelayMs)
                delay(80)
            }
        }
    }
    // Seek bar preview: a strip of small frames is built in the background, so dragging shows a frame at once;
    // when the finger rests, the exact frame is fetched and replaces it.
    LaunchedEffect(idx, durMs > 0L) {
        if (durMs > 0L && !isNetworkVideo(list[idx])) {
            delay(1500)
            strip.generate(ctx, list[idx].uri, durMs)
        }
    }
    LaunchedEffect(scrubbing, scrubValue) {
        if (!scrubbing) {
            previewBmp = null
        } else {
            strip.nearest(scrubValue)?.let { previewBmp = it }
            delay(140)
            val t = (scrubValue * durMs).toLong()
            val v = list[idx]
            val b = if (isNetworkVideo(v)) null else withContext(Dispatchers.IO) { grabber.frame(ctx, v.uri, t, 320) }
            if (scrubbing && b != null) previewBmp = b
        }
    }
    DisposableEffect(idx) {
        onDispose { strip.clear() }
    }

    fun takeScreenshot() {
        val v = list[idx]
        if (isNetworkVideo(v)) {
            showToast("Screenshot isn't available for streams", R.drawable.ic_image)
            return
        }
        val t = exo.currentPosition
        scope.launch {
            val res = withContext(Dispatchers.IO) {
                val bmp = grabFullFrame(ctx, v.uri, t)
                val u = if (bmp != null) saveScreenshot(ctx, bmp, v.name.substringBeforeLast('.')) else null
                if (bmp == null || u == null) null else {
                    val w = 360
                    val small = Bitmap.createScaledBitmap(bmp, w, (w * bmp.height / bmp.width.toFloat()).toInt().coerceAtLeast(1), true)
                    Pair(small, u)
                }
            }
            if (res != null) {
                shotBmp = res.first
                shotUri = res.second
                shotTick++
            } else {
                showToast("Screenshot failed", R.drawable.ic_image)
            }
        }
    }
    LaunchedEffect(shotTick) {
        if (shotTick > 0) {
            delay(3000)
            shotBmp = null
        }
    }

    LaunchedEffect(playMode) {
        exo.repeatMode = if (playMode == 3) androidx.media3.common.Player.REPEAT_MODE_ONE
        else androidx.media3.common.Player.REPEAT_MODE_OFF
        prefs.edit().putInt("play_mode", playMode).apply()
    }
    LaunchedEffect(eqPreset, bassPct, eqBands, idx) {
        delay(150)
        applyEq()
    }
    LaunchedEffect(idx) {
        chapters = withContext(Dispatchers.IO) {
            runCatching { readChapters(ctx, list[idx]) }.getOrDefault(emptyList())
        }
    }
    LaunchedEffect(sleepEnd) {
        if (sleepEnd > 0L) {
            delay((sleepEnd - System.currentTimeMillis()).coerceAtLeast(0L))
            exo.pause()
            sleepEnd = 0L
            showToast("Sleep timer: paused", R.drawable.ic_timer)
        }
    }

    // Android likes to bring the status bar back after a rotation; hide it again.
    val orientationNow = LocalConfiguration.current.orientation
    LaunchedEffect(orientationNow) {
        activity?.window?.let { w ->
            androidx.core.view.WindowInsetsControllerCompat(w, w.decorView)
                .hide(androidx.core.view.WindowInsetsCompat.Type.systemBars())
        }
    }

    val owner = LocalLifecycleOwner.current
    DisposableEffect(owner) {
        var wasPlaying = false
        val obs = LifecycleEventObserver { _, e ->
            if (e == Lifecycle.Event.ON_STOP) {
                persist()
                val inPip = activity?.isInPictureInPictureMode == true
                if (!bgPlay && !inPip) {
                    wasPlaying = exo.isPlaying
                    exo.pause()
                }
            }
            if (e == Lifecycle.Event.ON_START) {
                if (wasPlaying) {
                    exo.play()
                    wasPlaying = false
                }
            }
        }
        owner.lifecycle.addObserver(obs)
        onDispose { owner.lifecycle.removeObserver(obs) }
    }

    DisposableEffect(bgPlay) {
        if (bgPlay) {
            ContextCompat.startForegroundService(
                ctx,
                Intent(ctx, PlaybackService::class.java).putExtra("title", list[idx].name.substringBeforeLast('.'))
            )
        }
        onDispose { ctx.stopService(Intent(ctx, PlaybackService::class.java)) }
    }
    LaunchedEffect(idx) {
        if (bgPlay) {
            ContextCompat.startForegroundService(
                ctx,
                Intent(ctx, PlaybackService::class.java).putExtra("title", list[idx].name.substringBeforeLast('.'))
            )
        }
    }

    BackHandler {
        if (panel != 0) {
            panel = 0
        } else if (locked) {
            showUnlock = true
            showToast("Unlock the screen first", R.drawable.ic_lock)
        } else {
            exitMovie()
        }
    }

    val progress = if (durMs > 0) (posMs.toFloat() / durMs).coerceIn(0f, 1f) else 0f
    val showControls = controlsVisible || ended
    val isLand = LocalConfiguration.current.orientation == android.content.res.Configuration.ORIENTATION_LANDSCAPE
    val sideM = if (isLand) 28.dp else 14.dp
    val topM = if (isLand) 8.dp else 18.dp
    val topBarH = 42.dp

    // App content never goes under the status bar / navigation bar / camera cutout.
    // (When the bars are hidden these insets are 0, so the player stays full screen.)
    Box(
        Modifier.fillMaxSize().background(Color.Black)
            .windowInsetsPadding(WindowInsets.systemBars.union(WindowInsets.displayCutout))
            .onSizeChanged {
                boxW = it.width
                boxH = it.height
            }
    ) {
        Box(Modifier.fillMaxSize().clipToBounds()) {
            AndroidView(
                factory = { c ->
                    (android.view.LayoutInflater.from(c).inflate(R.layout.player_texture, null, false) as PlayerView).apply {
                        useController = false
                        keepScreenOn = true
                        setShutterBackgroundColor(android.graphics.Color.BLACK)
                        player = exo
                    }
                },
                update = { pv ->
                    pv.resizeMode = if (pip) AspectRatioFrameLayout.RESIZE_MODE_FIT else resizeModes[resizeIdx]
                    pv.subtitleView?.setStyle(captionStyleFor(subColorIdx, subBgIdx))
                    pv.subtitleView?.setFractionalTextSize(0.0533f * subScale)
                    pv.subtitleView?.setBottomPaddingFraction(0.08f + subPos)
                    val tv = pv.videoSurfaceView as? android.view.TextureView
                    if (tv != null) {
                        val neutral = fBright == 0f && fContrast == 1f && fSat == 1f
                        tv.setLayerPaint(if (neutral) null else buildFilterPaint(fBright, fContrast, fSat))
                    }
                },
                modifier = Modifier.fillMaxSize().graphicsLayer {
                    val z = if (pip) 1f else zoom
                    scaleX = z
                    scaleY = z
                    translationX = if (pip) 0f else panX
                    translationY = if (pip) 0f else panY
                }
            )
        }

        // Screenshot preview card
        val shot = shotBmp
        if (!pip && shot != null) {
            Box(
                Modifier.align(Alignment.BottomStart)
                    .padding(start = sideM + 56.dp, bottom = if (isLand) 24.dp else 90.dp)
                    .width(if (isLand) 130.dp else 120.dp)
                    .clip(RoundedCornerShape(10.dp))
                    .background(Color.Black)
                    .clickable {
                        val u = shotUri
                        if (u != null) runCatching {
                            ctx.startActivity(
                                Intent(Intent.ACTION_VIEW).setDataAndType(u, "image/jpeg")
                                    .addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_ACTIVITY_NEW_TASK)
                            )
                        }
                    }
            ) {
                Image(
                    bitmap = shot.asImageBitmap(), contentDescription = null,
                    modifier = Modifier.fillMaxWidth().aspectRatio(shot.width.toFloat() / shot.height.toFloat())
                )
                Text(
                    "Screenshot saved", color = Color.White, fontSize = 10.sp, fontWeight = FontWeight.SemiBold,
                    modifier = Modifier.align(Alignment.BottomCenter).fillMaxWidth()
                        .background(Color.Black.copy(alpha = 0.6f)).padding(vertical = 3.dp),
                    textAlign = TextAlign.Center
                )
            }
        }

        // External subtitle file (own renderer, so the delay works)
        val subText = extText
        if (!pip && subText != null) {
            val lift = if (showControls) (if (isLand) 112.dp else 150.dp) else 0.dp
            val basePad = (if (isLand) 28.dp else 64.dp) + with(density) { (boxH * subPos).toDp() }
            Box(
                Modifier.align(Alignment.BottomCenter)
                    .padding(bottom = if (basePad > lift) basePad else lift, start = 40.dp, end = 40.dp)
                    .background(subBgColor(subBgIdx), RoundedCornerShape(8.dp))
                    .padding(horizontal = 10.dp, vertical = 4.dp)
            ) {
                Text(
                    subText,
                    color = subColors[subColorIdx.coerceIn(0, subColors.size - 1)],
                    textAlign = TextAlign.Center,
                    fontSize = (18f * subScale).sp,
                    style = if (subBgIdx == 2) TextStyle.Default else subTextShadow
                )
            }
        }

        if (!pip) {
            if (locked) {
                Box(
                    Modifier.fillMaxSize().pointerInput(Unit) {
                        detectTapGestures(onTap = { showUnlock = true })
                    }
                )
                if (showUnlock) {
                    Box(Modifier.align(Alignment.TopStart).padding(start = sideM, top = topM + topBarH + 10.dp)) {
                        CircleBtn(R.drawable.ic_lock_open, onClick = {
                            locked = false
                            showUnlock = false
                            controlsVisible = true
                        }, size = 44.dp)
                    }
                }
            } else {
                // Gesture layers: tap / double tap / hold, and drag (seek, brightness, volume)
                Box(
                    Modifier.fillMaxSize()
                        .pointerInput(Unit) {
                            detectTapGestures(
                                onLongPress = { },
                                onTap = {
                                    controlsVisible = !controlsVisible
                                    interactionTick++
                                },
                                onDoubleTap = { off ->
                                    val w = size.width
                                    if (off.x < w * 0.4f) {
                                        seekBy(-dtSeekSec * 1000L)
                                        showToast("-${dtSeekSec}s", R.drawable.ic_replay)
                                    } else if (off.x > w * 0.6f) {
                                        seekBy(dtSeekSec * 1000L)
                                        showToast("+${dtSeekSec}s", R.drawable.ic_forward)
                                    } else {
                                        togglePlay()
                                    }
                                }
                            )
                        }
                        .pointerInput(Unit) {
                            var axis = 0
                            var accX = 0f
                            var accY = 0f
                            var startPos = 0L
                            var target = 0L
                            var leftSide = true
                            detectDragGestures(
                                onDragStart = { off ->
                                    axis = 0
                                    accX = 0f
                                    accY = 0f
                                    startPos = exo.currentPosition
                                    target = startPos
                                    leftSide = off.x < size.width / 2f
                                    if (!leftSide && boostMb == 0) {
                                        volPct = am.getStreamVolume(AudioManager.STREAM_MUSIC) * 100f / maxVol
                                    }
                                },
                                onDragEnd = {
                                    if (axis == 1) {
                                        exo.seekTo(target)
                                        posMs = target
                                    }
                                    seekPreview = null
                                    axis = 0
                                },
                                onDragCancel = {
                                    seekPreview = null
                                    axis = 0
                                }
                            ) { change, drag ->
                                change.consume()
                                accX += drag.x
                                accY += drag.y
                                if (axis == 0 && (abs(accX) > 24f || abs(accY) > 24f)) {
                                    axis = if (abs(accX) > abs(accY)) 1 else 2
                                }
                                if (axis == 1) {
                                    val d = exo.duration
                                    val delta = (accX / size.width * 120_000f).toLong()
                                    target = (startPos + delta).coerceIn(0L, if (d > 0) d else Long.MAX_VALUE)
                                    val sign = if (target >= startPos) "+" else "-"
                                    seekPreview = "${fmt(target)}  ($sign${fmt(abs(target - startPos))})"
                                } else if (axis == 2) {
                                    val frac = -drag.y / size.height
                                    if (leftSide) {
                                        brightness = (brightness + frac).coerceIn(0.02f, 1f)
                                        activity?.window?.let { w ->
                                            val a = w.attributes
                                            a.screenBrightness = brightness
                                            w.attributes = a
                                        }
                                        showToast("Brightness ${(brightness * 100).roundToInt()}%", R.drawable.ic_brightness)
                                    } else {
                                        // 0-100% = system volume, 100-200% = extra boost (up to +12 dB)
                                        volPct = (volPct + frac * 150f).coerceIn(0f, 200f)
                                        val sys = (minOf(volPct, 100f) / 100f * maxVol).roundToInt()
                                        am.setStreamVolume(AudioManager.STREAM_MUSIC, sys, 0)
                                        boostMb = if (volPct > 100f) ((volPct - 100f) / 100f * 1200f).roundToInt() else 0
                                        showToast("Volume ${volPct.roundToInt()}%", R.drawable.ic_volume_on)
                                    }
                                }
                            }
                        }
                        .pointerInput(Unit) {
                            holdSlideSpeed(
                                canStart = { exo.isPlaying },
                                onSpeed = { sp ->
                                    exo.setPlaybackSpeed(sp)
                                    holdSpeed = sp
                                    fast = true
                                },
                                onEnd = {
                                    exo.setPlaybackSpeed(speedNow)
                                    fast = false
                                }
                            )
                        }
                        .pointerInput(Unit) {
                            pinchPanDetector(
                                onTransform = { z, pan, c ->
                                    val oldZ = zoom
                                    val newZ = (oldZ * z).coerceIn(1f, 5f)
                                    val cx = c.x - size.width / 2f
                                    val cy = c.y - size.height / 2f
                                    val tx = cx - newZ * (cx - panX) / oldZ + pan.x
                                    val ty = cy - newZ * (cy - panY) / oldZ + pan.y
                                    val maxX = size.width * (newZ - 1f) / 2f
                                    val maxY = size.height * (newZ - 1f) / 2f
                                    zoom = newZ
                                    panX = tx.coerceIn(-maxX, maxX)
                                    panY = ty.coerceIn(-maxY, maxY)
                                },
                                onEnd = {
                                    if (zoom < 1.05f) {
                                        zoom = 1f
                                        panX = 0f
                                        panY = 0f
                                    }
                                }
                            )
                        }
                )

                // Controls
                AnimatedVisibility(
                    visible = showControls,
                    modifier = Modifier.fillMaxSize(),
                    enter = fadeIn(),
                    exit = fadeOut()
                ) {
                    Box(Modifier.fillMaxSize()) {
                        Box(
                            Modifier.align(Alignment.TopCenter).fillMaxWidth().height(if (isLand) 84.dp else 110.dp)
                                .background(Brush.verticalGradient(listOf(Color.Black.copy(alpha = 0.7f), Color.Transparent)))
                        )
                        Box(
                            Modifier.align(Alignment.BottomCenter).fillMaxWidth().height(if (isLand) 150.dp else 200.dp)
                                .background(Brush.verticalGradient(listOf(Color.Transparent, Color.Black.copy(alpha = 0.8f))))
                        )

                        // Top bar
                        Row(
                            Modifier.align(Alignment.TopCenter).fillMaxWidth()
                                .padding(start = sideM, end = sideM, top = topM),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            CircleBtn(R.drawable.ic_back, onClick = { exitMovie() })
                            Column(Modifier.weight(1f).padding(horizontal = 12.dp)) {
                                Text(
                                    list[idx].name.substringBeforeLast('.'),
                                    color = Color.White,
                                    fontSize = 16.sp,
                                    fontWeight = FontWeight.SemiBold,
                                    maxLines = 1,
                                    overflow = TextOverflow.Ellipsis
                                )
                                if (list.size > 1) {
                                    Text("${idx + 1} / ${list.size}", color = Color.White.copy(alpha = 0.7f), fontSize = 12.sp)
                                }
                            }
                            CircleBtn(R.drawable.ic_cc, onClick = { panel = 2; interactionTick++ })
                            Spacer(Modifier.width(10.dp))
                            CircleBtn(R.drawable.ic_audiotrack, onClick = { panel = 1; interactionTick++ })
                            Spacer(Modifier.width(10.dp))
                            CircleBtn(R.drawable.ic_more_vert, onClick = { panel = 4; interactionTick++ })
                        }

                        // Quick buttons: vertically centered, left and right edge
                        Column(
                            Modifier.align(Alignment.CenterStart).padding(start = sideM),
                            verticalArrangement = Arrangement.spacedBy(14.dp)
                        ) {
                            CircleBtn(
                                if (orientLocked) R.drawable.ic_lock else R.drawable.ic_rotate,
                                onClick = {
                                    val a = activity
                                    if (a != null) {
                                        if (orientLocked) {
                                            // back to automatic: follows the sensor, like VLC
                                            a.requestedOrientation = ActivityInfo.SCREEN_ORIENTATION_SENSOR
                                            orientLocked = false
                                            showToast("Auto rotate", R.drawable.ic_rotate)
                                        } else {
                                            // freeze whatever orientation we are in right now
                                            a.requestedOrientation = ActivityInfo.SCREEN_ORIENTATION_LOCKED
                                            orientLocked = true
                                            showToast("Orientation locked", R.drawable.ic_lock)
                                        }
                                    }
                                    interactionTick++
                                },
                                size = 40.dp
                            )
                            Box(
                                Modifier.size(40.dp).clip(CircleShape).background(Color.Black.copy(alpha = 0.35f))
                                    .clickable { panel = 3; interactionTick++ },
                                contentAlignment = Alignment.Center
                            ) {
                                Text(fmtSpeed(speed), color = Color.White, fontSize = 11.sp, fontWeight = FontWeight.Bold, maxLines = 1)
                            }
                        }
                        Column(
                            Modifier.align(Alignment.CenterEnd).padding(end = sideM),
                            verticalArrangement = Arrangement.spacedBy(14.dp)
                        ) {
                            CircleBtn(R.drawable.ic_image, onClick = { takeScreenshot(); interactionTick++ }, size = 40.dp)
                            CircleBtn(
                                R.drawable.ic_aspect,
                                onClick = {
                                    resizeIdx = (resizeIdx + 1) % resizeModes.size
                                    resetZoom()
                                    showToast(resizeNames[resizeIdx], R.drawable.ic_aspect)
                                    interactionTick++
                                },
                                size = 40.dp
                            )
                        }

                        // Seek preview: sits above the finger
                        val prevBmp = previewBmp
                        if (scrubbing && prevBmp != null) {
                            val hDp = if (isLand) 80.dp else 96.dp
                            val wPx = with(density) { hDp.toPx() } * prevBmp.width / prevBmp.height.toFloat()
                            val pad = with(density) { 10.dp.toPx() }
                            val center = (sliderRootX - barRootX) + pad + (sliderW - 2 * pad) * scrubValue.coerceIn(0f, 1f)
                            val x = (center - wPx / 2f).coerceIn(0f, (barW - wPx).coerceAtLeast(0f))
                            Box(
                                Modifier.align(Alignment.BottomCenter).fillMaxWidth()
                                    .padding(start = sideM + 2.dp, end = sideM + 2.dp)
                                    .padding(bottom = if (isLand) 108.dp else 132.dp)
                            ) {
                                Column(
                                    Modifier.offset { IntOffset(x.roundToInt(), 0) },
                                    horizontalAlignment = Alignment.CenterHorizontally
                                ) {
                                    Image(
                                        bitmap = prevBmp.asImageBitmap(), contentDescription = null,
                                        modifier = Modifier.height(hDp)
                                            .aspectRatio(prevBmp.width.toFloat() / prevBmp.height.toFloat())
                                            .clip(RoundedCornerShape(10.dp))
                                    )
                                    Text(
                                        fmt((scrubValue * durMs).toLong()), color = Color.White, fontSize = 13.sp,
                                        fontWeight = FontWeight.SemiBold, modifier = Modifier.padding(top = 4.dp)
                                    )
                                }
                            }
                        }

                        // Bottom: seek bar + options
                        Column(
                            Modifier.align(Alignment.BottomCenter).fillMaxWidth()
                                .onGloballyPositioned {
                                    barRootX = it.positionInRoot().x + with(density) { (sideM + 2.dp).toPx() }
                                    barW = it.size.width - with(density) { (sideM * 2 + 4.dp).toPx() }
                                }
                                .padding(start = sideM + 2.dp, end = sideM + 2.dp, bottom = if (isLand) 6.dp else 10.dp)
                        ) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                val curMs = if (scrubbing) (scrubValue * durMs).toLong() else posMs
                                Text(
                                    fmt(curMs),
                                    color = Color.White, fontSize = 13.sp,
                                    modifier = Modifier.clickable {
                                        showRemaining = !showRemaining
                                        prefs.edit().putBoolean("show_remaining", showRemaining).apply()
                                        interactionTick++
                                    }.padding(horizontal = 4.dp, vertical = 8.dp)
                                )
                                Box(Modifier.weight(1f).padding(horizontal = 8.dp)) {
                                Slider(
                                    value = if (scrubbing) scrubValue else progress,
                                    onValueChange = {
                                        scrubbing = true
                                        scrubValue = it
                                        interactionTick++
                                    },
                                    onValueChangeFinished = {
                                        val d = exo.duration
                                        if (d > 0) {
                                            val t = (scrubValue * d).toLong()
                                            exo.seekTo(t)
                                            posMs = t
                                        }
                                        scrubbing = false
                                    },
                                    modifier = Modifier.fillMaxWidth()
                                        .onGloballyPositioned {
                                            sliderRootX = it.positionInRoot().x
                                            sliderW = it.size.width.toFloat()
                                        },
                                    colors = SliderDefaults.colors(
                                        thumbColor = Accent,
                                        activeTrackColor = Accent,
                                        inactiveTrackColor = Color.White.copy(alpha = 0.3f)
                                    )
                                )
                                SeekMarkers(durMs, bookmarks.map { it.posMs }, chapters.map { it.startMs }, Modifier.matchParentSize())
                                }
                                Text(
                                    if (showRemaining) "-" + fmt((durMs - (if (scrubbing) (scrubValue * durMs).toLong() else posMs)).coerceAtLeast(0))
                                    else fmt(durMs),
                                    color = Color.White, fontSize = 13.sp,
                                    modifier = Modifier.clickable {
                                        showRemaining = !showRemaining
                                        prefs.edit().putBoolean("show_remaining", showRemaining).apply()
                                        interactionTick++
                                    }.padding(horizontal = 4.dp, vertical = 8.dp)
                                )
                            }
                            // Transport row: prev - play - next, centered
                            val playSize = if (isLand) 56.dp else 62.dp
                            val skipSize = if (isLand) 42.dp else 46.dp
                            Box(Modifier.fillMaxWidth().padding(top = if (isLand) 0.dp else 2.dp)) {
                                Row(
                                    Modifier.align(Alignment.Center),
                                    horizontalArrangement = Arrangement.spacedBy(if (isLand) 28.dp else 18.dp),
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Box(Modifier.alpha(if (idx > 0 || playMode == 1 || (playMode == 2 && history.isNotEmpty())) 1f else 0.3f)) {
                                        CircleBtn(R.drawable.ic_skip_prev, onClick = { goPrev() }, size = skipSize)
                                    }
                                    Box(
                                        Modifier.size(playSize).clip(CircleShape).background(Accent)
                                            .clickable { togglePlay(); interactionTick++ },
                                        contentAlignment = Alignment.Center
                                    ) {
                                        Ic(
                                            if (ended) R.drawable.ic_replay
                                            else if (isPlaying) R.drawable.ic_pause
                                            else R.drawable.ic_play,
                                            if (isLand) 30.dp else 34.dp
                                        )
                                    }
                                    Box(Modifier.alpha(if (idx < list.size - 1 || playMode == 1 || (playMode == 2 && list.size > 1)) 1f else 0.3f)) {
                                        CircleBtn(R.drawable.ic_skip_next, onClick = { goNext() }, size = skipSize)
                                    }
                                }
                            }
                        }
                    }
                }

                // Sleep timer
                if (panel == 5) {
                    ChoiceDialog(
                        title = "Sleep timer",
                        options = listOf("Off", "15 minutes", "30 minutes", "45 minutes", "60 minutes", "90 minutes"),
                        selected = -1,
                        onPick = { i ->
                            panel = 0
                            val mins = listOf(0, 15, 30, 45, 60, 90)[i]
                            sleepEnd = if (mins == 0) 0L else System.currentTimeMillis() + mins * 60_000L
                            showToast(if (mins == 0) "Sleep timer off" else "Pause in $mins min", R.drawable.ic_timer)
                        },
                        onDismiss = { panel = 0 }
                    )
                }

                // Subtitle delay
                if (panel == 7) {
                    SubDelayDialog(
                        delayMs = subDelayMs,
                        hasFile = extCues.isNotEmpty(),
                        onChange = { subDelayMs = it },
                        onDismiss = { panel = 0 }
                    )
                }

                // Video info
                if (panel == 6) {
                    val v = list[idx]
                    val res = if (AppState.videoW > 0) "${AppState.videoW} x ${AppState.videoH}" else "-"
                    InfoDialog(
                        title = "Video info",
                        rows = listOf(
                            "Name" to v.name,
                            "Duration" to fmt(exo.duration.coerceAtLeast(0L)),
                            "Resolution" to res,
                            "Size" to android.text.format.Formatter.formatShortFileSize(ctx, v.sizeBytes),
                            "Folder" to v.folder
                        ),
                        onDismiss = { panel = 0 }
                    )
                }

                // New dialogs
                if (panel == 8) {
                    PlayerSettingsDialog(
                        dtSeekSec = dtSeekSec,
                        playMode = playMode,
                        onDtSeek = {
                            dtSeekSec = it
                            prefs.edit().putInt("dt_seek", it).apply()
                        },
                        onPlayMode = { playMode = it },
                        onDismiss = { panel = 0 }
                    )
                }
                if (panel == 15) {
                    ChoiceDialog(
                        title = "When a video ends",
                        options = playModeNames,
                        selected = playMode,
                        onPick = { i ->
                            playMode = i
                            panel = 0
                            showToast(playModeNames[i], R.drawable.ic_shuffle)
                        },
                        onDismiss = { panel = 0 }
                    )
                }
                if (panel == 9) {
                    EqualizerDialog(
                        engine = eqEngine,
                        preset = eqPreset,
                        bassPct = bassPct,
                        bandsMb = if (eqPreset == 5 && eqBands.size == eqEngine.bandCount) eqBands else presetGains(eqPreset),
                        onPreset = { p ->
                            if (p == 5 && eqBands.size != eqEngine.bandCount) eqBands = presetGains(eqPreset)
                            eqPreset = p
                            saveEq()
                        },
                        onBass = {
                            bassPct = it
                            saveEq()
                        },
                        onBand = { i, v ->
                            val base = if (eqPreset == 5 && eqBands.size == eqEngine.bandCount) eqBands else presetGains(eqPreset)
                            eqBands = base.toMutableList().also { m -> if (i in m.indices) m[i] = v }
                            eqPreset = 5
                            saveEq()
                        },
                        onDismiss = { panel = 0 }
                    )
                }
                if (panel == 10) {
                    FilterDialog(
                        brightness = fBright,
                        contrast = fContrast,
                        saturation = fSat,
                        onBrightness = {
                            fBright = it
                            prefs.edit().putFloat("f_bright", it).apply()
                        },
                        onContrast = {
                            fContrast = it
                            prefs.edit().putFloat("f_contrast", it).apply()
                        },
                        onSaturation = {
                            fSat = it
                            prefs.edit().putFloat("f_sat", it).apply()
                        },
                        onReset = {
                            fBright = 0f
                            fContrast = 1f
                            fSat = 1f
                            prefs.edit().putFloat("f_bright", 0f).putFloat("f_contrast", 1f).putFloat("f_sat", 1f).apply()
                        },
                        onDismiss = { panel = 0 }
                    )
                }
                if (panel == 11) {
                    SubtitleStyleDialog(
                        scale = subScale,
                        colorIdx = subColorIdx,
                        bgIdx = subBgIdx,
                        pos = subPos,
                        onScale = {
                            subScale = it
                            prefs.edit().putFloat("sub_scale", it).apply()
                        },
                        onColor = {
                            subColorIdx = it
                            prefs.edit().putInt("sub_color", it).apply()
                        },
                        onBg = {
                            subBgIdx = it
                            prefs.edit().putInt("sub_bg", it).apply()
                        },
                        onPos = {
                            subPos = it
                            prefs.edit().putFloat("sub_pos", it).apply()
                        },
                        onReset = {
                            subScale = 1f
                            subColorIdx = 0
                            subBgIdx = 0
                            subPos = 0f
                            prefs.edit().putFloat("sub_scale", 1f).putInt("sub_color", 0).putInt("sub_bg", 0)
                                .putFloat("sub_pos", 0f).apply()
                        },
                        onDismiss = { panel = 0 }
                    )
                }
                if (panel == 12) {
                    BookmarksDialog(
                        list = bookmarks,
                        curMs = exo.currentPosition,
                        onAdd = {
                            val p = exo.currentPosition
                            val nl = (bookmarks + Bookmark(p, "")).sortedBy { it.posMs }.distinctBy { it.posMs / 1000L }
                            bookmarks = nl
                            saveBookmarks(ctx, list[idx].uri.toString(), nl)
                            showToast("Bookmark added", R.drawable.ic_bookmark)
                        },
                        onJump = { b ->
                            exo.seekTo(b.posMs)
                            posMs = b.posMs
                            panel = 0
                        },
                        onDelete = { b ->
                            val nl = bookmarks.filter { it !== b }
                            bookmarks = nl
                            saveBookmarks(ctx, list[idx].uri.toString(), nl)
                        },
                        onDismiss = { panel = 0 }
                    )
                }
                if (panel == 13) {
                    ChaptersDialog(
                        chapters = chapters,
                        curMs = exo.currentPosition,
                        onJump = { c ->
                            exo.seekTo(c.startMs)
                            posMs = c.startMs
                            panel = 0
                        },
                        onDismiss = { panel = 0 }
                    )
                }
                if (panel == 14) {
                    VideoActionsHost(
                        v = list[idx],
                        onDismiss = { panel = 0 },
                        onGone = { msg ->
                            noPersist[0] = true
                            removeRecent(ctx, list[idx].uri.toString())
                            exo.pause()
                            android.widget.Toast.makeText(ctx, msg, android.widget.Toast.LENGTH_SHORT).show()
                            AppState.libraryTick++
                            onExit(list[idx])
                        }
                    )
                }

                // 3-dot menu
                if (panel == 4) {
                    val net = isNetworkVideo(list[idx])
                    val entries = buildList<MenuEntry> {
                        add(MenuEntry(R.drawable.ic_list, "Chapters", if (chapters.isEmpty()) "None" else "${chapters.size}", chapters.isNotEmpty()) { panel = 13 })
                        add(MenuEntry(R.drawable.ic_bookmark, "Bookmarks", if (bookmarks.isEmpty()) null else "${bookmarks.size}", bookmarks.isNotEmpty()) { panel = 12 })
                        add(
                            MenuEntry(
                                R.drawable.ic_equalizer, "Equalizer",
                                if (eqPreset != 0 || bassPct > 0) eqPresetNames[eqPreset] else "Off",
                                eqPreset != 0 || bassPct > 0
                            ) {
                                eqEngine.attach(exo.audioSessionId)
                                panel = 9
                            }
                        )
                        add(MenuEntry(R.drawable.ic_tune, "Video filters", if (filterOn) "On" else "Off", filterOn) { panel = 10 })
                        add(MenuEntry(R.drawable.ic_shuffle, "When video ends", playModeNames[playMode], playMode != 0) { panel = 15 })
                        add(MenuEntry(R.drawable.ic_settings, "Player settings", "${dtSeekSec}s") { panel = 8 })
                        add(MenuEntry(0, "", divider = true) { })
                        add(
                            MenuEntry(
                                R.drawable.ic_cc, "Subtitle delay", "${"%+.1f".format(subDelayMs / 1000f)} s",
                                subDelayMs != 0L
                            ) { panel = 7 }
                        )
                        val abText = if (abA < 0L) "Off" else if (abB < 0L) "A ${fmt(abA)}" else "${fmt(abA)} - ${fmt(abB)}"
                        add(
                            MenuEntry(R.drawable.ic_repeat, "A-B repeat", abText, abText != "Off") {
                                panel = 0
                                if (abA < 0L) {
                                    abA = exo.currentPosition
                                    showToast("Point A set - open menu again for B", R.drawable.ic_repeat)
                                } else if (abB < 0L) {
                                    val b = exo.currentPosition
                                    if (b > abA + 500L) {
                                        abB = b
                                        showToast("A-B repeat ON", R.drawable.ic_repeat)
                                    } else {
                                        showToast("B must be after A", R.drawable.ic_repeat)
                                    }
                                } else {
                                    abA = -1L
                                    abB = -1L
                                    showToast("A-B repeat OFF", R.drawable.ic_repeat)
                                }
                            }
                        )
                        add(
                            MenuEntry(R.drawable.ic_headset, "Background play", if (bgPlay) "On" else "Off", bgPlay) {
                                panel = 0
                                bgPlay = !bgPlay
                                prefs.edit().putBoolean("bg_play", bgPlay).apply()
                                if (bgPlay && Build.VERSION.SDK_INT >= 33 &&
                                    ContextCompat.checkSelfPermission(ctx, Manifest.permission.POST_NOTIFICATIONS)
                                    != PackageManager.PERMISSION_GRANTED
                                ) {
                                    notifPerm.launch(Manifest.permission.POST_NOTIFICATIONS)
                                }
                                showToast(if (bgPlay) "Background play ON" else "Background play OFF", R.drawable.ic_headset)
                            }
                        )
                        val sleepText = if (sleepEnd > 0L) "${((sleepEnd - System.currentTimeMillis()) / 60000L + 1)} min" else "Off"
                        add(MenuEntry(R.drawable.ic_timer, "Sleep timer", sleepText, sleepText != "Off") { panel = 5 })
                        add(
                            MenuEntry(R.drawable.ic_pip, "Picture in picture") {
                                panel = 0
                                val a = activity
                                if (a != null) {
                                    AppState.pipRequested = true
                                    enterPip(a, AppState.videoW, AppState.videoH)
                                }
                            }
                        )
                        add(
                            MenuEntry(R.drawable.ic_lock, "Touch lock") {
                                panel = 0
                                locked = true
                                controlsVisible = false
                                showToast("Touch locked", R.drawable.ic_lock)
                            }
                        )
                        add(MenuEntry(R.drawable.ic_info, "Video info") { panel = 6 })
                        add(
                            MenuEntry(R.drawable.ic_share, "Share") {
                                panel = 0
                                runCatching {
                                    val send = Intent(Intent.ACTION_SEND)
                                    if (net) {
                                        send.type = "text/plain"
                                        send.putExtra(Intent.EXTRA_TEXT, list[idx].uri.toString())
                                    } else {
                                        send.type = "video/*"
                                        send.putExtra(Intent.EXTRA_STREAM, list[idx].uri)
                                        send.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
                                    }
                                    ctx.startActivity(Intent.createChooser(send, "Share").addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
                                }
                            }
                        )
                        add(MenuEntry(0, "", divider = true) { })
                        if (!net) {
                            add(MenuEntry(R.drawable.ic_edit, "Rename, delete, hide, private") { panel = 14 })
                        }
                        add(MenuEntry(R.drawable.ic_reels, "Open in Reels player") { panel = 0; openInReels() })
                    }
                    MovieMenu(entries) { panel = 0 }
                }

                // Speed panel
                if (panel == 3) {
                    SpeedPanel(speed, { speed = it }, { panel = 0 })
                }

                // Panels (audio / subtitles)
                if (panel == 1 || panel == 2) {
                    val audioGroups = tracks.groups.filter { it.type == C.TRACK_TYPE_AUDIO }
                    val textGroups = tracks.groups.filter { it.type == C.TRACK_TYPE_TEXT }
                    val textDisabled = exo.trackSelectionParameters.disabledTrackTypes.contains(C.TRACK_TYPE_TEXT)

                    val items: List<PanelItem> = if (panel == 1) {
                        val l = buildList {
                            audioGroups.forEach { g ->
                                for (i in 0 until g.length) {
                                    val ok = g.isTrackSupported(i)
                                    val label = trackLabel(g.getTrackFormat(i), i, "Audio") +
                                        (if (ok) "" else "  (not supported on this device)")
                                    add(PanelItem(label, g.isTrackSelected(i)) {
                                        if (ok) selectTrack(g, i) else showToast("This audio track isn't supported on this device")
                                        panel = 0
                                    })
                                }
                            }
                        }
                        if (l.isEmpty()) listOf(PanelItem("No other audio tracks available", false) { }) else l
                    } else if (panel == 2) {
                        buildList {
                            if (extCues.isNotEmpty()) {
                                add(PanelItem("File: $extName", extOn) {
                                    extOn = true
                                    exo.trackSelectionParameters = exo.trackSelectionParameters.buildUpon()
                                        .setTrackTypeDisabled(C.TRACK_TYPE_TEXT, true)
                                        .build()
                                    panel = 0
                                })
                            }
                            add(PanelItem("Off", (extCues.isEmpty() || !extOn) && (textDisabled || textGroups.none { it.isSelected })) {
                                extOn = false
                                disableSubs()
                                panel = 0
                            })
                            textGroups.forEach { g ->
                                for (i in 0 until g.length) {
                                    add(PanelItem(trackLabel(g.getTrackFormat(i), i, "Subtitle"), !textDisabled && g.isTrackSelected(i)) {
                                        selectTrack(g, i)
                                        panel = 0
                                    })
                                }
                            }
                            add(PanelItem("+ Add subtitle file (.srt .vtt .ass)", false) {
                                panel = 0
                                pickSub.launch(arrayOf("*/*"))
                            })
                            add(PanelItem("Subtitle delay: ${"%+.1f".format(subDelayMs / 1000f)} s", false) { panel = 7 })
                            add(PanelItem("Subtitle style (size, color, background, position)", false) { panel = 11 })
                        }
                    } else {
                        speedOptions.map { sp ->
                            PanelItem(if (sp == 1f) "Normal (1x)" else "${sp}x", sp == speed) {
                                speed = sp
                                panel = 0
                            }
                        }
                    }
                    val title = if (panel == 1) "Audio track" else if (panel == 2) "Subtitles" else "Playback speed"
                    Panel(title, items) { panel = 0 }
                }
            }

            if (!pip && zoom > 1.01f) {
                Box(
                    Modifier.align(Alignment.TopCenter).padding(top = SpeedBadgeTop + 44.dp)
                        .background(Color.Black.copy(alpha = 0.55f), RoundedCornerShape(20.dp))
                        .clickable { resetZoom() }
                        .padding(horizontal = 14.dp, vertical = 6.dp)
                ) {
                    Text("Zoom ${(zoom * 100).roundToInt()}%  •  tap to reset", color = Color.White, fontSize = 12.sp)
                }
            }
            if (!pip && buffering) {
                CircularProgressIndicator(
                    color = Accent, strokeWidth = 3.dp,
                    modifier = Modifier.align(Alignment.Center).size(44.dp)
                )
            }

            // On-screen feedback
            val t = toast
            if (t != null) {
                Row(
                    Modifier.align(Alignment.Center)
                        .background(Color.Black.copy(alpha = 0.6f), RoundedCornerShape(14.dp))
                        .padding(horizontal = 18.dp, vertical = 10.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    if (toastIcon != 0) {
                        Ic(toastIcon, 22.dp)
                        Spacer(Modifier.width(8.dp))
                    }
                    Text(t, color = Color.White, fontSize = 16.sp, fontWeight = FontWeight.Medium)
                }
            }
            val sp = seekPreview
            if (sp != null) {
                Box(
                    Modifier.align(Alignment.Center)
                        .background(Color.Black.copy(alpha = 0.6f), RoundedCornerShape(14.dp))
                        .padding(horizontal = 22.dp, vertical = 12.dp)
                ) {
                    Text(sp, color = Color.White, fontSize = 24.sp, fontWeight = FontWeight.Bold)
                }
            }
            if (fast) {
                SpeedBadge(holdSpeed, Modifier.align(Alignment.TopCenter).padding(top = SpeedBadgeTop))
            }
        }
    }
}


// ---------- Speed control ----------

fun fmtSpeed(s: Float): String = "%.2f".format(s).trimEnd('0').trimEnd('.') + "x"

const val SPEED_STEP = 0.1f
fun roundSpeed(v: Float): Float = ((v / SPEED_STEP).roundToInt() * SPEED_STEP).coerceIn(0.25f, 4f)

val speedPresetsPortrait = listOf(0.5f, 1f, 2f, 3f)
val speedPresetsLandscape = listOf(0.25f, 0.5f, 0.75f, 1f, 1.5f, 2f, 2.5f, 3f, 4f)

/** Same distance from the top in Reels and in the Movie player. */
val SpeedBadgeTop = 88.dp

@Composable
fun ToggleCircle(res: Int, on: Boolean, onClick: () -> Unit, modifier: Modifier = Modifier, size: Dp = 40.dp) {
    Box(
        modifier.size(size).clip(CircleShape)
            .background(if (on) Accent else Color.Black.copy(alpha = 0.35f))
            .clickable(onClick = onClick),
        contentAlignment = Alignment.Center
    ) {
        Ic(res, 22.dp, Color.White)
    }
}

/** < / > button. Tap = one step, press and hold = keeps stepping. */
@Composable
fun SpeedArrow(left: Boolean, onStep: () -> Unit) {
    val step by rememberUpdatedState(onStep)
    Box(
        Modifier.size(44.dp).clip(CircleShape).background(Color.White.copy(alpha = 0.1f))
            .pointerInput(Unit) {
                detectTapGestures(onPress = {
                    step()
                    val released = withTimeoutOrNull(380L) { tryAwaitRelease() }
                    if (released == null) {
                        coroutineScope {
                            val j = launch {
                                while (true) {
                                    delay(70L)
                                    step()
                                }
                            }
                            tryAwaitRelease()
                            j.cancel()
                        }
                    }
                })
            },
        contentAlignment = Alignment.Center
    ) {
        Ic(R.drawable.ic_chevron, 26.dp, Color.White, Modifier.rotate(if (left) 180f else 0f))
    }
}

@Composable
fun SpeedPanel(speed: Float, onSpeed: (Float) -> Unit, onDismiss: () -> Unit) {
    val cur by rememberUpdatedState(speed)
    val land = LocalConfiguration.current.orientation == android.content.res.Configuration.ORIENTATION_LANDSCAPE
    val presets = if (land) speedPresetsLandscape else speedPresetsPortrait
    Box(
        Modifier.fillMaxSize().background(Color.Black.copy(alpha = 0.5f)).clickable(onClick = onDismiss),
        contentAlignment = Alignment.Center
    ) {
        Column(
            Modifier.widthIn(max = if (land) 560.dp else 360.dp)
                .fillMaxWidth(if (land) 0.75f else 0.88f)
                .clip(RoundedCornerShape(22.dp)).background(Color(0xFF1C1C22))
                .clickable(onClick = { })
                .padding(horizontal = 16.dp, vertical = if (land) 12.dp else 16.dp)
        ) {
            Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                SpeedArrow(left = true) { onSpeed(roundSpeed(cur - SPEED_STEP)) }
                Text(
                    fmtSpeed(speed),
                    color = Accent, fontSize = 32.sp, fontWeight = FontWeight.Bold,
                    textAlign = TextAlign.Center,
                    modifier = Modifier.weight(1f)
                )
                SpeedArrow(left = false) { onSpeed(roundSpeed(cur + SPEED_STEP)) }
            }
            Slider(
                value = speed,
                onValueChange = { onSpeed(roundSpeed(it)) },
                valueRange = 0.25f..4f,
                modifier = Modifier.fillMaxWidth().padding(top = 2.dp),
                colors = SliderDefaults.colors(
                    thumbColor = Accent,
                    activeTrackColor = Accent,
                    inactiveTrackColor = Color.White.copy(alpha = 0.2f)
                )
            )
            Row(
                Modifier.fillMaxWidth().padding(top = 4.dp),
                horizontalArrangement = Arrangement.spacedBy(if (land) 6.dp else 8.dp)
            ) {
                presets.forEach { p ->
                    val active = abs(p - speed) < 0.001f
                    Box(
                        Modifier.weight(1f).clip(RoundedCornerShape(10.dp))
                            .background(if (active) Accent else Color.White.copy(alpha = 0.08f))
                            .clickable { onSpeed(p) }
                            .padding(vertical = 10.dp),
                        contentAlignment = Alignment.Center
                    ) {
                        Text(
                            fmtSpeed(p), color = Color.White,
                            fontSize = if (land) 12.sp else 13.sp,
                            fontWeight = if (active) FontWeight.Bold else FontWeight.Normal,
                            maxLines = 1
                        )
                    }
                }
            }
        }
    }
}

// ---------- Small dialogs ----------

@Composable
fun ChoiceDialog(title: String, options: List<String>, selected: Int, onPick: (Int) -> Unit, onDismiss: () -> Unit) {
    Box(
        Modifier.fillMaxSize().background(Color.Black.copy(alpha = 0.5f)).clickable(onClick = onDismiss),
        contentAlignment = Alignment.Center
    ) {
        Column(
            Modifier.widthIn(max = 320.dp).fillMaxWidth(0.8f).heightIn(max = 320.dp)
                .clip(RoundedCornerShape(20.dp)).background(Color(0xFF1C1C22))
                .clickable(onClick = { })
                .verticalScroll(rememberScrollState())
                .padding(vertical = 8.dp)
        ) {
            Text(title, color = Color.White, fontSize = 16.sp, fontWeight = FontWeight.SemiBold,
                modifier = Modifier.padding(horizontal = 20.dp, vertical = 10.dp))
            options.forEachIndexed { i, o ->
                Row(
                    Modifier.fillMaxWidth().clickable { onPick(i) }.padding(horizontal = 20.dp, vertical = 13.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(o, color = if (i == selected) Accent else Color.White, fontSize = 14.sp, modifier = Modifier.weight(1f))
                    if (i == selected) Ic(R.drawable.ic_check, 18.dp, Accent)
                }
            }
        }
    }
}

@Composable
fun InfoDialog(title: String, rows: List<Pair<String, String>>, onDismiss: () -> Unit) {
    Box(
        Modifier.fillMaxSize().background(Color.Black.copy(alpha = 0.5f)).clickable(onClick = onDismiss),
        contentAlignment = Alignment.Center
    ) {
        Column(
            Modifier.widthIn(max = 420.dp).fillMaxWidth(0.88f).heightIn(max = 320.dp)
                .clip(RoundedCornerShape(20.dp)).background(Color(0xFF1C1C22))
                .clickable(onClick = { })
                .verticalScroll(rememberScrollState())
                .padding(horizontal = 20.dp, vertical = 16.dp)
        ) {
            Text(title, color = Color.White, fontSize = 16.sp, fontWeight = FontWeight.SemiBold)
            rows.forEach { (k, v) ->
                Column(Modifier.padding(top = 10.dp)) {
                    Text(k, color = Color.White.copy(alpha = 0.55f), fontSize = 12.sp)
                    Text(v, color = Color.White, fontSize = 14.sp)
                }
            }
        }
    }
}

// ---------- 3-dot menu ----------

@Composable
fun MenuItemRow(res: Int, label: String, value: String? = null, on: Boolean = false, onClick: () -> Unit) {
    Row(
        Modifier.fillMaxWidth().clickable(onClick = onClick).padding(horizontal = 16.dp, vertical = 13.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Ic(res, 20.dp, if (on) Accent else Color.White)
        Spacer(Modifier.width(14.dp))
        Text(label, color = Color.White, fontSize = 14.sp, modifier = Modifier.weight(1f))
        if (value != null) {
            Spacer(Modifier.width(12.dp))
            Text(value, color = if (on) Accent else Color.White.copy(alpha = 0.6f), fontSize = 13.sp, fontWeight = FontWeight.Medium)
        }
    }
}

class MenuEntry(
    val icon: Int,
    val label: String,
    val value: String? = null,
    val on: Boolean = false,
    val divider: Boolean = false,
    val onClick: () -> Unit
)

@Composable
fun MovieMenu(entries: List<MenuEntry>, onDismiss: () -> Unit) {
    val land = LocalConfiguration.current.orientation == android.content.res.Configuration.ORIENTATION_LANDSCAPE
    Box(Modifier.fillMaxSize().clickable(onClick = onDismiss)) {
        Column(
            Modifier.align(Alignment.TopEnd).padding(top = 64.dp, end = 14.dp)
                .widthIn(min = 250.dp, max = 310.dp)
                .heightIn(max = if (land) 250.dp else 480.dp)
                .clip(RoundedCornerShape(16.dp)).background(Color(0xFF1C1C22))
                .clickable(onClick = { })
                .verticalScroll(rememberScrollState())
                .padding(vertical = 6.dp)
        ) {
            entries.forEach { e ->
                if (e.divider) {
                    Box(Modifier.fillMaxWidth().height(1.dp).background(Color.White.copy(alpha = 0.08f)))
                } else {
                    MenuItemRow(e.icon, e.label, e.value, e.on, e.onClick)
                }
            }
        }
    }
}


// ---------- Telegram-style hold + slide speed ----------

fun snapSpeed(v: Float): Float = (((v * 4f).roundToInt()) / 4f).coerceIn(0.25f, 4f)

/**
 * Hold anywhere = 2x. While holding, slide right to go faster (up to 4x) or left to go slower (down to 0.5x).
 * Releasing calls [onEnd]. Quick taps and swipes are left alone.
 */
suspend fun PointerInputScope.holdSlideSpeed(
    canStart: () -> Boolean,
    onSpeed: (Float) -> Unit,
    onEnd: () -> Unit
) {
    awaitEachGesture {
        val down = awaitFirstDown(requireUnconsumed = false)
        val t0 = System.currentTimeMillis()
        val up = withTimeoutOrNull(350L) { waitForUpOrCancellation() }
        val elapsed = System.currentTimeMillis() - t0
        if (up == null && elapsed >= 330L && canStart()) {
            val w = size.width.toFloat().coerceAtLeast(1f)
            var sp = 2f
            onSpeed(sp)
            try {
                while (true) {
                    val event = awaitPointerEvent()
                    val ch = event.changes.firstOrNull { it.id == down.id } ?: break
                    if (!ch.pressed) {
                        ch.consume()
                        break
                    }
                    val ns = snapSpeed(2f + (ch.position.x - down.position.x) / w * 3f).coerceIn(0.5f, 4f)
                    if (ns != sp) {
                        sp = ns
                        onSpeed(sp)
                    }
                    ch.consume()
                }
            } finally {
                onEnd()
            }
        }
    }
}

@Composable
fun SpeedBadge(speed: Float, modifier: Modifier = Modifier) {
    Row(
        modifier.background(Color.Black.copy(alpha = 0.55f), RoundedCornerShape(20.dp))
            .padding(horizontal = 14.dp, vertical = 6.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Ic(R.drawable.ic_fast_forward, 18.dp, Color.White)
        Spacer(Modifier.width(6.dp))
        Text(fmtSpeed(speed), color = Color.White, fontSize = 14.sp, fontWeight = FontWeight.Bold)
    }
}
