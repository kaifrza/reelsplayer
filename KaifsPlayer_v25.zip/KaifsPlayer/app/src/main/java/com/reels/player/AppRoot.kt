package com.reels.player

import android.Manifest
import android.content.Context
import android.content.pm.PackageManager
import android.os.Build
import android.widget.Toast
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.foundation.background
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.TextButton
import androidx.compose.material3.Text
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.key
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalClipboardManager
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.ContextCompat
import androidx.core.view.WindowInsetsCompat
import androidx.core.view.WindowInsetsControllerCompat
import java.io.File
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.withContext

@Composable
fun AppRoot() {
    val dark = when (AppSettings.theme) {
        1 -> false
        2 -> true
        else -> isSystemInDarkTheme()
    }
    MaterialTheme(
        colorScheme = if (dark) darkColorScheme(primary = Accent) else lightColorScheme(primary = Accent)
    ) {
        CompositionLocalProvider(LocalDark provides dark) {
            App()
        }
    }
}

fun audioPermission(): String =
    if (Build.VERSION.SDK_INT >= 33) Manifest.permission.READ_MEDIA_AUDIO
    else Manifest.permission.READ_EXTERNAL_STORAGE

fun hasAudioPermission(ctx: Context): Boolean =
    ContextCompat.checkSelfPermission(ctx, audioPermission()) == PackageManager.PERMISSION_GRANTED

@Composable
fun App() {
    val ctx = LocalContext.current
    val perm = if (Build.VERSION.SDK_INT >= 33)
        Manifest.permission.READ_MEDIA_VIDEO else Manifest.permission.READ_EXTERNAL_STORAGE

    var granted by remember {
        mutableStateOf(ContextCompat.checkSelfPermission(ctx, perm) == PackageManager.PERMISSION_GRANTED)
    }
    val launcher = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) {
        granted = it
    }
    var videos by remember { mutableStateOf<List<Video>?>(null) }
    var splash by remember { mutableStateOf(true) }
    var crashText by remember { mutableStateOf(CrashReporter.read(ctx)) }
    val clipboard = LocalClipboardManager.current

    LaunchedEffect(Unit) { if (!granted) launcher.launch(perm) }
    LaunchedEffect(granted, AppState.libraryTick) {
        if (granted) videos = withContext(Dispatchers.IO) { loadVideos(ctx) }
    }
    val visibleVideos = remember(videos, AppSettings.hiddenFolders) {
        videos?.filter { it.folder !in AppSettings.hiddenFolders }
    }
    LaunchedEffect(Unit) {
        delay(1600)
        splash = false
    }

    Box(Modifier.fillMaxSize().background(Bg), contentAlignment = Alignment.Center) {
        val list = visibleVideos
        if (!granted) {
            CenterMessage(
                R.drawable.ic_video, "KaifsPlayer",
                "KaifsPlayer needs access to your videos and music to get started.",
                "Grant permission"
            ) { launcher.launch(perm) }
        } else if (list == null) {
            Text("Loading...", color = Fg.copy(alpha = 0.7f))
        } else {
            Main(list)
        }
        val crash = crashText
        if (crash != null && !splash) {
            AlertDialog(
                onDismissRequest = { },
                title = { Text("KaifsPlayer closed unexpectedly") },
                text = {
                    Column {
                        Text(
                            "Tap Copy and send this report to the developer so it can be fixed.",
                            fontSize = 13.sp
                        )
                        Box(
                            Modifier.padding(top = 10.dp).heightIn(max = 260.dp)
                                .verticalScroll(rememberScrollState())
                        ) {
                            Text(crash, fontSize = 10.sp, fontFamily = FontFamily.Monospace)
                        }
                    }
                },
                confirmButton = {
                    TextButton(onClick = {
                        clipboard.setText(AnnotatedString(crash))
                        Toast.makeText(ctx, "Report copied", Toast.LENGTH_SHORT).show()
                    }) { Text("Copy", color = Accent) }
                },
                dismissButton = {
                    TextButton(onClick = {
                        CrashReporter.clear(ctx)
                        crashText = null
                    }) { Text("Dismiss", color = Fg) }
                },
                containerColor = CardBg,
                titleContentColor = Fg,
                textContentColor = Fg.copy(alpha = 0.8f)
            )
        }
        AnimatedVisibility(
            visible = splash,
            modifier = Modifier.fillMaxSize(),
            enter = fadeIn(),
            exit = fadeOut(tween(450))
        ) {
            SplashScreen()
        }
    }
}

@Composable
fun Main(all: List<Video>) {
    val ctx = LocalContext.current
    val dark = LocalDark.current
    val roots = remember { storageRoots(ctx) }
    val fs = remember { FsState(roots.first().path) }
    var screen by remember { mutableStateOf<Screen>(Screen.Home) }
    var mode by remember { mutableIntStateOf(0) }
    var folder by remember { mutableStateOf<String?>(null) }
    var sort by remember { mutableIntStateOf(0) }
    var showNowPlaying by remember { mutableStateOf(false) }
    var songs by remember { mutableStateOf<List<Song>?>(null) }
    var audioGranted by remember { mutableStateOf(hasAudioPermission(ctx)) }
    var askedNotif by remember { mutableStateOf(false) }
    var showStream by remember { mutableStateOf(false) }
    val audioLauncher = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) {
        audioGranted = it
    }
    val notifLauncher = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { }

    LaunchedEffect(Unit) { MusicHub.init(ctx) }
    LaunchedEffect(Unit) {
        while (true) {
            MusicHub.tick()
            delay(500)
        }
    }
    LaunchedEffect(audioGranted, AppSettings.musicAll) {
        if (audioGranted) songs = withContext(Dispatchers.IO) { loadSongs(ctx, AppSettings.musicAll) }
    }
    LaunchedEffect(MusicHub.isPlaying) {
        if (MusicHub.isPlaying && !askedNotif && Build.VERSION.SDK_INT >= 33 &&
            ContextCompat.checkSelfPermission(ctx, Manifest.permission.POST_NOTIFICATIONS)
            != PackageManager.PERMISSION_GRANTED
        ) {
            askedNotif = true
            notifLauncher.launch(Manifest.permission.POST_NOTIFICATIONS)
        }
    }

    val s = screen
    val immersive = s is Screen.Reels || s is Screen.Movie
    val act = remember { ctx.findActivity() }
    LaunchedEffect(immersive, dark) {
        val w = act?.window
        if (w != null) {
            val c = WindowInsetsControllerCompat(w, w.decorView)
            if (immersive) {
                c.systemBarsBehavior = WindowInsetsControllerCompat.BEHAVIOR_SHOW_TRANSIENT_BARS_BY_SWIPE
                c.hide(WindowInsetsCompat.Type.systemBars())
            } else {
                c.show(WindowInsetsCompat.Type.systemBars())
                c.isAppearanceLightStatusBars = !dark
                c.isAppearanceLightNavigationBars = !dark
            }
        }
    }
    LaunchedEffect(immersive) { if (immersive) MusicHub.pause() }
    LaunchedEffect(AppState.nowPlayingRequest) {
        if (AppState.nowPlayingRequest > 0) {
            if (immersive) screen = Screen.Home
            showNowPlaying = true
        }
    }

    fun home() {
        screen = Screen.Home
    }

    fun browseBack() {
        if (mode == 0) {
            val p = fs.path
            if (p == null) {
                home()
            } else if (roots.any { it.path == p }) {
                if (roots.size > 1) fs.path = null else home()
            } else {
                fs.path = File(p).parent
            }
        } else if (mode == 1) {
            if (folder != null) folder = null else home()
        } else {
            home()
        }
    }

    fun startMusic(list: List<Song>, idx: Int, shuffle: Boolean = false) {
        MusicHub.playSongs(list, idx, shuffle)
        showNowPlaying = true
    }

    fun openMovie(v: Video, back: Screen) {
        val sib = siblingsOf(v, all)
        screen = Screen.Movie(sib, sib.indexOfFirst { it.uri == v.uri }.coerceAtLeast(0), back)
    }

    fun openReelsGrid() {
        if (all.isEmpty()) {
            Toast.makeText(ctx, "No videos found", Toast.LENGTH_SHORT).show()
        } else {
            screen = Screen.ReelsGrid(all, lastIndex(ctx, all))
        }
    }

    BackHandler(enabled = s is Screen.MusicTab || s is Screen.SettingsTab || s is Screen.ReelsGrid) { home() }

    if (immersive) {
        CompositionLocalProvider(LocalDark provides true) {
            if (s is Screen.Reels) {
                key(s) {
                    ReelsScreen(
                        videos = s.list,
                        startIndex = s.start,
                        rememberLast = (s.list === all),
                        onBrowse = { screen = Screen.Browse },
                        onBack = { idx -> screen = if (s.fromBrowse) Screen.Browse else Screen.ReelsGrid(s.list, idx) },
                        onMovie = { v, page -> openMovie(v, Screen.Reels(s.list, page, s.fromBrowse)) }
                    )
                }
            } else if (s is Screen.Movie) {
                key(s) {
                    MovieScreen(
                        list = s.list,
                        startIndex = s.index,
                        onExit = { last ->
                            val b = s.back
                            screen = if (b is Screen.Reels) {
                                val i = b.list.indexOfFirst { it.uri == last.uri }
                                b.copy(start = if (i >= 0) i else b.start)
                            } else {
                                b
                            }
                        },
                        onOpenReels = { cur ->
                            val i = all.indexOfFirst { it.uri == cur.uri }
                            screen = if (i >= 0) Screen.Reels(all, i, false)
                            else Screen.Reels(s.list, s.list.indexOfFirst { it.uri == cur.uri }.coerceAtLeast(0), false)
                        }
                    )
                }
            }
        }
    } else {
        val navIdx = when (s) {
            is Screen.Home -> 0
            is Screen.Browse -> 2
            is Screen.ReelsGrid -> 1
            is Screen.MusicTab -> 3
            is Screen.SettingsTab -> 4
            else -> 0
        }
        Box(Modifier.fillMaxSize()) {
            Column(Modifier.fillMaxSize().background(Bg)) {
                Box(Modifier.weight(1f).fillMaxWidth()) {
                    if (s is Screen.Home) {
                        HomeScreen(
                            all = all,
                            songs = songs,
                            onReels = { list, idx -> screen = Screen.Reels(list, idx, false) },
                            onBrowse = { m ->
                                mode = m
                                folder = null
                                screen = Screen.Browse
                            },
                            onMovie = { v -> openMovie(v, Screen.Home) },
                            onFolder = { f ->
                                mode = 1
                                folder = f
                                screen = Screen.Browse
                            },
                            onPlaySongs = { list, idx -> startMusic(list, idx) },
                            onMusicTab = { screen = Screen.MusicTab },
                            onStream = { showStream = true }
                        )
                    } else if (s is Screen.Browse) {
                        BackHandler { browseBack() }
                        if (mode == 0) {
                            FilesScreen(
                                fs = fs,
                                roots = roots,
                                onMode = { mode = it },
                                onPlay = { list, idx -> openMovie(list[idx], Screen.Browse) },
                                onMusic = { list, idx -> startMusic(list, idx) },
                                onBack = { browseBack() }
                            )
                        } else if (mode == 1) {
                            GalleryScreen(
                                all = all,
                                folder = folder,
                                sort = sort,
                                onFolder = { folder = it },
                                onSort = { sort = it },
                                onMode = { mode = it },
                                onPlay = { list, idx -> openMovie(list[idx], Screen.Browse) },
                                onBack = { browseBack() }
                            )
                        } else if (mode == 3) {
                            PrivateScreen(
                                onMode = { mode = it },
                                onPlay = { list, idx -> openMovie(list[idx], Screen.Browse) }
                            )
                        } else {
                            ContinueScreen(
                                onMode = { mode = it },
                                onOpen = { v -> openMovie(v, Screen.Browse) },
                                onBack = { browseBack() }
                            )
                        }
                    } else if (s is Screen.ReelsGrid) {
                        ReelsGridScreen(
                            list = s.list,
                            focus = s.focus,
                            onOpen = { idx -> screen = Screen.Reels(s.list, idx, false) },
                            onBack = { home() }
                        )
                    } else if (s is Screen.MusicTab) {
                        LaunchedEffect(Unit) {
                            if (!audioGranted) audioLauncher.launch(audioPermission())
                        }
                        MusicScreen(
                            songs = songs,
                            granted = audioGranted,
                            onGrant = { audioLauncher.launch(audioPermission()) },
                            onOpenFiles = {
                                mode = 0
                                screen = Screen.Browse
                            },
                            onPlay = { list, idx, shuffle -> startMusic(list, idx, shuffle) }
                        )
                    } else if (s is Screen.SettingsTab) {
                        SettingsScreen()
                    }
                }
                if (MusicHub.current != null && !showNowPlaying) {
                    MiniPlayer(onOpen = { showNowPlaying = true })
                }
                NavBar(navIdx) { i ->
                    if (i == 0) {
                        screen = Screen.Home
                    } else if (i == 1) {
                        openReelsGrid()
                    } else if (i == 2) {
                        screen = Screen.Browse
                    } else if (i == 3) {
                        screen = Screen.MusicTab
                    } else {
                        screen = Screen.SettingsTab
                    }
                }
            }
            if (showNowPlaying) {
                NowPlayingScreen(onClose = { showNowPlaying = false })
            }
            if (showStream) {
                StreamDialog(
                    onPlay = { url ->
                        showStream = false
                        screen = Screen.Movie(listOf(streamVideo(url)), 0, Screen.Home)
                    },
                    onDismiss = { showStream = false }
                )
            }
        }
    }
}
