@file:OptIn(
    androidx.media3.common.util.UnstableApi::class,
    androidx.compose.foundation.ExperimentalFoundationApi::class,
    androidx.compose.material3.ExperimentalMaterial3Api::class
)

package com.reels.player

import android.Manifest
import android.app.Activity
import android.content.Context
import android.content.pm.PackageManager
import android.media.MediaScannerConnection
import android.net.Uri
import android.os.Build
import android.os.Environment
import android.os.Handler
import android.os.Looper
import android.widget.Toast
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.combinedClickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.itemsIndexed
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableLongStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.platform.LocalClipboardManager
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.ContextCompat
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.io.File
import java.security.MessageDigest
import java.security.SecureRandom

// =====================================================================
// File operations: rename / delete / private folder
// =====================================================================

fun hasWriteAccess(ctx: Context): Boolean =
    if (Build.VERSION.SDK_INT >= 30) Environment.isExternalStorageManager()
    else ContextCompat.checkSelfPermission(ctx, Manifest.permission.WRITE_EXTERNAL_STORAGE) ==
        PackageManager.PERMISSION_GRANTED

fun scanPaths(ctx: Context, paths: List<String>) {
    runCatching {
        MediaScannerConnection.scanFile(ctx.applicationContext, paths.toTypedArray(), null) { _, _ ->
            Handler(Looper.getMainLooper()).post { AppState.libraryTick++ }
        }
    }
}

fun isNetworkVideo(v: Video): Boolean {
    val s = v.uri.scheme
    return s == "http" || s == "https"
}

fun renameVideo(ctx: Context, v: Video, newBase: String): String? {
    val path = videoPath(ctx, v) ?: return "Can't find this file"
    val src = File(path)
    if (!src.exists()) return "File not found"
    val clean = newBase.replace(Regex("[\\\\/:*?\"<>|]"), "").trim()
    if (clean.isEmpty()) return "Enter a name"
    val ext = src.extension
    val dst = File(src.parentFile, if (ext.isEmpty()) clean else "$clean.$ext")
    if (dst.exists()) return "A file with that name already exists"
    if (!src.renameTo(dst)) return "Rename failed. Check the file access permission."
    scanPaths(ctx, listOf(src.absolutePath, dst.absolutePath))
    return null
}

fun deleteVideo(ctx: Context, v: Video): String? {
    val path = videoPath(ctx, v) ?: return "Can't find this file"
    val f = File(path)
    if (f.exists() && !f.delete()) return "Delete failed. Check the file access permission."
    runCatching { if (v.uri.scheme == "content") ctx.contentResolver.delete(v.uri, null, null) }
    scanPaths(ctx, listOf(path))
    return null
}

fun vaultDir(): File {
    val d = File(Environment.getExternalStorageDirectory(), ".KaifsPrivate")
    if (!d.exists()) d.mkdirs()
    val n = File(d, ".nomedia")
    if (d.exists() && !n.exists()) runCatching { n.createNewFile() }
    return d
}

fun listVault(): List<Video> {
    val files = vaultDir().listFiles() ?: return emptyList()
    return files.filter { it.isFile && isVideoFile(it) }
        .sortedByDescending { it.lastModified() }
        .map { f ->
            readDuration(f.absolutePath)
            fileVideo(f)
        }
}

fun uniqueFile(dir: File, name: String): File {
    var f = File(dir, name)
    if (!f.exists()) return f
    val base = name.substringBeforeLast('.', name)
    val ext = name.substringAfterLast('.', "")
    var i = 1
    while (f.exists()) {
        f = File(dir, if (ext.isEmpty()) "$base ($i)" else "$base ($i).$ext")
        i++
    }
    return f
}

fun moveFile(src: File, dst: File): Boolean {
    if (src.renameTo(dst)) return true
    return try {
        src.inputStream().use { i -> dst.outputStream().use { o -> i.copyTo(o) } }
        if (dst.length() == src.length()) {
            src.delete()
            true
        } else {
            dst.delete()
            false
        }
    } catch (e: Exception) {
        runCatching { dst.delete() }
        false
    }
}

private fun vaultPrefs(ctx: Context) = ctx.getSharedPreferences("vault", Context.MODE_PRIVATE)

fun moveToPrivate(ctx: Context, v: Video): String? {
    val path = videoPath(ctx, v) ?: return "Can't find this file"
    val src = File(path)
    if (!src.exists()) return "File not found"
    val dir = vaultDir()
    if (!dir.exists()) return "Can't create the private folder. Check the file access permission."
    val dst = uniqueFile(dir, src.name)
    if (!moveFile(src, dst)) return "Move failed. Check the file access permission."
    vaultPrefs(ctx).edit().putString("orig_" + dst.name, src.absolutePath).apply()
    runCatching { if (v.uri.scheme == "content") ctx.contentResolver.delete(v.uri, null, null) }
    scanPaths(ctx, listOf(src.absolutePath))
    return null
}

fun restoreFromPrivate(ctx: Context, f: File): String? {
    val orig = vaultPrefs(ctx).getString("orig_" + f.name, null)
    val origDir: File? = if (orig != null) File(orig).parentFile else null
    val target: File = if (origDir != null && (origDir.exists() || origDir.mkdirs())) {
        origDir
    } else {
        val m = Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_MOVIES)
        m.mkdirs()
        m
    }
    val dst = uniqueFile(target, f.name)
    if (!moveFile(f, dst)) return "Restore failed"
    vaultPrefs(ctx).edit().remove("orig_" + f.name).apply()
    scanPaths(ctx, listOf(dst.absolutePath))
    return null
}

fun deleteVaultFile(f: File): Boolean = f.delete()

// =====================================================================
// PIN + fingerprint
// =====================================================================

object PrivateVault {
    var unlocked by mutableStateOfBool(false)

    private fun p(ctx: Context) = ctx.getSharedPreferences("vault", Context.MODE_PRIVATE)

    fun hasPin(ctx: Context): Boolean = p(ctx).getString("hash", null) != null

    private fun hash(salt: String, pin: String): String {
        val md = MessageDigest.getInstance("SHA-256")
        return md.digest((salt + pin).toByteArray()).joinToString("") { "%02x".format(it) }
    }

    fun setPin(ctx: Context, pin: String) {
        val bytes = ByteArray(16)
        SecureRandom().nextBytes(bytes)
        val salt = bytes.joinToString("") { "%02x".format(it) }
        p(ctx).edit().putString("salt", salt).putString("hash", hash(salt, pin)).apply()
    }

    fun check(ctx: Context, pin: String): Boolean {
        val salt = p(ctx).getString("salt", "") ?: ""
        return hash(salt, pin) == p(ctx).getString("hash", null)
    }
}

private fun mutableStateOfBool(v: Boolean) = androidx.compose.runtime.mutableStateOf(v)

fun hasBiometric(ctx: Context): Boolean =
    Build.VERSION.SDK_INT >= 28 && ctx.packageManager.hasSystemFeature(PackageManager.FEATURE_FINGERPRINT)

fun showBiometric(act: Activity, onOk: () -> Unit, onFail: (String) -> Unit) {
    if (Build.VERSION.SDK_INT < 28) {
        onFail("Not supported")
        return
    }
    try {
        val prompt = android.hardware.biometrics.BiometricPrompt.Builder(act)
            .setTitle("Unlock Private folder")
            .setNegativeButton(
                "Use PIN", act.mainExecutor,
                android.content.DialogInterface.OnClickListener { _, _ -> }
            )
            .build()
        prompt.authenticate(
            android.os.CancellationSignal(),
            act.mainExecutor,
            object : android.hardware.biometrics.BiometricPrompt.AuthenticationCallback() {
                override fun onAuthenticationSucceeded(result: android.hardware.biometrics.BiometricPrompt.AuthenticationResult?) {
                    onOk()
                }

                override fun onAuthenticationError(errorCode: Int, errString: CharSequence?) {
                    onFail(errString?.toString() ?: "")
                }
            }
        )
    } catch (e: Exception) {
        onFail("Fingerprint unavailable")
    }
}

@Composable
fun PinGate(forceCreate: Boolean, onUnlocked: () -> Unit) {
    val ctx = LocalContext.current
    val act = remember { ctx.findActivity() }
    var mode by remember(forceCreate) {
        mutableIntStateOf(if (!forceCreate && PrivateVault.hasPin(ctx)) 0 else 1)
    }
    var first by remember { mutableStateOf("") }
    var entry by remember { mutableStateOf("") }
    var msg by remember { mutableStateOf("") }
    var fails by remember { mutableIntStateOf(0) }
    var lockedUntil by remember { mutableLongStateOf(0L) }
    var forgot by remember { mutableStateOf(false) }
    val bio = remember { hasBiometric(ctx) }

    LaunchedEffect(mode, forceCreate) {
        if (mode == 0 && bio && act != null) {
            showBiometric(act, { onUnlocked() }, { })
        }
    }

    fun submit(e: String) {
        if (mode == 0) {
            if (System.currentTimeMillis() < lockedUntil) {
                msg = "Too many attempts. Try again in a moment."
                entry = ""
            } else if (PrivateVault.check(ctx, e)) {
                entry = ""
                onUnlocked()
            } else {
                fails++
                entry = ""
                msg = "Wrong PIN"
                if (fails >= 5) {
                    fails = 0
                    lockedUntil = System.currentTimeMillis() + 30_000L
                    msg = "Too many attempts. Try again in 30 seconds."
                }
            }
        } else if (mode == 1) {
            first = e
            entry = ""
            mode = 2
            msg = ""
        } else {
            if (e == first) {
                PrivateVault.setPin(ctx, e)
                entry = ""
                first = ""
                onUnlocked()
            } else {
                msg = "PINs did not match. Start again."
                entry = ""
                first = ""
                mode = 1
            }
        }
    }

    fun digit(d: String) {
        if (entry.length >= 4) return
        val e = entry + d
        entry = e
        if (e.length == 4) submit(e)
    }

    val title = when (mode) {
        0 -> "Enter PIN"
        1 -> "Create a 4-digit PIN"
        else -> "Confirm your PIN"
    }

    Column(
        Modifier.fillMaxSize().padding(24.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center
    ) {
        Ic(R.drawable.ic_lock, 40.dp, Accent)
        Text(title, color = Fg, fontSize = 20.sp, fontWeight = FontWeight.Bold, modifier = Modifier.padding(top = 10.dp))
        Row(Modifier.padding(top = 16.dp), horizontalArrangement = Arrangement.spacedBy(14.dp)) {
            for (i in 0 until 4) {
                Box(
                    Modifier.size(14.dp).clip(CircleShape)
                        .background(if (i < entry.length) Accent else Fg.copy(alpha = 0.2f))
                )
            }
        }
        Text(
            msg, color = Color(0xFFE5484D), fontSize = 13.sp, textAlign = TextAlign.Center,
            modifier = Modifier.padding(top = 10.dp).height(20.dp)
        )
        Spacer(Modifier.height(8.dp))
        val rows = listOf(listOf("1", "2", "3"), listOf("4", "5", "6"), listOf("7", "8", "9"))
        rows.forEach { r ->
            Row(Modifier.padding(vertical = 6.dp), horizontalArrangement = Arrangement.spacedBy(18.dp)) {
                r.forEach { d -> KeyButton(d) { digit(d) } }
            }
        }
        Row(Modifier.padding(vertical = 6.dp), horizontalArrangement = Arrangement.spacedBy(18.dp)) {
            if (bio && mode == 0 && act != null) {
                KeyButton("FP") { showBiometric(act, { onUnlocked() }, { }) }
            } else {
                Spacer(Modifier.size(68.dp))
            }
            KeyButton("0") { digit("0") }
            KeyButton("<") { if (entry.isNotEmpty()) entry = entry.dropLast(1) }
        }
        if (mode == 0) {
            Text(
                "Forgot PIN?", color = Accent, fontSize = 13.sp,
                modifier = Modifier.padding(top = 12.dp).clickable { forgot = true }.padding(8.dp)
            )
        }
    }
    if (forgot) {
        DialogFrame("Forgot PIN?", { forgot = false }) {
            Text(
                "Your private videos are stored in the hidden folder \".KaifsPrivate\" in your internal storage " +
                    "(show hidden files in a file manager to see it).\n\n" +
                    "To set a new PIN: Android Settings > Apps > KaifsPlayer > Storage > Clear data. " +
                    "Your private videos stay in that folder and show up again after you create a new PIN.",
                color = Color.White.copy(alpha = 0.8f), fontSize = 13.sp
            )
            Spacer(Modifier.height(12.dp))
            PillButton("OK", { forgot = false }, Modifier.fillMaxWidth())
        }
    }
}

@Composable
private fun KeyButton(label: String, onClick: () -> Unit) {
    Box(
        Modifier.size(68.dp).clip(CircleShape).background(CardBg).clickable(onClick = onClick),
        contentAlignment = Alignment.Center
    ) {
        if (label == "<") {
            Ic(R.drawable.ic_back, 24.dp, Fg)
        } else if (label == "FP") {
            Text("Touch", color = Accent, fontSize = 13.sp, fontWeight = FontWeight.Medium)
        } else {
            Text(label, color = Fg, fontSize = 24.sp, fontWeight = FontWeight.Medium)
        }
    }
}

// =====================================================================
// Private folder screen (Videos > Private)
// =====================================================================

@Composable
fun PrivateScreen(onMode: (Int) -> Unit, onPlay: (List<Video>, Int) -> Unit) {
    val ctx = LocalContext.current
    val unlocked = PrivateVault.unlocked
    var tick by remember { mutableIntStateOf(0) }
    var items by remember { mutableStateOf<List<Video>?>(null) }
    var selected by remember { mutableStateOf<Video?>(null) }
    var confirmDelete by remember { mutableStateOf<Video?>(null) }
    var changePin by remember { mutableStateOf(false) }

    LaunchedEffect(unlocked, tick) {
        if (unlocked) items = withContext(Dispatchers.IO) { listVault() }
    }

    Box(Modifier.fillMaxSize().background(Bg)) {
        Column(Modifier.fillMaxSize()) {
            BrowseHeader(
                "Private",
                if (!unlocked) "Locked" else "${items?.size ?: 0} videos",
                null
            ) {
                if (unlocked && !changePin) {
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        Chip(R.drawable.ic_settings, "PIN") { changePin = true }
                        Chip(R.drawable.ic_lock, "Lock") { PrivateVault.unlocked = false }
                    }
                }
            }
            ModeTabs(3, onMode)
            val list = items
            if (!unlocked || changePin) {
                PinGate(forceCreate = changePin) {
                    PrivateVault.unlocked = true
                    if (changePin) Toast.makeText(ctx, "PIN changed", Toast.LENGTH_SHORT).show()
                    changePin = false
                }
            } else if (list == null) {
                Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                    Text("Loading...", color = Fg.copy(alpha = 0.6f))
                }
            } else if (list.isEmpty()) {
                Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                    Text(
                        "No private videos yet.\nOpen a video's menu (or long-press it in Gallery) and choose \"Move to Private\".",
                        color = Fg.copy(alpha = 0.6f), textAlign = TextAlign.Center,
                        modifier = Modifier.padding(32.dp)
                    )
                }
            } else {
                LazyVerticalGrid(
                    columns = GridCells.Fixed(3),
                    contentPadding = PaddingValues(8.dp),
                    horizontalArrangement = Arrangement.spacedBy(6.dp),
                    verticalArrangement = Arrangement.spacedBy(6.dp),
                    modifier = Modifier.fillMaxSize()
                ) {
                    itemsIndexed(list, key = { _, v -> v.id }) { idx, v ->
                        Box(
                            Modifier.fillMaxWidth().aspectRatio(0.62f)
                                .clip(RoundedCornerShape(10.dp)).background(CardBg)
                                .combinedClickable(onClick = { onPlay(list, idx) }, onLongClick = { selected = v })
                        ) {
                            Thumb(v, 300, 480, Modifier.fillMaxSize())
                            Box(
                                Modifier.align(Alignment.BottomCenter).fillMaxWidth().height(70.dp).background(
                                    Brush.verticalGradient(listOf(Color.Transparent, Color.Black.copy(alpha = 0.8f)))
                                )
                            )
                            Text(
                                v.name.substringBeforeLast('.'), color = Color.White, fontSize = 11.sp,
                                maxLines = 2, overflow = TextOverflow.Ellipsis,
                                modifier = Modifier.align(Alignment.BottomStart).padding(6.dp)
                            )
                        }
                    }
                }
            }
        }

        val sel = selected
        if (sel != null) {
            DialogFrame(sel.name.substringBeforeLast('.'), { selected = null }) {
                ActionItem(R.drawable.ic_visibility_off, "Move out of Private") {
                    val f = File(sel.uri.path ?: "")
                    val err = restoreFromPrivate(ctx, f)
                    Toast.makeText(ctx, err ?: "Moved back to your library", Toast.LENGTH_SHORT).show()
                    selected = null
                    tick++
                }
                ActionItem(R.drawable.ic_delete, "Delete", danger = true) {
                    confirmDelete = sel
                    selected = null
                }
            }
        }
        val del = confirmDelete
        if (del != null) {
            DialogFrame("Delete this video?", { confirmDelete = null }) {
                Text(
                    "\"${del.name}\" will be deleted permanently. This can't be undone.",
                    color = Color.White.copy(alpha = 0.8f), fontSize = 13.sp
                )
                Spacer(Modifier.height(12.dp))
                Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                    PillButton("Cancel", { confirmDelete = null }, Modifier.weight(1f))
                    PillButton("Delete", {
                        deleteVaultFile(File(del.uri.path ?: ""))
                        confirmDelete = null
                        tick++
                    }, Modifier.weight(1f), primary = true)
                }
            }
        }
    }
}

@Composable
fun ActionItem(icon: Int, text: String, danger: Boolean = false, onClick: () -> Unit) {
    Row(
        Modifier.fillMaxWidth().clickable(onClick = onClick).padding(vertical = 13.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Ic(icon, 20.dp, if (danger) Color(0xFFFF6B6B) else Color.White)
        Spacer(Modifier.width(14.dp))
        Text(text, color = if (danger) Color(0xFFFF6B6B) else Color.White, fontSize = 15.sp)
    }
}

// =====================================================================
// Rename / delete / hide folder / move to private  (library + player)
// =====================================================================

/**
 * Overlay with the actions for one video. [onGone] is called after something that changes where the video lives
 * (rename, delete, hide folder, move to private) with a short message for the user.
 */
@Composable
fun VideoActionsHost(v: Video, onDismiss: () -> Unit, onGone: (String) -> Unit) {
    val ctx = LocalContext.current
    var step by remember { mutableIntStateOf(0) }
    var name by remember { mutableStateOf(v.name.substringBeforeLast('.')) }
    var error by remember { mutableStateOf("") }
    val writeLauncher = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { }

    fun blocked(): Boolean {
        if (hasWriteAccess(ctx)) return false
        Toast.makeText(ctx, "Allow file access first, then try again", Toast.LENGTH_LONG).show()
        if (Build.VERSION.SDK_INT >= 30) openAllFilesSettings(ctx)
        else writeLauncher.launch(Manifest.permission.WRITE_EXTERNAL_STORAGE)
        return true
    }

    when (step) {
        0 -> DialogFrame(v.name.substringBeforeLast('.'), onDismiss) {
            ActionItem(R.drawable.ic_edit, "Rename") { step = 1 }
            ActionItem(R.drawable.ic_lock, "Move to Private folder") { if (!blocked()) step = 4 }
            ActionItem(R.drawable.ic_visibility_off, "Hide folder \"${v.folder}\"") { step = 3 }
            ActionItem(R.drawable.ic_delete, "Delete", danger = true) { step = 2 }
        }
        1 -> DialogFrame("Rename video", onDismiss) {
            BasicTextField(
                value = name,
                onValueChange = { name = it },
                singleLine = true,
                textStyle = TextStyle(color = Color.White, fontSize = 15.sp),
                cursorBrush = SolidColor(Accent),
                modifier = Modifier.fillMaxWidth().clip(RoundedCornerShape(12.dp))
                    .background(Color.White.copy(alpha = 0.08f)).padding(horizontal = 14.dp, vertical = 12.dp)
            )
            if (error.isNotEmpty()) {
                Text(error, color = Color(0xFFFF6B6B), fontSize = 12.sp, modifier = Modifier.padding(top = 6.dp))
            }
            Spacer(Modifier.height(12.dp))
            Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                PillButton("Cancel", onDismiss, Modifier.weight(1f))
                PillButton("Rename", {
                    if (!blocked()) {
                        val err = renameVideo(ctx, v, name)
                        if (err == null) onGone("Renamed") else error = err
                    }
                }, Modifier.weight(1f), primary = true)
            }
        }
        2 -> DialogFrame("Delete this video?", onDismiss) {
            Text(
                "\"${v.name}\" will be deleted permanently. This can't be undone.",
                color = Color.White.copy(alpha = 0.8f), fontSize = 13.sp
            )
            if (error.isNotEmpty()) {
                Text(error, color = Color(0xFFFF6B6B), fontSize = 12.sp, modifier = Modifier.padding(top = 6.dp))
            }
            Spacer(Modifier.height(12.dp))
            Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                PillButton("Cancel", onDismiss, Modifier.weight(1f))
                PillButton("Delete", {
                    if (!blocked()) {
                        val err = deleteVideo(ctx, v)
                        if (err == null) onGone("Video deleted") else error = err
                    }
                }, Modifier.weight(1f), primary = true)
            }
        }
        3 -> DialogFrame("Hide folder?", onDismiss) {
            Text(
                "\"${v.folder}\" will be hidden from Gallery, Reels and Home. Your files are not touched. " +
                    "You can show it again in Settings > Library.",
                color = Color.White.copy(alpha = 0.8f), fontSize = 13.sp
            )
            Spacer(Modifier.height(12.dp))
            Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                PillButton("Cancel", onDismiss, Modifier.weight(1f))
                PillButton("Hide", {
                    AppSettings.hideFolder(ctx, v.folder)
                    onGone("Folder hidden")
                }, Modifier.weight(1f), primary = true)
            }
        }
        else -> DialogFrame("Move to Private?", onDismiss) {
            Text(
                "The video moves to a hidden folder and disappears from Gallery and other apps. " +
                    "Open it from Videos > Private (PIN or fingerprint).",
                color = Color.White.copy(alpha = 0.8f), fontSize = 13.sp
            )
            if (error.isNotEmpty()) {
                Text(error, color = Color(0xFFFF6B6B), fontSize = 12.sp, modifier = Modifier.padding(top = 6.dp))
            }
            Spacer(Modifier.height(12.dp))
            Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                PillButton("Cancel", onDismiss, Modifier.weight(1f))
                PillButton("Move", {
                    val err = moveToPrivate(ctx, v)
                    if (err == null) onGone("Moved to Private") else error = err
                }, Modifier.weight(1f), primary = true)
            }
        }
    }
}

/** Small overlay for the folder grid: long-press a folder to hide it. */
@Composable
fun HideFolderDialog(folderTitle: String, onHide: () -> Unit, onDismiss: () -> Unit) {
    DialogFrame("Hide folder?", onDismiss) {
        Text(
            "\"$folderTitle\" will be hidden from Gallery, Reels and Home. Your files are not touched. " +
                "You can show it again in Settings > Library.",
            color = Color.White.copy(alpha = 0.8f), fontSize = 13.sp
        )
        Spacer(Modifier.height(12.dp))
        Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
            PillButton("Cancel", onDismiss, Modifier.weight(1f))
            PillButton("Hide", onHide, Modifier.weight(1f), primary = true)
        }
    }
}

// =====================================================================
// 11. Network stream
// =====================================================================

fun streamVideo(url: String): Video {
    val u = Uri.parse(url)
    val last = u.lastPathSegment?.takeIf { it.isNotBlank() } ?: (u.host ?: "Stream")
    return Video(url.hashCode().toLong(), u, last, "Network stream", 0L, 0L, 0L)
}

private fun loadStreamRecents(ctx: Context): List<String> =
    ctx.getSharedPreferences("stream", Context.MODE_PRIVATE).getString("recent", "")!!
        .split('\n').filter { it.isNotBlank() }

private fun saveStreamRecent(ctx: Context, url: String) {
    val next = (listOf(url) + loadStreamRecents(ctx).filter { it != url }).take(5)
    ctx.getSharedPreferences("stream", Context.MODE_PRIVATE).edit()
        .putString("recent", next.joinToString("\n")).apply()
}

@Composable
fun StreamDialog(onPlay: (String) -> Unit, onDismiss: () -> Unit) {
    val ctx = LocalContext.current
    val clipboard = LocalClipboardManager.current
    var url by remember { mutableStateOf("") }
    val recents = remember { loadStreamRecents(ctx) }

    DialogFrame("Network stream", onDismiss, maxH = 460.dp) {
        BasicTextField(
            value = url,
            onValueChange = { url = it },
            singleLine = true,
            textStyle = TextStyle(color = Color.White, fontSize = 14.sp),
            cursorBrush = SolidColor(Accent),
            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Uri),
            modifier = Modifier.fillMaxWidth().clip(RoundedCornerShape(12.dp))
                .background(Color.White.copy(alpha = 0.08f)).padding(horizontal = 14.dp, vertical = 12.dp),
            decorationBox = { inner ->
                Box {
                    if (url.isEmpty()) {
                        Text("https://example.com/video.mp4  (or .m3u8 / .mpd)", color = Color.White.copy(alpha = 0.4f), fontSize = 14.sp)
                    }
                    inner()
                }
            }
        )
        Spacer(Modifier.height(10.dp))
        Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
            PillButton("Paste", {
                val t = clipboard.getText()?.text
                if (!t.isNullOrBlank()) url = t.trim()
            }, Modifier.weight(1f))
            PillButton("Play", {
                val u = url.trim()
                if (u.startsWith("http://") || u.startsWith("https://")) {
                    saveStreamRecent(ctx, u)
                    onPlay(u)
                } else {
                    Toast.makeText(ctx, "Enter a valid http(s) link", Toast.LENGTH_SHORT).show()
                }
            }, Modifier.weight(1f), primary = true)
        }
        if (recents.isNotEmpty()) {
            SectionLabel("Recent")
            recents.forEach { r ->
                Text(
                    r, color = Color.White.copy(alpha = 0.8f), fontSize = 13.sp, maxLines = 1,
                    overflow = TextOverflow.Ellipsis,
                    modifier = Modifier.fillMaxWidth().clickable { url = r }.padding(vertical = 8.dp)
                )
            }
        }
        Text(
            "Supports direct video links, HLS (.m3u8) and DASH (.mpd).",
            color = Color.White.copy(alpha = 0.4f), fontSize = 11.sp, modifier = Modifier.padding(top = 8.dp)
        )
    }
}
