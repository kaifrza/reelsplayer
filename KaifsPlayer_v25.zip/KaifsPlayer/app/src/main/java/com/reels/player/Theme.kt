@file:OptIn(androidx.compose.material3.ExperimentalMaterial3Api::class)

package com.reels.player

import android.content.Context
import android.widget.Toast
import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.Spring
import androidx.compose.animation.core.spring
import androidx.compose.animation.core.tween
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Switch
import androidx.compose.material3.SwitchDefaults
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.compositionLocalOf
import androidx.compose.runtime.getValue
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.launch

// ---------- Theme tokens (light / dark) ----------

val LocalDark = compositionLocalOf { true }

val Bg: Color
    @Composable get() = if (LocalDark.current) Color(0xFF0B0B0F) else Color(0xFFF3F3F7)

val CardBg: Color
    @Composable get() = if (LocalDark.current) Color(0xFF1C1C22) else Color(0xFFFFFFFF)

val Fg: Color
    @Composable get() = if (LocalDark.current) Color.White else Color(0xFF16161A)

object AppSettings {
    var theme by mutableIntStateOf(0)          // 0 system, 1 light, 2 dark
    var musicAll by mutableStateOf(false)
    var notifArt by mutableStateOf(false)

    private fun p(ctx: Context) = ctx.getSharedPreferences("app", Context.MODE_PRIVATE)

    fun load(ctx: Context) {
        theme = p(ctx).getInt("theme", 0)
        musicAll = p(ctx).getBoolean("music_all", false)
        notifArt = p(ctx).getBoolean("notif_art", false)
    }

    fun setTheme(ctx: Context, v: Int) {
        theme = v
        p(ctx).edit().putInt("theme", v).apply()
    }

    fun setNotifArt(ctx: Context, v: Boolean) {
        notifArt = v
        p(ctx).edit().putBoolean("notif_art", v).apply()
    }

    fun setMusicAll(ctx: Context, v: Boolean) {
        musicAll = v
        p(ctx).edit().putBoolean("music_all", v).apply()
    }
}

// ---------- Splash ----------

@Composable
fun SplashScreen() {
    val scale = remember { Animatable(0.6f) }
    val fade = remember { Animatable(0f) }
    LaunchedEffect(Unit) {
        launch { fade.animateTo(1f, tween(500)) }
        scale.animateTo(1f, spring(Spring.DampingRatioMediumBouncy))
    }
    Box(
        Modifier.fillMaxSize().background(
            Brush.verticalGradient(listOf(Color(0xFFE1306C), Color(0xFF833AB4)))
        ),
        contentAlignment = Alignment.Center
    ) {
        Column(
            horizontalAlignment = Alignment.CenterHorizontally,
            modifier = Modifier.graphicsLayer {
                scaleX = scale.value
                scaleY = scale.value
                alpha = fade.value
            }
        ) {
            Box(
                Modifier.size(96.dp).clip(RoundedCornerShape(28.dp)).background(Color.White),
                contentAlignment = Alignment.Center
            ) {
                Ic(R.drawable.ic_play, 56.dp, Accent)
            }
            Text(
                "KaifsPlayer",
                color = Color.White,
                fontSize = 30.sp,
                fontWeight = FontWeight.Bold,
                modifier = Modifier.padding(top = 20.dp)
            )
            Text(
                "Reels  •  Movies  •  Music",
                color = Color.White.copy(alpha = 0.85f),
                fontSize = 13.sp,
                modifier = Modifier.padding(top = 4.dp)
            )
        }
    }
}

// ---------- Bottom navigation ----------

@Composable
fun NavBar(selected: Int, onSelect: (Int) -> Unit) {
    val items = listOf(
        Pair(R.drawable.ic_home, "Home"),
        Pair(R.drawable.ic_reels, "Reels"),
        Pair(R.drawable.ic_videos, "Videos"),
        Pair(R.drawable.ic_music_note, "Music"),
        Pair(R.drawable.ic_settings, "Settings")
    )
    Column(Modifier.fillMaxWidth().background(CardBg)) {
        Box(Modifier.fillMaxWidth().height(1.dp).background(Fg.copy(alpha = 0.08f)))
        Row(
            Modifier.fillMaxWidth().navigationBarsPadding().height(60.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            items.forEachIndexed { i, item ->
                val sel = i == selected
                val tint = if (sel) Accent else Fg.copy(alpha = 0.6f)
                Column(
                    Modifier.weight(1f).fillMaxHeight().clickable { onSelect(i) },
                    horizontalAlignment = Alignment.CenterHorizontally,
                    verticalArrangement = Arrangement.Center
                ) {
                    Box(
                        Modifier.clip(RoundedCornerShape(16.dp))
                            .background(if (sel) Accent.copy(alpha = 0.16f) else Color.Transparent)
                            .padding(horizontal = 18.dp, vertical = 4.dp)
                    ) {
                        Ic(item.first, 22.dp, tint)
                    }
                    Text(
                        item.second,
                        color = tint,
                        fontSize = 11.sp,
                        fontWeight = if (sel) FontWeight.Bold else FontWeight.Normal
                    )
                }
            }
        }
    }
}

// ---------- Settings ----------

@Composable
fun SettingsCard(title: String, content: @Composable () -> Unit) {
    Column(
        Modifier.fillMaxWidth().padding(start = 16.dp, end = 16.dp, top = 14.dp)
            .clip(RoundedCornerShape(16.dp)).background(CardBg).padding(16.dp)
    ) {
        Text(title, color = Accent, fontSize = 13.sp, fontWeight = FontWeight.Bold)
        Spacer(Modifier.height(10.dp))
        content()
    }
}

@Composable
fun ToggleRow(title: String, sub: String, checked: Boolean, onChange: (Boolean) -> Unit) {
    Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
        Column(Modifier.weight(1f).padding(end = 12.dp)) {
            Text(title, color = Fg, fontSize = 15.sp)
            Text(sub, color = Fg.copy(alpha = 0.6f), fontSize = 12.sp)
        }
        Switch(
            checked = checked,
            onCheckedChange = onChange,
            colors = SwitchDefaults.colors(checkedTrackColor = Accent, checkedThumbColor = Color.White)
        )
    }
}

@Composable
fun ActionRow(label: String, sub: String?, onClick: () -> Unit) {
    Column(
        Modifier.fillMaxWidth().clickable(onClick = onClick).padding(vertical = 10.dp)
    ) {
        Text(label, color = Fg, fontSize = 15.sp)
        if (sub != null) Text(sub, color = Fg.copy(alpha = 0.6f), fontSize = 12.sp)
    }
}

@Composable
fun SettingsScreen(onOpenVault: () -> Unit = {}) {
    val ctx = LocalContext.current
    val rp = remember { ctx.getSharedPreferences("reels", Context.MODE_PRIVATE) }
    var fitMode by remember { mutableIntStateOf(rp.getInt("fit_mode", 0)) }
    var confirm by remember { mutableIntStateOf(0) }
    val version = remember {
        runCatching { ctx.packageManager.getPackageInfo(ctx.packageName, 0).versionName }.getOrNull() ?: "1.0"
    }

    Column(
        Modifier.fillMaxSize().background(Bg).verticalScroll(rememberScrollState()).padding(bottom = 24.dp)
    ) {
        Text(
            "Settings",
            color = Fg,
            fontSize = 26.sp,
            fontWeight = FontWeight.Bold,
            modifier = Modifier.padding(start = 16.dp, end = 16.dp, top = 40.dp)
        )

        SettingsCard("Appearance") {
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                Chip(R.drawable.ic_settings, "System", AppSettings.theme == 0) { AppSettings.setTheme(ctx, 0) }
                Chip(R.drawable.ic_brightness, "Light", AppSettings.theme == 1) { AppSettings.setTheme(ctx, 1) }
                Chip(R.drawable.ic_dark_mode, "Dark", AppSettings.theme == 2) { AppSettings.setTheme(ctx, 2) }
            }
        }

        SettingsCard("Reels") {
            Text("Video fit", color = Fg, fontSize = 15.sp)
            Spacer(Modifier.height(8.dp))
            Row(
                Modifier.fillMaxWidth().horizontalScrollCompat(),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                fitNames.forEachIndexed { i, name ->
                    Chip(R.drawable.ic_aspect, name.substringBefore(' '), fitMode == i) {
                        fitMode = i
                        rp.edit().putInt("fit_mode", i).apply()
                    }
                }
            }
        }

        SettingsCard("Music") {
            ToggleRow(
                "Show all audio files",
                "Include voice notes and recordings in the music list",
                AppSettings.musicAll
            ) { AppSettings.setMusicAll(ctx, it) }
        }

        SettingsCard("Music notification") {
            ToggleRow(
                "Artwork background style",
                "Shows the song artwork behind the notification. Off uses your phone's standard media notification, which looks best on Vivo and similar phones.",
                AppSettings.notifArt
            ) {
                AppSettings.setNotifArt(ctx, it)
                MusicService.instance?.refreshNotification()
            }
        }

        SettingsCard("Privacy") {
            ActionRow("Hidden videos", "Videos hidden from Gallery, file managers and all other apps. Protected by a PIN", onOpenVault)
        }

        SettingsCard("Data") {
            ActionRow("Clear continue watching", "Removes your saved Movie player resume positions") {
                confirm = 1
            }
            ActionRow("Reset liked videos", "Removes all your likes in Reels") {
                confirm = 2
            }
        }

        SettingsCard("Permissions") {
            ActionRow("All files access", "Needed to browse every folder in Files (Android 11+)") {
                openAllFilesSettings(ctx)
            }
        }

        SettingsCard("About") {
            Text("KaifsPlayer", color = Fg, fontSize = 16.sp, fontWeight = FontWeight.Bold)
            Text("Version $version", color = Fg.copy(alpha = 0.6f), fontSize = 12.sp)
            Text("Reels  •  Movies  •  Music", color = Fg.copy(alpha = 0.6f), fontSize = 12.sp)
        }
    }

    if (confirm != 0) {
        val clearing = confirm == 1
        AlertDialog(
            onDismissRequest = { confirm = 0 },
            title = { Text(if (clearing) "Clear continue watching?" else "Reset liked videos?") },
            text = {
                Text(
                    if (clearing) "This will remove all saved resume positions from the Movie player. This action can't be undone."
                    else "This will remove all your likes in Reels. This action can't be undone."
                )
            },
            confirmButton = {
                TextButton(onClick = {
                    if (clearing) {
                        saveRecents(ctx, emptyList())
                        Toast.makeText(ctx, "Continue watching cleared", Toast.LENGTH_SHORT).show()
                    } else {
                        rp.edit().remove("liked").apply()
                        Toast.makeText(ctx, "Liked videos reset", Toast.LENGTH_SHORT).show()
                    }
                    confirm = 0
                }) {
                    Text(if (clearing) "Clear" else "Reset", color = Color(0xFFE5484D))
                }
            },
            dismissButton = {
                TextButton(onClick = { confirm = 0 }) { Text("Cancel", color = Fg) }
            },
            containerColor = CardBg,
            titleContentColor = Fg,
            textContentColor = Fg.copy(alpha = 0.75f)
        )
    }
}

fun Modifier.horizontalScrollCompat(): Modifier = this
