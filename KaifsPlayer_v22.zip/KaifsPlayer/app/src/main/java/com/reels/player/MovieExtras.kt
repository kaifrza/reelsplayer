package com.reels.player

import android.content.ContentValues
import android.content.Context
import android.graphics.Bitmap
import android.media.MediaMetadataRetriever
import android.media.MediaScannerConnection
import android.net.Uri
import android.os.Build
import android.os.Environment
import android.provider.MediaStore
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import java.io.File
import java.io.FileOutputStream

// ---------- External subtitles (parsed here so the delay can be changed live) ----------

class ExtCue(val startMs: Long, val endMs: Long, val text: String)

private val timeRegex = Regex("""(?:(\d+):)?(\d+):(\d+)[.,](\d{1,3})""")

private fun parseTime(s: String): Long? {
    val m = timeRegex.find(s) ?: return null
    val h = m.groupValues[1].ifEmpty { "0" }.toLong()
    val min = m.groupValues[2].toLong()
    val sec = m.groupValues[3].toLong()
    val msRaw = m.groupValues[4]
    val ms = msRaw.padEnd(3, '0').toLong()
    return ((h * 60 + min) * 60 + sec) * 1000 + ms
}

/** Parses SRT and simple WebVTT. Returns an empty list if nothing usable was found. */
fun parseSubtitles(raw: String): List<ExtCue> {
    val text = raw.removePrefix("\uFEFF").replace("\r\n", "\n").replace('\r', '\n')
    val out = ArrayList<ExtCue>()
    for (block in text.split(Regex("\n\\s*\n"))) {
        val lines = block.trim().split('\n')
        val ti = lines.indexOfFirst { it.contains("-->") }
        if (ti < 0) continue
        val parts = lines[ti].split("-->")
        if (parts.size < 2) continue
        val s = parseTime(parts[0]) ?: continue
        val e = parseTime(parts[1]) ?: continue
        val body = lines.drop(ti + 1).joinToString("\n")
            .replace(Regex("<[^>]+>"), "")
            .replace(Regex("\\{[^}]*\\}"), "")
            .trim()
        if (body.isNotEmpty()) out.add(ExtCue(s, e, body))
    }
    out.sortBy { it.startMs }
    return out
}

fun readSubtitleText(ctx: Context, uri: Uri): String? = runCatching {
    val bytes = if (uri.scheme == "file") File(uri.path!!).readBytes()
    else ctx.contentResolver.openInputStream(uri)!!.use { it.readBytes() }
    val utf8 = String(bytes, Charsets.UTF_8)
    // If UTF-8 decoding produced replacement characters, the file is probably a legacy 8-bit encoding.
    if (utf8.contains('\uFFFD')) String(bytes, Charsets.ISO_8859_1) else utf8
}.getOrNull()

fun cueAt(cues: List<ExtCue>, tMs: Long): String? {
    if (cues.isEmpty()) return null
    var lo = 0
    var hi = cues.size - 1
    var found = -1
    while (lo <= hi) {
        val mid = (lo + hi) ushr 1
        if (cues[mid].startMs <= tMs) { found = mid; lo = mid + 1 } else hi = mid - 1
    }
    // look back a few cues in case of overlaps
    var i = found
    while (i >= 0 && i > found - 4) {
        val c = cues[i]
        if (tMs in c.startMs until c.endMs) return c.text
        i--
    }
    return null
}

// ---------- Frames: screenshot + seek preview ----------

/** Keeps one MediaMetadataRetriever alive for the seek-bar preview. All access is synchronized. */
class FrameGrabber {
    private var retriever: MediaMetadataRetriever? = null
    private var uri: Uri? = null

    @Synchronized
    fun frame(ctx: Context, u: Uri, tMs: Long, w: Int, h: Int): Bitmap? = runCatching {
        if (retriever == null || uri != u) {
            runCatching { retriever?.release() }
            retriever = MediaMetadataRetriever().also { it.setDataSource(ctx, u) }
            uri = u
        }
        val r = retriever!!
        if (Build.VERSION.SDK_INT >= 27) {
            r.getScaledFrameAtTime(tMs * 1000, MediaMetadataRetriever.OPTION_CLOSEST_SYNC, w, h)
        } else {
            val b = r.getFrameAtTime(tMs * 1000, MediaMetadataRetriever.OPTION_CLOSEST_SYNC)
            if (b != null) {
                val ratio = b.width.toFloat() / b.height
                Bitmap.createScaledBitmap(b, w, (w / ratio).toInt().coerceAtLeast(1), true)
            } else null
        }
    }.getOrNull()

    @Synchronized
    fun release() {
        runCatching { retriever?.release() }
        retriever = null
        uri = null
    }
}

/** Full-size frame at the given position (exact frame), for screenshots. */
fun grabFullFrame(ctx: Context, u: Uri, tMs: Long): Bitmap? {
    val r = MediaMetadataRetriever()
    return try {
        r.setDataSource(ctx, u)
        r.getFrameAtTime(tMs * 1000, MediaMetadataRetriever.OPTION_CLOSEST)
    } catch (e: Exception) {
        null
    } finally {
        runCatching { r.release() }
    }
}

fun saveScreenshot(ctx: Context, bmp: Bitmap, baseName: String): Boolean = runCatching {
    val name = "${baseName}_${System.currentTimeMillis()}.jpg"
    if (Build.VERSION.SDK_INT >= 29) {
        val cv = ContentValues().apply {
            put(MediaStore.Images.Media.DISPLAY_NAME, name)
            put(MediaStore.Images.Media.MIME_TYPE, "image/jpeg")
            put(MediaStore.Images.Media.RELATIVE_PATH, "Pictures/KaifsPlayer")
            put(MediaStore.Images.Media.IS_PENDING, 1)
        }
        val u = ctx.contentResolver.insert(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, cv)
        if (u == null) {
            false
        } else {
            ctx.contentResolver.openOutputStream(u)!!.use { bmp.compress(Bitmap.CompressFormat.JPEG, 95, it) }
            cv.clear()
            cv.put(MediaStore.Images.Media.IS_PENDING, 0)
            ctx.contentResolver.update(u, cv, null, null)
            true
        }
    } else {
        val dir = File(Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_PICTURES), "KaifsPlayer")
        dir.mkdirs()
        val f = File(dir, name)
        FileOutputStream(f).use { bmp.compress(Bitmap.CompressFormat.JPEG, 95, it) }
        MediaScannerConnection.scanFile(ctx, arrayOf(f.absolutePath), null, null)
        true
    }
}.getOrDefault(false)

// ---------- Subtitle delay dialog ----------

@Composable
fun SubDelayDialog(delayMs: Long, hasFile: Boolean, onChange: (Long) -> Unit, onDismiss: () -> Unit) {
    Box(
        Modifier.fillMaxSize().background(Color.Black.copy(alpha = 0.5f)).clickable(onClick = onDismiss),
        contentAlignment = Alignment.Center
    ) {
        Column(
            Modifier.widthIn(max = 360.dp).fillMaxWidth(0.88f).heightIn(max = 300.dp)
                .clip(RoundedCornerShape(22.dp)).background(Color(0xFF1C1C22))
                .clickable(onClick = { })
                .padding(horizontal = 16.dp, vertical = 16.dp)
        ) {
            Text("Subtitle delay", color = Color.White.copy(alpha = 0.85f), fontSize = 14.sp)
            if (!hasFile) {
                Text(
                    "No subtitle file loaded. Open the CC menu and choose \"+ Add subtitle file\", " +
                        "or put a .srt/.vtt with the same name next to the video.",
                    color = Color.White.copy(alpha = 0.6f), fontSize = 13.sp,
                    modifier = Modifier.padding(top = 10.dp)
                )
            } else {
                Row(Modifier.fillMaxWidth().padding(top = 8.dp), verticalAlignment = Alignment.CenterVertically) {
                    SpeedArrow(left = true) { onChange((delayMs - 100L).coerceAtLeast(-60_000L)) }
                    Text(
                        "%+.1f s".format(delayMs / 1000f),
                        color = Accent, fontSize = 30.sp, fontWeight = FontWeight.Bold,
                        textAlign = TextAlign.Center, modifier = Modifier.weight(1f)
                    )
                    SpeedArrow(left = false) { onChange((delayMs + 100L).coerceAtMost(60_000L)) }
                }
                Text(
                    "+ shows subtitles later, - shows them earlier",
                    color = Color.White.copy(alpha = 0.5f), fontSize = 12.sp,
                    modifier = Modifier.padding(top = 6.dp).fillMaxWidth(), textAlign = TextAlign.Center
                )
                Box(
                    Modifier.padding(top = 12.dp).fillMaxWidth().clip(RoundedCornerShape(10.dp))
                        .background(Color.White.copy(alpha = 0.08f))
                        .clickable { onChange(0L) }
                        .padding(vertical = 10.dp),
                    contentAlignment = Alignment.Center
                ) { Text("Reset", color = Color.White, fontSize = 13.sp) }
            }
        }
    }
}
