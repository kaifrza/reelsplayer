package com.reels.player

import android.content.Context
import android.widget.Toast
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

@Composable
fun SectionTitle(title: String, action: String? = null, onAction: () -> Unit = { }) {
    Row(
        Modifier.fillMaxWidth().padding(start = 16.dp, end = 16.dp, top = 24.dp, bottom = 10.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Text(title, color = Fg, fontSize = 18.sp, fontWeight = FontWeight.Bold, modifier = Modifier.weight(1f))
        if (action != null) {
            Text(action, color = Accent, fontSize = 13.sp, modifier = Modifier.clickable(onClick = onAction))
        }
    }
}

@Composable
fun QuickCard(res: Int, label: String, modifier: Modifier, onClick: () -> Unit) {
    Column(
        modifier.clip(RoundedCornerShape(16.dp)).background(CardBg)
            .clickable(onClick = onClick).padding(vertical = 14.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Box(
            Modifier.size(44.dp).clip(CircleShape).background(Accent.copy(alpha = 0.18f)),
            contentAlignment = Alignment.Center
        ) {
            Ic(res, 24.dp, Accent)
        }
        Text(label, color = Fg, fontSize = 12.sp, fontWeight = FontWeight.Medium, modifier = Modifier.padding(top = 8.dp))
    }
}

@Composable
fun VideoCard(v: Video, width: Dp, aspect: Float, badge: String?, subtitle: String?, onClick: () -> Unit) {
    Column(Modifier.width(width).clickable(onClick = onClick)) {
        Box(Modifier.fillMaxWidth().aspectRatio(aspect).clip(RoundedCornerShape(12.dp))) {
            Thumb(v, 320, (320 / aspect).toInt(), Modifier.fillMaxSize())
            if (badge != null) {
                Text(
                    badge,
                    color = Color.White,
                    fontSize = 11.sp,
                    fontWeight = FontWeight.Medium,
                    modifier = Modifier.align(Alignment.BottomEnd).padding(6.dp)
                        .background(Color.Black.copy(alpha = 0.65f), RoundedCornerShape(6.dp))
                        .padding(horizontal = 5.dp, vertical = 2.dp)
                )
            }
        }
        Text(
            v.name.substringBeforeLast('.'),
            color = Fg,
            fontSize = 12.sp,
            maxLines = 2,
            overflow = TextOverflow.Ellipsis,
            modifier = Modifier.padding(top = 6.dp)
        )
        if (subtitle != null) {
            Text(subtitle, color = Fg.copy(alpha = 0.55f), fontSize = 11.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
        }
    }
}

@Composable
fun HomeScreen(
    all: List<Video>,
    songs: List<Song>?,
    onReels: (List<Video>, Int) -> Unit,
    onBrowse: (Int) -> Unit,
    onMovie: (Video) -> Unit,
    onFolder: (String) -> Unit,
    onPlaySongs: (List<Song>, Int) -> Unit,
    onMusicTab: () -> Unit
) {
    val ctx = LocalContext.current
    val prefs = remember { ctx.getSharedPreferences("reels", Context.MODE_PRIVATE) }
    val recents = remember { loadRecents(ctx).take(10) }
    val likedSet = remember { prefs.getStringSet("liked", emptySet())!!.toSet() }
    val liked = remember(all) { all.filter { it.uri.toString() in likedSet } }
    val movies = remember(all) { all.filter { it.durationMs >= 20 * 60_000L }.take(15) }
    val folders = remember(all) {
        all.groupBy { it.folder }.entries.sortedByDescending { it.value.size }.take(12)
    }
    val last = remember { lastIndex(ctx, all) }
    val newSongs = remember(songs) { songs?.sortedByDescending { it.added }?.take(20) ?: emptyList() }

    LazyColumn(
        Modifier.fillMaxSize().background(Bg),
        contentPadding = PaddingValues(bottom = 24.dp)
    ) {
        // Header
        item {
            Row(
                Modifier.fillMaxWidth().padding(start = 16.dp, end = 16.dp, top = 40.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Box(
                    Modifier.size(46.dp).clip(RoundedCornerShape(14.dp)).background(Accent),
                    contentAlignment = Alignment.Center
                ) {
                    Ic(R.drawable.ic_play, 28.dp, Color.White)
                }
                Column(Modifier.padding(start = 12.dp)) {
                    Text("KaifsPlayer", color = Fg, fontSize = 24.sp, fontWeight = FontWeight.Bold)
                    Text("Reels  •  Movies  •  Music", color = Fg.copy(alpha = 0.6f), fontSize = 13.sp)
                }
            }
        }

        // Hero: continue reels
        if (all.isNotEmpty()) {
            item {
                val hero = all[last.coerceIn(0, all.size - 1)]
                Box(
                    Modifier.fillMaxWidth().padding(start = 16.dp, end = 16.dp, top = 20.dp)
                        .height(180.dp).clip(RoundedCornerShape(20.dp)).background(CardBg)
                        .clickable { onReels(all, last) }
                ) {
                    Thumb(hero, 640, 360, Modifier.fillMaxSize())
                    Box(
                        Modifier.fillMaxSize().background(
                            Brush.verticalGradient(listOf(Color.Black.copy(alpha = 0.15f), Color.Black.copy(alpha = 0.8f)))
                        )
                    )
                    Column(Modifier.align(Alignment.BottomStart).padding(16.dp)) {
                        Text("Reels chalao", color = Color.White, fontSize = 22.sp, fontWeight = FontWeight.Bold)
                        Text(
                            hero.name.substringBeforeLast('.'),
                            color = Color.White.copy(alpha = 0.75f),
                            fontSize = 13.sp,
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis,
                            modifier = Modifier.padding(end = 70.dp)
                        )
                    }
                    Box(
                        Modifier.align(Alignment.BottomEnd).padding(16.dp).size(50.dp)
                            .clip(CircleShape).background(Accent),
                        contentAlignment = Alignment.Center
                    ) {
                        Ic(R.drawable.ic_play, 28.dp, Color.White)
                    }
                }
            }
        }

        // Quick actions
        item {
            Row(
                Modifier.fillMaxWidth().padding(start = 16.dp, end = 16.dp, top = 18.dp),
                horizontalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                QuickCard(R.drawable.ic_folder, "Files", Modifier.weight(1f)) { onBrowse(0) }
                QuickCard(R.drawable.ic_apps, "Gallery", Modifier.weight(1f)) { onBrowse(1) }
                QuickCard(R.drawable.ic_music_note, "Music", Modifier.weight(1f)) { onMusicTab() }
                QuickCard(R.drawable.ic_heart, "Liked", Modifier.weight(1f)) {
                    if (liked.isNotEmpty()) onReels(liked, 0)
                    else Toast.makeText(ctx, "Abhi koi liked video nahi hai", Toast.LENGTH_SHORT).show()
                }
            }
        }

        // Continue watching
        if (recents.isNotEmpty()) {
            item { SectionTitle("Continue watching", "Sab dekho") { onBrowse(2) } }
            item {
                LazyRow(
                    contentPadding = PaddingValues(horizontal = 16.dp),
                    horizontalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    items(recents) { r ->
                        val v = remember(r.uri) { recentVideo(r) }
                        val left = (r.dur - r.pos).coerceAtLeast(0)
                        VideoCard(v, 190.dp, 16f / 9f, fmt(r.pos) + " / " + fmt(r.dur), "${fmt(left)} baaki") {
                            onMovie(v)
                        }
                    }
                }
            }
        }

        // Music
        if (newSongs.isNotEmpty()) {
            item { SectionTitle("Music", "Sab gaane") { onMusicTab() } }
            item {
                LazyRow(
                    contentPadding = PaddingValues(horizontal = 16.dp),
                    horizontalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    items(newSongs.size) { i ->
                        val s = newSongs[i]
                        Column(Modifier.width(112.dp).clickable { onPlaySongs(newSongs, i) }) {
                            ArtImage(s.uri, s.id.toString(), 256, Modifier.size(112.dp), 14.dp)
                            Text(
                                s.title, color = Fg, fontSize = 12.sp, maxLines = 1,
                                overflow = TextOverflow.Ellipsis, modifier = Modifier.padding(top = 6.dp)
                            )
                            Text(
                                s.artist, color = Fg.copy(alpha = 0.55f), fontSize = 11.sp, maxLines = 1,
                                overflow = TextOverflow.Ellipsis
                            )
                        }
                    }
                }
            }
        }

        if (all.isNotEmpty()) {
            // Recently added
            item { SectionTitle("Recently added", "Reels me dekho") { onReels(all, 0) } }
            item {
                LazyRow(
                    contentPadding = PaddingValues(horizontal = 16.dp),
                    horizontalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    val recent = all.take(12)
                    items(recent.size) { i ->
                        val v = recent[i]
                        VideoCard(v, 110.dp, 0.62f, fmt(v.durationMs), null) { onReels(all, i) }
                    }
                }
            }

            // Movies
            if (movies.isNotEmpty()) {
                item { SectionTitle("Movies  (20+ min)") }
                item {
                    LazyRow(
                        contentPadding = PaddingValues(horizontal = 16.dp),
                        horizontalArrangement = Arrangement.spacedBy(12.dp)
                    ) {
                        items(movies) { v ->
                            VideoCard(v, 190.dp, 16f / 9f, fmt(v.durationMs), v.folder) { onMovie(v) }
                        }
                    }
                }
            }

            // Liked
            if (liked.isNotEmpty()) {
                item { SectionTitle("Liked", "Sab chalao") { onReels(liked, 0) } }
                item {
                    LazyRow(
                        contentPadding = PaddingValues(horizontal = 16.dp),
                        horizontalArrangement = Arrangement.spacedBy(12.dp)
                    ) {
                        val likedShow = liked.take(12)
                        items(likedShow.size) { i ->
                            val v = likedShow[i]
                            VideoCard(v, 110.dp, 0.62f, fmt(v.durationMs), null) { onReels(liked, i) }
                        }
                    }
                }
            }

            // Folders
            item { SectionTitle("Folders", "Sab dekho") { onBrowse(1) } }
            item {
                LazyRow(
                    contentPadding = PaddingValues(horizontal = 16.dp),
                    horizontalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    items(folders) { f ->
                        VideoCard(f.value.first(), 140.dp, 1.2f, "${f.value.size}", f.key) { onFolder(f.key) }
                    }
                }
            }
        }

        item { Spacer(Modifier.height(8.dp)) }
    }
}
