@file:OptIn(
    androidx.media3.common.util.UnstableApi::class,
    androidx.compose.foundation.ExperimentalFoundationApi::class,
    androidx.compose.material3.ExperimentalMaterial3Api::class
)

package com.reels.player

import android.Manifest
import android.app.Activity
import android.app.PictureInPictureParams
import android.content.Context
import android.content.ContextWrapper
import android.content.Intent
import android.content.pm.ActivityInfo
import android.content.pm.PackageManager
import android.media.AudioManager
import android.net.Uri
import android.os.Build
import android.provider.MediaStore
import android.provider.OpenableColumns
import android.util.Rational
import android.view.WindowManager
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectDragGestures
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Slider
import androidx.compose.material3.SliderDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableLongStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalLifecycleOwner
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.core.content.ContextCompat
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.LifecycleEventObserver
import androidx.media3.common.AudioAttributes
import androidx.media3.common.C
import androidx.media3.common.Format
import androidx.media3.common.MediaItem
import androidx.media3.common.MimeTypes
import androidx.media3.common.Player
import androidx.media3.common.TrackSelectionOverride
import androidx.media3.common.Tracks
import androidx.media3.common.VideoSize
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.ui.AspectRatioFrameLayout
import androidx.media3.ui.CaptionStyleCompat
import androidx.media3.ui.PlayerView
import java.io.File
import java.util.Locale
import kotlin.math.abs
import kotlin.math.roundToInt
import kotlinx.coroutines.delay
import kotlinx.coroutines.withTimeoutOrNull
import org.json.JSONArray
import org.json.JSONObject

// ---------- Helpers ----------

data class PanelItem(val label: String, val selected: Boolean, val onClick: () -> Unit)

data class Recent(
    val uri: String,
    val name: String,
    val folder: String,
    val pos: Long,
    val dur: Long,
    val ts: Long
)

val speedOptions = listOf(0.5f, 0.75f, 1f, 1.25f, 1.5f, 2f, 3f)
val resizeModes = listOf(
    AspectRatioFrameLayout.RESIZE_MODE_FIT,
    AspectRatioFrameLayout.RESIZE_MODE_ZOOM,
    AspectRatioFrameLayout.RESIZE_MODE_FILL
)
val resizeNames = listOf("Fit", "Crop", "Stretch")
val subSizeNames = listOf("Small", "Medium", "Large")
val subSizeScale = listOf(0.7f, 1f, 1.4f)
val subExts = mapOf(
    "srt" to MimeTypes.APPLICATION_SUBRIP,
    "vtt" to MimeTypes.TEXT_VTT,
    "ass" to MimeTypes.TEXT_SSA,
    "ssa" to MimeTypes.TEXT_SSA,
    "ttml" to MimeTypes.APPLICATION_TTML
)

fun Context.findActivity(): Activity? {
    var c: Context = this
    while (c is ContextWrapper) {
        if (c is Activity) return c
        c = c.baseContext
    }
    return null
}

fun enterPip(activity: Activity, w: Int, h: Int) {
    if (Build.VERSION.SDK_INT >= 26) {
        val r = if (w > 0 && h > 0) (w.toFloat() / h).coerceIn(0.5f, 2.3f) else 16f / 9f
        runCatching {
            activity.enterPictureInPictureMode(
                PictureInPictureParams.Builder()
                    .setAspectRatio(Rational((r * 1000).toInt(), 1000))
                    .build()
            )
        }
    }
}

fun naturalCompare(a: String, b: String): Int {
    var i = 0
    var j = 0
    while (i < a.length && j < b.length) {
        if (a[i].isDigit() && b[j].isDigit()) {
            var ie = i
            while (ie < a.length && a[ie].isDigit()) ie++
            var je = j
            while (je < b.length && b[je].isDigit()) je++
            val na = a.substring(i, ie).trimStart('0')
            val nb = b.substring(j, je).trimStart('0')
            if (na.length != nb.length) return na.length - nb.length
            val c = na.compareTo(nb)
            if (c != 0) return c
            i = ie
            j = je
        } else {
            val c = a[i].lowercaseChar().compareTo(b[j].lowercaseChar())
            if (c != 0) return c
            i++
            j++
        }
    }
    return (a.length - i) - (b.length - j)
}

fun siblingsOf(v: Video, all: List<Video>): List<Video> {
    val sib: List<Video> = if (v.uri.scheme == "file") {
        val f = File(v.uri.path ?: "")
        val files = f.parentFile?.listFiles() ?: emptyArray<File>()
        files.filter { it.isFile && isVideoFile(it) }
            .sortedWith(Comparator { a, b -> naturalCompare(a.name, b.name) })
            .map { fileVideo(it) }
    } else {
        all.filter { it.folder == v.folder }
            .sortedWith(Comparator { a, b -> naturalCompare(a.name, b.name) })
    }
    return if (sib.any { it.uri == v.uri }) sib else listOf(v)
}

fun videoPath(ctx: Context, v: Video): String? {
    if (v.uri.scheme == "file") return v.uri.path
    return runCatching {
        ctx.contentResolver.query(v.uri, arrayOf(MediaStore.MediaColumns.DATA), null, null, null)
            ?.use { c -> if (c.moveToFirst()) c.getString(0) else null }
    }.getOrNull()
}

fun findSubtitleConfigs(ctx: Context, v: Video): List<MediaItem.SubtitleConfiguration> {
    val p = videoPath(ctx, v) ?: return emptyList()
    val f = File(p)
    val dir = f.parentFile ?: return emptyList()
    val base = f.nameWithoutExtension
    val files = dir.listFiles() ?: return emptyList()
    val found = files
        .filter { it.isFile && it.extension.lowercase() in subExts.keys && it.name.startsWith(base) }
        .sortedBy { it.name }
    return found.mapIndexed { i, s ->
        MediaItem.SubtitleConfiguration.Builder(Uri.fromFile(s))
            .setMimeType(subExts.getValue(s.extension.lowercase()))
            .setLabel(s.name)
            .setSelectionFlags(if (i == 0) C.SELECTION_FLAG_DEFAULT else 0)
            .build()
    }
}

fun trackLabel(f: Format, idx: Int, kind: String): String {
    val lang = f.language?.let { l -> runCatching { Locale(l).displayLanguage }.getOrNull() }
        ?.takeIf { it.isNotBlank() }
    val base = f.label ?: lang ?: "$kind ${idx + 1}"
    val extra = if (kind == "Audio" && f.channelCount > 0) "  •  ${f.channelCount}ch" else ""
    return base + extra
}

// ---------- Recents (continue watching) ----------

fun loadRecents(ctx: Context): List<Recent> {
    val s = ctx.getSharedPreferences("movie", Context.MODE_PRIVATE).getString("recents", null)
        ?: return emptyList()
    return runCatching {
        val a = JSONArray(s)
        (0 until a.length()).map { i ->
            val o = a.getJSONObject(i)
            Recent(o.getString("u"), o.optString("n"), o.optString("f"), o.optLong("p"), o.optLong("d"), o.optLong("t"))
        }
    }.getOrDefault(emptyList())
}

fun saveRecents(ctx: Context, list: List<Recent>) {
    val a = JSONArray()
    list.forEach { r ->
        a.put(
            JSONObject().put("u", r.uri).put("n", r.name).put("f", r.folder)
                .put("p", r.pos).put("d", r.dur).put("t", r.ts)
        )
    }
    ctx.getSharedPreferences("movie", Context.MODE_PRIVATE).edit().putString("recents", a.toString()).apply()
}

fun updateRecent(ctx: Context, v: Video, pos: Long, dur: Long) {
    if (pos < 5_000) return
    val key = v.uri.toString()
    val rest = loadRecents(ctx).filter { it.uri != key }
    val finished = dur > 0 && pos >= dur - 20_000
    val next = if (finished) rest
    else listOf(Recent(key, v.name, v.folder, pos, dur, System.currentTimeMillis())) + rest
    saveRecents(ctx, next.take(30))
}

fun removeRecent(ctx: Context, key: String) {
    saveRecents(ctx, loadRecents(ctx).filter { it.uri != key })
}

fun savedPosition(ctx: Context, key: String): Long =
    loadRecents(ctx).firstOrNull { it.uri == key }?.pos ?: 0L

fun recentVideo(r: Recent): Video {
    val uri = Uri.parse(r.uri)
    val id = if (uri.scheme == "file") (uri.path ?: "").hashCode().toLong()
    else runCatching { android.content.ContentUris.parseId(uri) }.getOrDefault(0L)
    return Video(id, uri, r.name, r.folder, r.dur, 0L, 0L)
}

// ---------- Shared small composables ----------

@Composable
fun MenuRow(res: Int, text: String, onClick: () -> Unit) {
    Row(
        Modifier.fillMaxWidth().clickable(onClick = onClick).padding(horizontal = 16.dp, vertical = 14.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Ic(res, 22.dp)
        Spacer(Modifier.width(12.dp))
        Text(text, color = Color.White, fontSize = 15.sp)
    }
}

@Composable
fun Panel(title: String, items: List<PanelItem>, onDismiss: () -> Unit) {
    Box(
        Modifier.fillMaxSize().background(Color.Black.copy(alpha = 0.55f)).clickable(onClick = onDismiss),
        contentAlignment = Alignment.Center
    ) {
        Column(
            Modifier.widthIn(max = 380.dp).fillMaxWidth(0.9f).heightIn(max = 280.dp)
                .clip(RoundedCornerShape(16.dp)).background(Color(0xFF1C1C22))
                .clickable(onClick = { })
        ) {
            Text(title, color = Color.White, fontSize = 16.sp, fontWeight = FontWeight.Bold, modifier = Modifier.padding(16.dp))
            LazyColumn {
                items(items) { item ->
                    Row(
                        Modifier.fillMaxWidth().clickable(onClick = item.onClick)
                            .padding(horizontal = 16.dp, vertical = 12.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            item.label,
                            color = if (item.selected) Accent else Color.White,
                            fontSize = 14.sp,
                            modifier = Modifier.weight(1f)
                        )
                        if (item.selected) Ic(R.drawable.ic_check, 20.dp, Accent)
                    }
                }
            }
        }
    }
}

// ---------- Continue watching screen ----------

@Composable
fun ContinueScreen(onMode: (Int) -> Unit, onOpen: (Video) -> Unit, onBack: () -> Unit) {
    val ctx = LocalContext.current
    var recents by remember { mutableStateOf(loadRecents(ctx)) }

    Column(Modifier.fillMaxSize().background(Bg)) {
        BrowseHeader("Continue watching", "${recents.size} videos", onBack) { }
        ModeTabs(2, onMode)
        if (recents.isEmpty()) {
            Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                Text(
                    "Abhi kuch adhoora nahi hai.\nMovie player me video dekhoge to yahan aayegi.",
                    color = Fg.copy(alpha = 0.6f),
                    textAlign = TextAlign.Center,
                    modifier = Modifier.padding(32.dp)
                )
            }
        } else {
            LazyColumn(Modifier.fillMaxSize(), contentPadding = androidx.compose.foundation.layout.PaddingValues(bottom = 24.dp)) {
                items(recents) { r ->
                    val v = remember(r.uri) { recentVideo(r) }
                    val frac = if (r.dur > 0) (r.pos.toFloat() / r.dur).coerceIn(0f, 1f) else 0f
                    Row(
                        Modifier.fillMaxWidth().clickable { onOpen(v) }
                            .padding(horizontal = 14.dp, vertical = 8.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Box(Modifier.width(128.dp).height(72.dp).clip(RoundedCornerShape(10.dp))) {
                            Thumb(v, 256, 144, Modifier.fillMaxSize())
                            Box(
                                Modifier.align(Alignment.BottomStart).fillMaxWidth(frac).height(3.dp).background(Accent)
                            )
                        }
                        Spacer(Modifier.width(12.dp))
                        Column(Modifier.weight(1f)) {
                            Text(
                                r.name.substringBeforeLast('.'),
                                color = Fg,
                                fontSize = 15.sp,
                                maxLines = 2,
                                overflow = TextOverflow.Ellipsis
                            )
                            Text(
                                "${fmt(r.pos)} / ${fmt(r.dur)}  •  ${r.folder}",
                                color = Fg.copy(alpha = 0.6f),
                                fontSize = 12.sp,
                                maxLines = 1,
                                overflow = TextOverflow.Ellipsis
                            )
                        }
                        Box(
                            Modifier.size(36.dp).clip(CircleShape).clickable {
                                removeRecent(ctx, r.uri)
                                recents = loadRecents(ctx)
                            },
                            contentAlignment = Alignment.Center
                        ) {
                            Ic(R.drawable.ic_close, 18.dp, Fg.copy(alpha = 0.6f))
                        }
                    }
                }
            }
        }
    }
}

// ---------- Movie player ----------

@Composable
fun MovieScreen(list: List<Video>, startIndex: Int, onExit: (Video) -> Unit) {
    val ctx = LocalContext.current
    val activity = remember { ctx.findActivity() }
    val prefs = remember { ctx.getSharedPreferences("movie", Context.MODE_PRIVATE) }

    var idx by remember { mutableIntStateOf(startIndex.coerceIn(0, list.size - 1)) }
    var controlsVisible by remember { mutableStateOf(true) }
    var interactionTick by remember { mutableIntStateOf(0) }
    var locked by remember { mutableStateOf(false) }
    var showUnlock by remember { mutableStateOf(false) }
    var panel by remember { mutableIntStateOf(0) }
    var speed by remember { mutableFloatStateOf(prefs.getFloat("speed", 1f)) }
    var showRemaining by remember { mutableStateOf(prefs.getBoolean("show_remaining", false)) }
    var resizeIdx by remember { mutableIntStateOf(0) }
    var subSize by remember { mutableIntStateOf(prefs.getInt("sub_size", 1)) }
    var bgPlay by remember { mutableStateOf(prefs.getBoolean("bg_play", false)) }
    var landscape by remember { mutableStateOf(true) }
    var isPlaying by remember { mutableStateOf(false) }
    var posMs by remember { mutableLongStateOf(0L) }
    var durMs by remember { mutableLongStateOf(0L) }
    var scrubbing by remember { mutableStateOf(false) }
    var scrubValue by remember { mutableFloatStateOf(0f) }
    var tracks by remember { mutableStateOf(Tracks.EMPTY) }
    var toast by remember { mutableStateOf<String?>(null) }
    var toastIcon by remember { mutableIntStateOf(0) }
    var toastTick by remember { mutableIntStateOf(0) }
    var seekPreview by remember { mutableStateOf<String?>(null) }
    var fast by remember { mutableStateOf(false) }
    var ended by remember { mutableStateOf(false) }
    val pip = AppState.inPip

    val am = remember { ctx.getSystemService(Context.AUDIO_SERVICE) as AudioManager }
    val maxVol = remember { am.getStreamMaxVolume(AudioManager.STREAM_MUSIC).coerceAtLeast(1) }
    var volF by remember { mutableFloatStateOf(am.getStreamVolume(AudioManager.STREAM_MUSIC).toFloat()) }
    var brightness by remember {
        val b = activity?.window?.attributes?.screenBrightness ?: -1f
        mutableFloatStateOf(if (b >= 0f) b else 0.5f)
    }

    fun showToast(text: String, icon: Int = 0) {
        toast = text
        toastIcon = icon
        toastTick++
    }

    val exo = remember {
        ExoPlayer.Builder(ctx)
            .setAudioAttributes(
                AudioAttributes.Builder()
                    .setUsage(C.USAGE_MEDIA)
                    .setContentType(C.AUDIO_CONTENT_TYPE_MOVIE)
                    .build(),
                true
            )
            .setHandleAudioBecomingNoisy(true)
            .setWakeMode(C.WAKE_MODE_LOCAL)
            .build()
            .apply { playWhenReady = true }
    }

    fun persist() {
        val d = exo.duration
        if (d > 0 && idx in list.indices) updateRecent(ctx, list[idx], exo.currentPosition, d)
    }

    fun loadIndex(i: Int, startMs: Long?) {
        idx = i
        val v = list[i]
        val item = MediaItem.Builder()
            .setUri(v.uri)
            .setSubtitleConfigurations(findSubtitleConfigs(ctx, v))
            .build()
        val resume = startMs ?: savedPosition(ctx, v.uri.toString())
        exo.setMediaItem(item, if (resume > 5_000) resume else 0L)
        exo.prepare()
        exo.play()
        ended = false
        posMs = 0L
        if (startMs == null && resume > 5_000) showToast("Resume: ${fmt(resume)}", R.drawable.ic_play)
    }

    fun seekBy(ms: Long) {
        val d = exo.duration
        val t = (exo.currentPosition + ms).coerceIn(0L, if (d > 0) d else Long.MAX_VALUE)
        exo.seekTo(t)
        posMs = t
    }

    fun togglePlay() {
        if (ended) {
            exo.seekTo(0L)
            exo.play()
            ended = false
        } else if (exo.isPlaying) {
            exo.pause()
        } else {
            exo.play()
        }
    }

    fun exitMovie() {
        persist()
        onExit(list[idx])
    }

    fun selectTrack(g: Tracks.Group, i: Int) {
        exo.trackSelectionParameters = exo.trackSelectionParameters.buildUpon()
            .setTrackTypeDisabled(g.type, false)
            .setOverrideForType(TrackSelectionOverride(g.mediaTrackGroup, i))
            .build()
    }

    fun disableSubs() {
        exo.trackSelectionParameters = exo.trackSelectionParameters.buildUpon()
            .setTrackTypeDisabled(C.TRACK_TYPE_TEXT, true)
            .build()
    }

    fun addSubtitle(u: Uri) {
        val name = ctx.contentResolver.query(u, arrayOf(OpenableColumns.DISPLAY_NAME), null, null, null)
            ?.use { c -> if (c.moveToFirst()) c.getString(0) else null } ?: "subtitle"
        val ext = name.substringAfterLast('.', "").lowercase()
        val mime = subExts[ext] ?: MimeTypes.APPLICATION_SUBRIP
        val cur = exo.currentMediaItem ?: return
        val existing = cur.localConfiguration?.subtitleConfigurations ?: emptyList()
        val conf = MediaItem.SubtitleConfiguration.Builder(u)
            .setMimeType(mime)
            .setLabel(name)
            .setSelectionFlags(C.SELECTION_FLAG_DEFAULT)
            .build()
        val pos = exo.currentPosition
        exo.trackSelectionParameters = exo.trackSelectionParameters.buildUpon()
            .setTrackTypeDisabled(C.TRACK_TYPE_TEXT, false)
            .build()
        exo.setMediaItem(cur.buildUpon().setSubtitleConfigurations(existing + conf).build(), pos)
        exo.prepare()
        showToast("Subtitle add ho gaya", R.drawable.ic_cc)
    }

    val pickSub = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { u ->
        if (u != null) addSubtitle(u)
    }
    val notifPerm = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { }

    LaunchedEffect(Unit) { loadIndex(idx, null) }
    LaunchedEffect(speed) {
        exo.setPlaybackSpeed(speed)
        prefs.edit().putFloat("speed", speed).apply()
    }
    LaunchedEffect(toastTick) {
        if (toastTick > 0) {
            delay(1000)
            toast = null
        }
    }
    LaunchedEffect(showUnlock) {
        if (showUnlock) {
            delay(2500)
            showUnlock = false
        }
    }
    LaunchedEffect(controlsVisible, isPlaying, interactionTick, panel) {
        if (controlsVisible && isPlaying && panel == 0) {
            delay(3500)
            controlsVisible = false
        }
    }
    LaunchedEffect(Unit) {
        while (true) {
            posMs = exo.currentPosition.coerceAtLeast(0)
            durMs = exo.duration.coerceAtLeast(0)
            delay(250)
        }
    }
    LaunchedEffect(Unit) {
        while (true) {
            delay(5000)
            persist()
        }
    }
    LaunchedEffect(bgPlay) { AppState.autoPip = !bgPlay }

    DisposableEffect(exo) {
        val l = object : Player.Listener {
            override fun onIsPlayingChanged(playing: Boolean) {
                isPlaying = playing
                AppState.moviePlaying = playing
            }

            override fun onPlaybackStateChanged(state: Int) {
                if (state == Player.STATE_ENDED) {
                    val d = exo.duration
                    updateRecent(ctx, list[idx], d, d)
                    if (idx < list.size - 1) {
                        loadIndex(idx + 1, 0L)
                        showToast("Next: ${list[idx].name.substringBeforeLast('.')}", R.drawable.ic_skip_next)
                    } else {
                        ended = true
                        controlsVisible = true
                    }
                }
            }

            override fun onTracksChanged(t: Tracks) {
                tracks = t
            }

            override fun onVideoSizeChanged(videoSize: VideoSize) {
                AppState.videoW = videoSize.width
                AppState.videoH = videoSize.height
            }
        }
        exo.addListener(l)
        onDispose {
            exo.removeListener(l)
            persist()
            exo.release()
        }
    }

    DisposableEffect(Unit) {
        AppState.movieActive = true
        activity?.requestedOrientation = ActivityInfo.SCREEN_ORIENTATION_SENSOR_LANDSCAPE
        onDispose {
            AppState.movieActive = false
            AppState.moviePlaying = false
            activity?.requestedOrientation = ActivityInfo.SCREEN_ORIENTATION_PORTRAIT
            activity?.window?.let { w ->
                val a = w.attributes
                a.screenBrightness = WindowManager.LayoutParams.BRIGHTNESS_OVERRIDE_NONE
                w.attributes = a
            }
        }
    }

    val owner = LocalLifecycleOwner.current
    DisposableEffect(owner) {
        var wasPlaying = false
        val obs = LifecycleEventObserver { _, e ->
            if (e == Lifecycle.Event.ON_STOP) {
                persist()
                val inPip = activity?.isInPictureInPictureMode == true
                if (!bgPlay && !inPip) {
                    wasPlaying = exo.isPlaying
                    exo.pause()
                }
            }
            if (e == Lifecycle.Event.ON_START) {
                if (wasPlaying) {
                    exo.play()
                    wasPlaying = false
                }
            }
        }
        owner.lifecycle.addObserver(obs)
        onDispose { owner.lifecycle.removeObserver(obs) }
    }

    DisposableEffect(bgPlay) {
        if (bgPlay) {
            ContextCompat.startForegroundService(
                ctx,
                Intent(ctx, PlaybackService::class.java).putExtra("title", list[idx].name.substringBeforeLast('.'))
            )
        }
        onDispose { ctx.stopService(Intent(ctx, PlaybackService::class.java)) }
    }
    LaunchedEffect(idx) {
        if (bgPlay) {
            ContextCompat.startForegroundService(
                ctx,
                Intent(ctx, PlaybackService::class.java).putExtra("title", list[idx].name.substringBeforeLast('.'))
            )
        }
    }

    BackHandler {
        if (panel != 0) {
            panel = 0
        } else if (locked) {
            showUnlock = true
            showToast("Pehle unlock karo", R.drawable.ic_lock)
        } else {
            exitMovie()
        }
    }

    val progress = if (durMs > 0) (posMs.toFloat() / durMs).coerceIn(0f, 1f) else 0f
    val showControls = controlsVisible || ended

    Box(Modifier.fillMaxSize().background(Color.Black)) {
        AndroidView(
            factory = { c ->
                PlayerView(c).apply {
                    useController = false
                    keepScreenOn = true
                    setShutterBackgroundColor(android.graphics.Color.BLACK)
                    player = exo
                    subtitleView?.setStyle(
                        CaptionStyleCompat(
                            android.graphics.Color.WHITE,
                            android.graphics.Color.TRANSPARENT,
                            android.graphics.Color.TRANSPARENT,
                            CaptionStyleCompat.EDGE_TYPE_OUTLINE,
                            android.graphics.Color.BLACK,
                            null
                        )
                    )
                }
            },
            update = { pv ->
                pv.resizeMode = if (pip) AspectRatioFrameLayout.RESIZE_MODE_FIT else resizeModes[resizeIdx]
                pv.subtitleView?.setFractionalTextSize(0.0533f * subSizeScale[subSize])
            },
            modifier = Modifier.fillMaxSize()
        )

        if (!pip) {
            if (locked) {
                Box(
                    Modifier.fillMaxSize().pointerInput(Unit) {
                        detectTapGestures(onTap = { showUnlock = true })
                    }
                )
                if (showUnlock) {
                    Box(Modifier.align(Alignment.CenterStart).padding(start = 24.dp)) {
                        CircleBtn(R.drawable.ic_lock_open, onClick = {
                            locked = false
                            showUnlock = false
                            controlsVisible = true
                        }, size = 52.dp)
                    }
                }
            } else {
                // Gesture layers: tap / double tap / hold, and drag (seek, brightness, volume)
                Box(
                    Modifier.fillMaxSize()
                        .pointerInput(Unit) {
                            detectTapGestures(
                                onPress = {
                                    val released = withTimeoutOrNull(350) { tryAwaitRelease(); true }
                                    if (released == null && exo.isPlaying) {
                                        exo.setPlaybackSpeed(2f)
                                        fast = true
                                        tryAwaitRelease()
                                        exo.setPlaybackSpeed(speed)
                                        fast = false
                                    }
                                },
                                onLongPress = { },
                                onTap = {
                                    controlsVisible = !controlsVisible
                                    interactionTick++
                                },
                                onDoubleTap = { off ->
                                    val w = size.width
                                    if (off.x < w * 0.4f) {
                                        seekBy(-10_000)
                                        showToast("-10s", R.drawable.ic_replay)
                                    } else if (off.x > w * 0.6f) {
                                        seekBy(10_000)
                                        showToast("+10s", R.drawable.ic_forward)
                                    } else {
                                        togglePlay()
                                    }
                                }
                            )
                        }
                        .pointerInput(Unit) {
                            var axis = 0
                            var accX = 0f
                            var accY = 0f
                            var startPos = 0L
                            var target = 0L
                            var leftSide = true
                            detectDragGestures(
                                onDragStart = { off ->
                                    axis = 0
                                    accX = 0f
                                    accY = 0f
                                    startPos = exo.currentPosition
                                    target = startPos
                                    leftSide = off.x < size.width / 2f
                                },
                                onDragEnd = {
                                    if (axis == 1) {
                                        exo.seekTo(target)
                                        posMs = target
                                    }
                                    seekPreview = null
                                    axis = 0
                                },
                                onDragCancel = {
                                    seekPreview = null
                                    axis = 0
                                }
                            ) { change, drag ->
                                change.consume()
                                accX += drag.x
                                accY += drag.y
                                if (axis == 0 && (abs(accX) > 24f || abs(accY) > 24f)) {
                                    axis = if (abs(accX) > abs(accY)) 1 else 2
                                }
                                if (axis == 1) {
                                    val d = exo.duration
                                    val delta = (accX / size.width * 120_000f).toLong()
                                    target = (startPos + delta).coerceIn(0L, if (d > 0) d else Long.MAX_VALUE)
                                    val sign = if (target >= startPos) "+" else "-"
                                    seekPreview = "${fmt(target)}  ($sign${fmt(abs(target - startPos))})"
                                } else if (axis == 2) {
                                    val frac = -drag.y / size.height
                                    if (leftSide) {
                                        brightness = (brightness + frac).coerceIn(0.02f, 1f)
                                        activity?.window?.let { w ->
                                            val a = w.attributes
                                            a.screenBrightness = brightness
                                            w.attributes = a
                                        }
                                        showToast("Brightness ${(brightness * 100).roundToInt()}%", R.drawable.ic_brightness)
                                    } else {
                                        volF = (volF + frac * maxVol * 1.2f).coerceIn(0f, maxVol.toFloat())
                                        am.setStreamVolume(AudioManager.STREAM_MUSIC, volF.roundToInt(), 0)
                                        showToast("Volume ${(volF / maxVol * 100).roundToInt()}%", R.drawable.ic_volume_on)
                                    }
                                }
                            }
                        }
                )

                // Controls
                AnimatedVisibility(
                    visible = showControls,
                    modifier = Modifier.fillMaxSize(),
                    enter = fadeIn(),
                    exit = fadeOut()
                ) {
                    Box(Modifier.fillMaxSize()) {
                        Box(
                            Modifier.align(Alignment.TopCenter).fillMaxWidth().height(110.dp)
                                .background(Brush.verticalGradient(listOf(Color.Black.copy(alpha = 0.7f), Color.Transparent)))
                        )
                        Box(
                            Modifier.align(Alignment.BottomCenter).fillMaxWidth().height(170.dp)
                                .background(Brush.verticalGradient(listOf(Color.Transparent, Color.Black.copy(alpha = 0.8f))))
                        )

                        // Top bar
                        Row(
                            Modifier.align(Alignment.TopCenter).fillMaxWidth()
                                .padding(start = 14.dp, end = 14.dp, top = 18.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            CircleBtn(R.drawable.ic_back, onClick = { exitMovie() })
                            Column(Modifier.weight(1f).padding(horizontal = 12.dp)) {
                                Text(
                                    list[idx].name.substringBeforeLast('.'),
                                    color = Color.White,
                                    fontSize = 16.sp,
                                    fontWeight = FontWeight.SemiBold,
                                    maxLines = 1,
                                    overflow = TextOverflow.Ellipsis
                                )
                                if (list.size > 1) {
                                    Text("${idx + 1} / ${list.size}", color = Color.White.copy(alpha = 0.7f), fontSize = 12.sp)
                                }
                            }
                            CircleBtn(R.drawable.ic_cc, onClick = { panel = 2; interactionTick++ })
                            Spacer(Modifier.width(10.dp))
                            CircleBtn(R.drawable.ic_audiotrack, onClick = { panel = 1; interactionTick++ })
                        }

                        // Center controls
                        Row(
                            Modifier.align(Alignment.Center),
                            horizontalArrangement = Arrangement.spacedBy(40.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Box(Modifier.alpha(if (idx > 0) 1f else 0.3f)) {
                                CircleBtn(R.drawable.ic_skip_prev, onClick = {
                                    if (idx > 0) loadIndex(idx - 1, 0L)
                                }, size = 52.dp)
                            }
                            Box(
                                Modifier.size(70.dp).clip(CircleShape).background(Accent)
                                    .clickable { togglePlay(); interactionTick++ },
                                contentAlignment = Alignment.Center
                            ) {
                                Ic(
                                    if (ended) R.drawable.ic_replay
                                    else if (isPlaying) R.drawable.ic_pause
                                    else R.drawable.ic_play,
                                    38.dp
                                )
                            }
                            Box(Modifier.alpha(if (idx < list.size - 1) 1f else 0.3f)) {
                                CircleBtn(R.drawable.ic_skip_next, onClick = {
                                    if (idx < list.size - 1) loadIndex(idx + 1, 0L)
                                }, size = 52.dp)
                            }
                        }

                        // Bottom: seek bar + options
                        Column(
                            Modifier.align(Alignment.BottomCenter).fillMaxWidth()
                                .padding(start = 16.dp, end = 16.dp, bottom = 10.dp)
                        ) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                val curMs = if (scrubbing) (scrubValue * durMs).toLong() else posMs
                                Text(
                                    fmt(curMs),
                                    color = Color.White, fontSize = 13.sp,
                                    modifier = Modifier.clickable {
                                        showRemaining = !showRemaining
                                        prefs.edit().putBoolean("show_remaining", showRemaining).apply()
                                        interactionTick++
                                    }.padding(horizontal = 4.dp, vertical = 8.dp)
                                )
                                Slider(
                                    value = if (scrubbing) scrubValue else progress,
                                    onValueChange = {
                                        scrubbing = true
                                        scrubValue = it
                                        interactionTick++
                                    },
                                    onValueChangeFinished = {
                                        val d = exo.duration
                                        if (d > 0) {
                                            val t = (scrubValue * d).toLong()
                                            exo.seekTo(t)
                                            posMs = t
                                        }
                                        scrubbing = false
                                    },
                                    modifier = Modifier.weight(1f).padding(horizontal = 8.dp),
                                    colors = SliderDefaults.colors(
                                        thumbColor = Accent,
                                        activeTrackColor = Accent,
                                        inactiveTrackColor = Color.White.copy(alpha = 0.3f)
                                    )
                                )
                                Text(
                                    if (showRemaining) "-" + fmt((durMs - (if (scrubbing) (scrubValue * durMs).toLong() else posMs)).coerceAtLeast(0))
                                    else fmt(durMs),
                                    color = Color.White, fontSize = 13.sp,
                                    modifier = Modifier.clickable {
                                        showRemaining = !showRemaining
                                        prefs.edit().putBoolean("show_remaining", showRemaining).apply()
                                        interactionTick++
                                    }.padding(horizontal = 4.dp, vertical = 8.dp)
                                )
                            }
                            Row(
                                Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()),
                                horizontalArrangement = Arrangement.spacedBy(8.dp)
                            ) {
                                Chip(R.drawable.ic_lock, "Lock") {
                                    locked = true
                                    controlsVisible = false
                                    showToast("Screen lock", R.drawable.ic_lock)
                                }
                                Chip(R.drawable.ic_speed, fmtSpeed(speed)) {
                                    panel = 3
                                    interactionTick++
                                }
                                Chip(R.drawable.ic_aspect, resizeNames[resizeIdx]) {
                                    resizeIdx = (resizeIdx + 1) % resizeModes.size
                                    interactionTick++
                                }
                                Chip(R.drawable.ic_rotate, null) {
                                    landscape = !landscape
                                    activity?.requestedOrientation =
                                        if (landscape) ActivityInfo.SCREEN_ORIENTATION_SENSOR_LANDSCAPE
                                        else ActivityInfo.SCREEN_ORIENTATION_PORTRAIT
                                }
                                Chip(R.drawable.ic_pip, null) {
                                    val a = activity
                                    if (a != null) {
                                        AppState.pipRequested = true
                                        enterPip(a, AppState.videoW, AppState.videoH)
                                    }
                                }
                                Chip(R.drawable.ic_headset, "Background", bgPlay) {
                                    bgPlay = !bgPlay
                                    prefs.edit().putBoolean("bg_play", bgPlay).apply()
                                    if (bgPlay && Build.VERSION.SDK_INT >= 33 &&
                                        ContextCompat.checkSelfPermission(ctx, Manifest.permission.POST_NOTIFICATIONS)
                                        != PackageManager.PERMISSION_GRANTED
                                    ) {
                                        notifPerm.launch(Manifest.permission.POST_NOTIFICATIONS)
                                    }
                                    showToast(if (bgPlay) "Background play ON" else "Background play OFF", R.drawable.ic_headset)
                                }
                            }
                        }
                    }
                }

                // Speed panel
                if (panel == 3) {
                    SpeedPanel(speed, { speed = it }, { panel = 0 })
                }

                // Panels (audio / subtitles)
                if (panel == 1 || panel == 2) {
                    val audioGroups = tracks.groups.filter { it.type == C.TRACK_TYPE_AUDIO }
                    val textGroups = tracks.groups.filter { it.type == C.TRACK_TYPE_TEXT }
                    val textDisabled = exo.trackSelectionParameters.disabledTrackTypes.contains(C.TRACK_TYPE_TEXT)

                    val items: List<PanelItem> = if (panel == 1) {
                        val l = buildList {
                            audioGroups.forEach { g ->
                                for (i in 0 until g.length) {
                                    val ok = g.isTrackSupported(i)
                                    val label = trackLabel(g.getTrackFormat(i), i, "Audio") +
                                        (if (ok) "" else "  (device support nahi)")
                                    add(PanelItem(label, g.isTrackSelected(i)) {
                                        if (ok) selectTrack(g, i) else showToast("Ye audio is phone par nahi chalega")
                                        panel = 0
                                    })
                                }
                            }
                        }
                        if (l.isEmpty()) listOf(PanelItem("Koi alag audio track nahi hai", false) { }) else l
                    } else if (panel == 2) {
                        buildList {
                            add(PanelItem("Off", textDisabled || textGroups.none { it.isSelected }) {
                                disableSubs()
                                panel = 0
                            })
                            textGroups.forEach { g ->
                                for (i in 0 until g.length) {
                                    add(PanelItem(trackLabel(g.getTrackFormat(i), i, "Subtitle"), !textDisabled && g.isTrackSelected(i)) {
                                        selectTrack(g, i)
                                        panel = 0
                                    })
                                }
                            }
                            add(PanelItem("+ Subtitle file chuno (.srt .vtt .ass)", false) {
                                panel = 0
                                pickSub.launch(arrayOf("*/*"))
                            })
                            add(PanelItem("Text size: ${subSizeNames[subSize]}  (badalne ke liye tap)", false) {
                                subSize = (subSize + 1) % subSizeNames.size
                                prefs.edit().putInt("sub_size", subSize).apply()
                            })
                        }
                    } else {
                        speedOptions.map { sp ->
                            PanelItem(if (sp == 1f) "Normal (1x)" else "${sp}x", sp == speed) {
                                speed = sp
                                panel = 0
                            }
                        }
                    }
                    val title = if (panel == 1) "Audio track" else if (panel == 2) "Subtitles" else "Playback speed"
                    Panel(title, items) { panel = 0 }
                }
            }

            // On-screen feedback
            val t = toast
            if (t != null) {
                Row(
                    Modifier.align(Alignment.Center)
                        .background(Color.Black.copy(alpha = 0.6f), RoundedCornerShape(14.dp))
                        .padding(horizontal = 18.dp, vertical = 10.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    if (toastIcon != 0) {
                        Ic(toastIcon, 22.dp)
                        Spacer(Modifier.width(8.dp))
                    }
                    Text(t, color = Color.White, fontSize = 16.sp, fontWeight = FontWeight.Medium)
                }
            }
            val sp = seekPreview
            if (sp != null) {
                Box(
                    Modifier.align(Alignment.Center)
                        .background(Color.Black.copy(alpha = 0.6f), RoundedCornerShape(14.dp))
                        .padding(horizontal = 22.dp, vertical = 12.dp)
                ) {
                    Text(sp, color = Color.White, fontSize = 24.sp, fontWeight = FontWeight.Bold)
                }
            }
            if (fast) {
                Row(
                    Modifier.align(Alignment.TopCenter).padding(top = 24.dp)
                        .background(Color.Black.copy(alpha = 0.55f), RoundedCornerShape(20.dp))
                        .padding(horizontal = 14.dp, vertical = 6.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Ic(R.drawable.ic_fast_forward, 18.dp)
                    Spacer(Modifier.width(6.dp))
                    Text("2x", color = Color.White, fontSize = 14.sp, fontWeight = FontWeight.Bold)
                }
            }
        }
    }
}


// ---------- Speed control ----------

fun fmtSpeed(s: Float): String = "%.2f".format(s).trimEnd('0').trimEnd('.') + "x"

fun roundSpeed(v: Float): Float = ((v * 20f).roundToInt() / 20f).coerceIn(0.25f, 4f)

val speedPresets = listOf(0.5f, 0.75f, 1f, 1.1f, 1.25f, 1.5f, 1.75f, 2f, 2.5f, 3f)

@Composable
fun SpeedStep(label: String, onClick: () -> Unit) {
    Box(
        Modifier.clip(RoundedCornerShape(10.dp)).background(Color.White.copy(alpha = 0.12f))
            .clickable(onClick = onClick).padding(horizontal = 12.dp, vertical = 9.dp),
        contentAlignment = Alignment.Center
    ) {
        Text(label, color = Color.White, fontSize = 13.sp, fontWeight = FontWeight.Medium)
    }
}

@Composable
fun SpeedPanel(speed: Float, onSpeed: (Float) -> Unit, onDismiss: () -> Unit) {
    Box(
        Modifier.fillMaxSize().background(Color.Black.copy(alpha = 0.55f)).clickable(onClick = onDismiss),
        contentAlignment = Alignment.Center
    ) {
        Column(
            Modifier.widthIn(max = 440.dp).fillMaxWidth(0.92f).heightIn(max = 320.dp)
                .clip(RoundedCornerShape(18.dp)).background(Color(0xFF1C1C22))
                .clickable(onClick = { })
                .verticalScroll(rememberScrollState())
                .padding(16.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                Text("Playback speed", color = Color.White, fontSize = 16.sp, fontWeight = FontWeight.Bold, modifier = Modifier.weight(1f))
                SpeedStep("Reset 1x") { onSpeed(1f) }
            }
            Row(
                Modifier.fillMaxWidth().padding(top = 10.dp),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                SpeedStep("-0.25") { onSpeed(roundSpeed(speed - 0.25f)) }
                SpeedStep("-0.05") { onSpeed(roundSpeed(speed - 0.05f)) }
                Text("%.2fx".format(speed), color = Accent, fontSize = 34.sp, fontWeight = FontWeight.Bold)
                SpeedStep("+0.05") { onSpeed(roundSpeed(speed + 0.05f)) }
                SpeedStep("+0.25") { onSpeed(roundSpeed(speed + 0.25f)) }
            }
            Slider(
                value = speed,
                onValueChange = { onSpeed(roundSpeed(it)) },
                valueRange = 0.25f..4f,
                modifier = Modifier.fillMaxWidth(),
                colors = SliderDefaults.colors(
                    thumbColor = Accent,
                    activeTrackColor = Accent,
                    inactiveTrackColor = Color.White.copy(alpha = 0.25f)
                )
            )
            Row(
                Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                speedPresets.forEach { p ->
                    val active = abs(p - speed) < 0.001f
                    Box(
                        Modifier.clip(RoundedCornerShape(20.dp))
                            .background(if (active) Accent else Color.White.copy(alpha = 0.12f))
                            .clickable { onSpeed(p) }
                            .padding(horizontal = 14.dp, vertical = 8.dp)
                    ) {
                        Text(fmtSpeed(p), color = Color.White, fontSize = 13.sp)
                    }
                }
            }
        }
    }
}
