package com.reels.player

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.itemsIndexed
import androidx.compose.foundation.lazy.grid.rememberLazyGridState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.foundation.layout.Arrangement

/** Grid of reels shown when you press back inside Reels. Tap a video to jump straight into Reels at that video. */
@Composable
fun ReelsGridScreen(list: List<Video>, focus: Int, onOpen: (Int) -> Unit, onBack: () -> Unit) {
    val safeFocus = if (list.isEmpty()) 0 else focus.coerceIn(0, list.size - 1)
    val gridState = rememberLazyGridState(initialFirstVisibleItemIndex = (safeFocus / 3) * 3)

    Column(Modifier.fillMaxSize().background(Bg)) {
        BrowseHeader("Reels", "${list.size} videos", null) {
            if (list.isNotEmpty()) {
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    if (safeFocus > 0) {
                        Chip(R.drawable.ic_replay, "Resume", false) { onOpen(safeFocus) }
                    }
                    Chip(R.drawable.ic_play, "Play all", true) { onOpen(0) }
                }
            }
        }

        if (list.isEmpty()) {
            Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                Text("No videos found", color = Fg.copy(alpha = 0.6f))
            }
        } else {
            LazyVerticalGrid(
                columns = GridCells.Fixed(3),
                state = gridState,
                contentPadding = PaddingValues(8.dp),
                horizontalArrangement = Arrangement.spacedBy(6.dp),
                verticalArrangement = Arrangement.spacedBy(6.dp),
                modifier = Modifier.fillMaxSize()
            ) {
                itemsIndexed(list, key = { _, v -> v.id }) { idx, v ->
                    val shape = RoundedCornerShape(10.dp)
                    Box(
                        Modifier.fillMaxWidth().aspectRatio(0.62f)
                            .clip(shape)
                            .background(CardBg)
                            .then(if (idx == safeFocus) Modifier.border(2.dp, Accent, shape) else Modifier)
                            .clickable { onOpen(idx) }
                    ) {
                        Thumb(v, 300, 480, Modifier.fillMaxSize())
                        Box(
                            Modifier.align(Alignment.BottomCenter).fillMaxWidth().height(70.dp).background(
                                Brush.verticalGradient(listOf(Color.Transparent, Color.Black.copy(alpha = 0.8f)))
                            )
                        )
                        Text(
                            fmt(v.durationMs),
                            color = Color.White,
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Medium,
                            modifier = Modifier.align(Alignment.TopEnd).padding(6.dp)
                                .background(Color.Black.copy(alpha = 0.6f), RoundedCornerShape(6.dp))
                                .padding(horizontal = 5.dp, vertical = 2.dp)
                        )
                        Text(
                            v.name.substringBeforeLast('.'),
                            color = Color.White,
                            fontSize = 11.sp,
                            maxLines = 2,
                            overflow = TextOverflow.Ellipsis,
                            modifier = Modifier.align(Alignment.BottomStart).padding(6.dp)
                        )
                    }
                }
            }
        }
    }
}
