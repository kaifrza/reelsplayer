package com.reels.player

import android.content.Context
import android.os.Build
import java.io.File
import java.io.PrintWriter
import java.io.StringWriter
import java.util.Date

/** Saves the stack trace of a crash so the app can show it on the next launch. */
object CrashReporter {
    private fun file(ctx: Context) = File(ctx.filesDir, "last_crash.txt")

    fun install(ctx: Context) {
        val app = ctx.applicationContext
        val previous = Thread.getDefaultUncaughtExceptionHandler()
        Thread.setDefaultUncaughtExceptionHandler { thread, error ->
            try {
                val sw = StringWriter()
                error.printStackTrace(PrintWriter(sw))
                file(app).writeText(
                    "KaifsPlayer crash report\n" +
                        "Time: " + Date() + "\n" +
                        "Thread: " + thread.name + "\n" +
                        "Device: " + Build.MANUFACTURER + " " + Build.MODEL +
                        ", Android " + Build.VERSION.RELEASE + " (API " + Build.VERSION.SDK_INT + ")\n\n" +
                        sw.toString()
                )
            } catch (e: Exception) {
                // never let the reporter itself crash
            }
            previous?.uncaughtException(thread, error)
        }
    }

    fun read(ctx: Context): String? {
        val f = file(ctx)
        return if (f.exists()) runCatching { f.readText() }.getOrNull() else null
    }

    fun clear(ctx: Context) {
        runCatching { file(ctx).delete() }
    }
}
